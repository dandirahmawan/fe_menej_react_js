create view view_project_team as
  select `p`.`project_id` AS `project_id`,
         `u`.`user_id`    AS `user_id`,
         `u`.`user_name`  AS `user_name`,
         `u`.`email_user` AS `email_user`
  from (`project_management`.`project_team` `p` join `project_management`.`user` `u` on ((`u`.`user_id` =
                                                                                          `p`.`user_id`)))
  group by `p`.`project_id`, `u`.`user_id`;

