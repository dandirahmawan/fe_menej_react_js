create view view_document_file as
  select `df`.`modul_id`         AS `modul_id`,
         `df`.`project_id`       AS `project_id`,
         `df`.`user_id`          AS `user_id`,
         `df`.`file_name`        AS `file_name`,
         `df`.`file_size`        AS `file_size`,
         `df`.`extension`        AS `extension`,
         `df`.`description_file` AS `description_file`,
         `df`.`path`             AS `path`,
         `df`.`upload_date`      AS `upload_date`,
         `m`.`modul_name`        AS `modul_name`,
         `m`.`user_id`           AS `user_id_module`,
         `p`.`project_name`      AS `project_name`,
         `p`.`pic`               AS `pic`,
         `usr`.`user_name`       AS `user_name`
  from (((`project_management`.`document_file` `df` left join `project_management`.`modul` `m` on ((`m`.`modul_id` =
                                                                                                    `df`.`modul_id`))) left join `project_management`.`project` `p` on ((
    `p`.`project_id` = `df`.`project_id`))) left join `project_management`.`user` `usr` on ((`usr`.`user_id` =
                                                                                             `df`.`user_id`)))
  where (((`m`.`is_trash` <> 'Y') or isnull(`m`.`is_trash`)) and ((`p`.`is_delete` <> 'Y') or isnull(`p`.`is_delete`)));

