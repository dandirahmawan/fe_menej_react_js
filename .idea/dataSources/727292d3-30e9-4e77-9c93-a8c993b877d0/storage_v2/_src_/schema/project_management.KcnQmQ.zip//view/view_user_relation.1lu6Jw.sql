create view view_user_relation as
  select `usr`.`user_id`     AS `user_id`,
         `ur`.`user_one`     AS `user_one`,
         `ur`.`user_two`     AS `user_two`,
         `usr`.`email_user`  AS `email_user`,
         `usr`.`user_name`   AS `user_name`,
         `usr`.`pic_profile` AS `pic_profile`,
         `ur`.`relate_date`  AS `relate_date`
  from (`project_management`.`user` `usr` join `project_management`.`user_relation` `ur` on ((
    (`ur`.`user_one` = `usr`.`user_id`) or (`ur`.`user_two` = `usr`.`user_id`))));

