create view view_data_module as
  select `project_management`.`modul`.`modul_id`                                                             AS `modul_id`,
         `project_management`.`modul`.`project_id`                                                           AS `project_id`,
         `project_management`.`modul`.`user_id`                                                              AS `user_id`,
         `project_management`.`modul`.`modul_name`                                                           AS `modul_name`,
         `project_management`.`modul`.`modul_status`                                                         AS `modul_status`,
         `project_management`.`modul`.`created_by`                                                           AS `created_by`,
         `project_management`.`modul`.`created_date`                                                         AS `created_date`,
         `project_management`.`modul`.`is_trash`                                                             AS `is_trash`,
         `project_management`.`modul`.`updated_by`                                                           AS `updated_by`,
         `project_management`.`modul`.`updated_date`                                                         AS `updated_date`,
         `project_management`.`modul`.`percentage`                                                           AS `percentage`,
         `project_management`.`modul`.`description`                                                          AS `description`,
         `project_management`.`modul`.`end_date`                                                             AS `end_date`,
         (select count(`project_management`.`bugs`.`modul_id`)
          from `project_management`.`bugs`
          where (`project_management`.`bugs`.`modul_id` =
                 `project_management`.`modul`.`modul_id`))                                                   AS `count_bugs`,
         (select count(`project_management`.`document_file`.`modul_id`)
          from `project_management`.`document_file`
          where (`project_management`.`document_file`.`modul_id` =
                 `project_management`.`modul`.`modul_id`))                                                   AS `count_doc_file`
  from `project_management`.`modul`;

