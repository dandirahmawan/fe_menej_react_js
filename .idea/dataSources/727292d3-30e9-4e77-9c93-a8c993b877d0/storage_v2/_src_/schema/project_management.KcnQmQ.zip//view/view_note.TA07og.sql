create view view_note as select `nt`.`note_id`              AS `note_id`,
                                `nt`.`note`                 AS `note`,
                                ifnull(`nt`.`module_id`, 0) AS `module_id`,
                                ifnull(`nt`.`bugs_id`, 0)   AS `bugs_id`,
                                `nt`.`created_date`         AS `created_date`,
                                `nt`.`type`                 AS `type`,
                                `nt`.`user_id`              AS `user_id`,
                                `usr`.`user_name`           AS `user_name`,
                                `m`.`modul_name`            AS `modul_name`,
                                `p`.`project_id`            AS `project_id`,
                                'N'                         AS `is_delete`
                         from (((`project_management`.`note` `nt` join `project_management`.`user` `usr` on ((
                           `usr`.`user_id` = `nt`.`user_id`))) join `project_management`.`modul` `m` on ((`m`.`modul_id`
                                                                                                          =
                                                                                                          `nt`.`module_id`))) left join `project_management`.`project` `p` on ((
                           `p`.`project_id` = `m`.`project_id`)))
                         where (isnull(`nt`.`bugs_id`) or (`nt`.`bugs_id` = 0))
                         union select `nt`.`note_id`              AS `note_id`,
                                      `nt`.`note`                 AS `note`,
                                      ifnull(`nt`.`module_id`, 0) AS `module_id`,
                                      ifnull(`nt`.`bugs_id`, 0)   AS `bugs_id`,
                                      `nt`.`created_date`         AS `created_date`,
                                      `nt`.`type`                 AS `type`,
                                      `nt`.`user_id`              AS `user_id`,
                                      `usr`.`user_name`           AS `user_name`,
                                      `m`.`modul_name`            AS `modul_name`,
                                      `p`.`project_id`            AS `project_id`,
                                      'N'                         AS `is_delete`
                               from ((((`project_management`.`note` `nt` join `project_management`.`user` `usr` on ((
                                 `usr`.`user_id` = `nt`.`user_id`))) join `project_management`.`bugs` `b` on ((
                                 `b`.`bugs_id` = `nt`.`bugs_id`))) join `project_management`.`modul` `m` on ((
                                 `m`.`modul_id` = `nt`.`module_id`))) left join `project_management`.`project` `p` on ((
                                 `p`.`project_id` = `m`.`project_id`)));

