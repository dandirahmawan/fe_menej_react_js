create view view_data_permition as
  select `p`.`permition_code`         AS `permition_code`,
         `p`.`user_id`                AS `user_id`,
         `p`.`project_id`             AS `project_id`,
         `pc`.`permition_name`        AS `permition_name`,
         `pc`.`permition_description` AS `permition_description`
  from (`project_management`.`permition` `p` left join `project_management`.`permition_code` `pc` on ((
    `p`.`permition_code` = `pc`.`permition_code`)));

