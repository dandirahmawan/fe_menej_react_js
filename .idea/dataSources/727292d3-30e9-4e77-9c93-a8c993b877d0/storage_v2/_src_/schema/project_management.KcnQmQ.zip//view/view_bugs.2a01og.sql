create view view_bugs as
  select `b`.`bugs_id`                                                     AS `bugs_id`,
         `b`.`bug_status`                                                  AS `bug_status`,
         `b`.`create_date`                                                 AS `create_date`,
         `b`.`is_delete`                                                   AS `is_delete`,
         `b`.`modul_id`                                                    AS `modul_id`,
         `b`.`note`                                                        AS `note`,
         `m`.`modul_name`                                                  AS `modul_name`,
         (case when (`b`.`modul_id` = 0) then 0 else `p`.`project_id` end) AS `project_id`,
         `p`.`project_name`                                                AS `project_name`,
         `p`.`pic`                                                         AS `pic`,
         ifnull(`u`.`user_id`, 0)                                          AS `user_id`,
         `u`.`user_name`                                                   AS `user_name`,
         (select count(0)
          from `project_management`.`note`
          where ((`project_management`.`note`.`bugs_id` = `b`.`bugs_id`) and
                 (`project_management`.`note`.`bugs_id` > 0)))             AS `count_note`
  from (((`project_management`.`bugs` `b` left join `project_management`.`modul` `m` on ((`m`.`modul_id` =
                                                                                          `b`.`modul_id`))) left join `project_management`.`user` `u` on ((
    `u`.`user_id` = `m`.`user_id`))) left join `project_management`.`project` `p` on ((`b`.`project_id` =
                                                                                       `p`.`project_id`)))
  where ((isnull(`m`.`is_trash`) or (`m`.`is_trash` <> 'Y')) and (`b`.`bugs_id` > 0))
  order by `b`.`create_date`;

