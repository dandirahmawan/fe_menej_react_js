create view FCS_TEST_VALID as
  SELECT PC.PROPOSAL_ID, PP.PROMO_PRODUK_ID, AC.CUSTOMER_ID
     FROM (SELECT PCA.REGION_CODE CODE,
                  PCA.CUST_REG_FLG,
                  PCA.PROPOSAL_ID,
                  PCA.PROMO_CUSTOMER_ID
             FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA
            WHERE PCA.CUST_REG_FLG = 'REGION'
           UNION
           SELECT PCA.AREA_CODE CODE,
                  PCA.CUST_REG_FLG,
                  PCA.PROPOSAL_ID,
                  PCA.PROMO_CUSTOMER_ID
             FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA
            WHERE PCA.CUST_REG_FLG = 'AREA'
           UNION
           SELECT PCA.LOC_CODE CODE,
                  PCA.CUST_REG_FLG,
                  PCA.PROPOSAL_ID,
                  PCA.PROMO_CUSTOMER_ID
             FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA
            WHERE PCA.CUST_REG_FLG = 'LOCATION') REGION,
          FOCUSPP.PROMO_PRODUK PP,
          FOCUSPP.PROPOSAL PC,
        APPS.AR_CUSTOMERS AC
    WHERE REGION.CODE =
             CASE
                WHEN REGION.CUST_REG_FLG = 'REGION' THEN AC.ATTRIBUTE3
                WHEN REGION.CUST_REG_FLG = 'AREA' THEN AC.ATTRIBUTE4
                WHEN REGION.CUST_REG_FLG = 'LOCATION' THEN AC.ATTRIBUTE5
             END
          AND REGION.PROPOSAL_ID = PP.PROPOSAL_ID
          AND PP.PROPOSAL_ID = PC.PROPOSAL_ID
          AND PC.DISCOUNT_TYPE = 'PROMOBARANG'
          AND PC.MEKANISME_PENAGIHAN = 'ONINVOICE'
          AND PC.STATUS NOT IN ('CANCELED')
          AND PP.CLOSE_FLAG = 'N'
          AND AC.ATTRIBUTE8 IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 PCA1.CUSTTYP_CODE,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               PCA1.PROPOSAL_ID)
                                         FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA1
                                        WHERE PCA1.CUST_NREG_FLG = 'CUSTTYPE'
                                              AND PCA1.PROPOSAL_ID =
                                                     REGION.PROPOSAL_ID
                                              AND PCA1.PROMO_CUSTOMER_ID =
                                                     REGION.PROMO_CUSTOMER_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                AC.ATTRIBUTE8)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              PCA1.CUSTTYP_CODE,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            PCA1.PROPOSAL_ID)
                                      FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA1
                                     WHERE PCA1.CUST_NREG_FLG = 'CUSTTYPE'
                                           AND PCA1.PROPOSAL_ID =
                                                  REGION.PROPOSAL_ID
                                           AND PCA1.PROMO_CUSTOMER_ID =
                                                  REGION.PROMO_CUSTOMER_ID),
                                   '[^;'']+'))
          AND AC.ATTRIBUTE1 IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 PCA1.CUSTGRP_CODE,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               PCA1.PROPOSAL_ID)
                                         FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA1
                                        WHERE PCA1.CUST_NREG_FLG = 'CUSTGROUP'
                                              AND PCA1.PROPOSAL_ID =
                                                     REGION.PROPOSAL_ID
                                              AND PCA1.PROMO_CUSTOMER_ID =
                                                     REGION.PROMO_CUSTOMER_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                AC.ATTRIBUTE1)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              PCA1.CUSTGRP_CODE,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            PCA1.PROPOSAL_ID)
                                      FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA1
                                     WHERE PCA1.CUST_NREG_FLG = 'CUSTGROUP'
                                           AND PCA1.PROPOSAL_ID =
                                                  REGION.PROPOSAL_ID
                                           AND PCA1.PROMO_CUSTOMER_ID =
                                                  REGION.PROMO_CUSTOMER_ID),
                                   '[^;'']+'))
          AND AC.CUSTOMER_ID IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 PCA1.CUSTOMER_ID,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               PCA1.PROPOSAL_ID)
                                         FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA1
                                        WHERE PCA1.CUST_NREG_FLG = 'CUSTOMER'
                                              AND PCA1.PROPOSAL_ID =
                                                     REGION.PROPOSAL_ID
                                              AND PCA1.PROMO_CUSTOMER_ID =
                                                     REGION.PROMO_CUSTOMER_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                AC.CUSTOMER_ID)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              PCA1.CUSTOMER_ID,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            PCA1.PROPOSAL_ID)
                                      FROM FOCUSPP.PROMO_CUSTOMER_AREA PCA1
                                     WHERE PCA1.CUST_NREG_FLG = 'CUSTOMER'
                                           AND PCA1.PROPOSAL_ID =
                                                  REGION.PROPOSAL_ID
                                           AND PCA1.PROMO_CUSTOMER_ID =
                                                  REGION.PROMO_CUSTOMER_ID),
                                   '[^;'']+'))
          AND AC.CUSTOMER_ID NOT IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 FPEA.CUSTOMER_ID,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               FPEA.
                                                                PROMO_PRODUK_ID)
                                         FROM APPS.FCS_PPPC_EXCLUDE_AREA FPEA
                                        WHERE FPEA.PROMO_PRODUK_ID =
                                                 PP.PROMO_PRODUK_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                0)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              FPEA.CUSTOMER_ID,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            FPEA.
                                                             PROMO_PRODUK_ID)
                                      FROM APPS.FCS_PPPC_EXCLUDE_AREA FPEA
                                     WHERE FPEA.PROMO_PRODUK_ID =
                                              PP.PROMO_PRODUK_ID),
                                   '[^;'']+'))
UNION
--HO
SELECT PC.PROPOSAL_ID, PP.PROMO_PRODUK_ID, AC.CUSTOMER_ID
     FROM (SELECT PCA.REGION_CODE CODE,
                  PCA.CUST_REG_FLG,
                  PCA.PROMO_PRODUK_ID,
                  PCA.PROMO_CUSTOMER_ID
             FROM FOCUSPP.PROMO_CUSTOMER_HO PCA
            WHERE PCA.CUST_REG_FLG = 'REGION'
           UNION
           SELECT PCA.AREA_CODE CODE,
                  PCA.CUST_REG_FLG,
                  PCA.PROMO_PRODUK_ID,
                  PCA.PROMO_CUSTOMER_ID
             FROM FOCUSPP.PROMO_CUSTOMER_HO PCA
            WHERE PCA.CUST_REG_FLG = 'AREA'
           UNION
           SELECT PCA.LOC_CODE CODE,
                  PCA.CUST_REG_FLG,
                  PCA.PROMO_PRODUK_ID,
                  PCA.PROMO_CUSTOMER_ID
             FROM FOCUSPP.PROMO_CUSTOMER_HO PCA
            WHERE PCA.CUST_REG_FLG = 'LOCATION') REGION,
          FOCUSPP.PROMO_PRODUK PP,
          FOCUSPP.PROPOSAL PC,
          APPS.AR_CUSTOMERS AC
    WHERE REGION.CODE =
             CASE
                WHEN REGION.CUST_REG_FLG = 'REGION' THEN AC.ATTRIBUTE3
                WHEN REGION.CUST_REG_FLG = 'AREA' THEN AC.ATTRIBUTE4
                WHEN REGION.CUST_REG_FLG = 'LOCATION' THEN AC.ATTRIBUTE5
             END
          AND REGION.PROMO_PRODUK_ID = PP.PROMO_PRODUK_ID
          AND PP.PROPOSAL_ID = PC.PROPOSAL_ID
          AND PC.DISCOUNT_TYPE = 'PROMOBARANG'
          AND PC.MEKANISME_PENAGIHAN = 'ONINVOICE'
          AND PC.STATUS NOT IN ('CANCELED')
          AND PP.CLOSE_FLAG = 'N'
          AND AC.ATTRIBUTE8 IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 PCA1.CUSTTYP_CODE,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               PCA1.
                                                                PROMO_PRODUK_ID)
                                         FROM FOCUSPP.PROMO_CUSTOMER_HO PCA1
                                        WHERE PCA1.CUST_NREG_FLG = 'CUSTTYPE'
                                              AND PCA1.PROMO_PRODUK_ID =
                                                     REGION.PROMO_PRODUK_ID
                                              AND PCA1.PROMO_CUSTOMER_ID =
                                                     REGION.PROMO_CUSTOMER_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                AC.ATTRIBUTE8)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              PCA1.CUSTTYP_CODE,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            PCA1.
                                                             PROMO_PRODUK_ID)
                                      FROM FOCUSPP.PROMO_CUSTOMER_HO PCA1
                                     WHERE PCA1.CUST_NREG_FLG = 'CUSTTYPE'
                                           AND PCA1.PROMO_PRODUK_ID =
                                                  REGION.PROMO_PRODUK_ID
                                           AND PCA1.PROMO_CUSTOMER_ID =
                                                  REGION.PROMO_CUSTOMER_ID),
                                   '[^;'']+'))
          AND AC.ATTRIBUTE1 IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 PCA1.CUSTGRP_CODE,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               PCA1.
                                                                PROMO_PRODUK_ID)
                                         FROM FOCUSPP.PROMO_CUSTOMER_HO PCA1
                                        WHERE PCA1.CUST_NREG_FLG = 'CUSTGROUP'
                                              AND PCA1.PROMO_PRODUK_ID =
                                                     REGION.PROMO_PRODUK_ID
                                              AND PCA1.PROMO_CUSTOMER_ID =
                                                     REGION.PROMO_CUSTOMER_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                AC.ATTRIBUTE1)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              PCA1.CUSTGRP_CODE,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            PCA1.
                                                             PROMO_PRODUK_ID)
                                      FROM FOCUSPP.PROMO_CUSTOMER_HO PCA1
                                     WHERE PCA1.CUST_NREG_FLG = 'CUSTGROUP'
                                           AND PCA1.PROMO_PRODUK_ID =
                                                  REGION.PROMO_PRODUK_ID
                                           AND PCA1.PROMO_CUSTOMER_ID =
                                                  REGION.PROMO_CUSTOMER_ID),
                                   '[^;'']+'))
          AND AC.CUSTOMER_ID IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 PCA1.CUSTOMER_ID,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               PCA1.
                                                                PROMO_PRODUK_ID)
                                         FROM FOCUSPP.PROMO_CUSTOMER_HO PCA1
                                        WHERE PCA1.CUST_NREG_FLG = 'CUSTOMER'
                                              AND PCA1.PROMO_PRODUK_ID =
                                                     REGION.PROMO_PRODUK_ID
                                              AND PCA1.PROMO_CUSTOMER_ID =
                                                     REGION.PROMO_CUSTOMER_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                AC.CUSTOMER_ID)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              PCA1.CUSTOMER_ID,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            PCA1.
                                                             PROMO_PRODUK_ID)
                                      FROM FOCUSPP.PROMO_CUSTOMER_HO PCA1
                                     WHERE PCA1.CUST_NREG_FLG = 'CUSTOMER'
                                           AND PCA1.PROMO_PRODUK_ID =
                                                  REGION.PROMO_PRODUK_ID
                                           AND PCA1.PROMO_CUSTOMER_ID =
                                                  REGION.PROMO_CUSTOMER_ID),
                                   '[^;'']+'))
          AND AC.CUSTOMER_ID NOT IN
                 (    SELECT NVL (
                                TRIM (
                                   REGEXP_SUBSTR (
                                      (SELECT LISTAGG (
                                                 FPEA.CUSTOMER_ID,
                                                 ';')
                                              WITHIN GROUP (ORDER BY
                                                               FPEA.
                                                                PROMO_PRODUK_ID)
                                         FROM APPS.FCS_PPPC_EXCLUDE_HO FPEA
                                        WHERE FPEA.PROMO_PRODUK_ID =
                                                 PP.PROMO_PRODUK_ID),
                                      '[^;'']+',
                                      1,
                                      LEVEL)),
                                0)
                        FROM DUAL
                  CONNECT BY LEVEL <=
                                REGEXP_COUNT (
                                   (SELECT LISTAGG (
                                              FPEA.CUSTOMER_ID,
                                              ';')
                                           WITHIN GROUP (ORDER BY
                                                            FPEA.
                                                             PROMO_PRODUK_ID)
                                      FROM APPS.FCS_PPPC_EXCLUDE_HO FPEA
                                     WHERE FPEA.PROMO_PRODUK_ID =
                                              PP.PROMO_PRODUK_ID),
                                   '[^;'']+'))
   ORDER BY 1
/

