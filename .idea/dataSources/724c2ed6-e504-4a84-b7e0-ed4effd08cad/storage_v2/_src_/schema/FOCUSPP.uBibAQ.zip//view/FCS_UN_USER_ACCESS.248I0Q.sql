create view FCS_UN_USER_ACCESS as
  select uua.user_name, uua.password, uua.descr, uua.title, uua.contact_no, uua.company_id, uua.active_period_from, uua.active_period_to, uua.user_initial, uua.user_type, uua.user_division, uua.direct_spv from ut_user_access uua
    union all
    select aua.user_name, aua.password, aua.descr, aua.title, aua.contact_no, aua.company_id, aua.active_period_from, aua.active_period_to, aua.user_initial, aua.user_type, aua.user_division, aua.direct_spv from app_user_access aua where aua.user_name not in (select uua.user_name from ut_user_access uua)
/

