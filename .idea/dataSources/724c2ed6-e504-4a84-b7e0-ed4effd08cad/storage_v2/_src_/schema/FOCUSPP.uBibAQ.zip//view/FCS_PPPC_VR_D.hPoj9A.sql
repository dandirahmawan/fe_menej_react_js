create view FCS_PPPC_VR_D as
  SELECT DR.COMPANY,
          DR.PP_RCODE,
          DR.PP_ID,
          DR.PP_NO,
          DR.REQUESTER,
          DR.FLAG_AREA_HO,
          DR.PP_DATE,
          DR.PP_REFERENCE,
          DR.PP_STATUS,
          DR.PC,
          DR.ADDENDUM,
          DR.PC_DATE,
          DR.EBS_REQUEST_ID,
          DR.EBS_STATUS,
          DR.START_DATE_PROMO,
          DR.END_DATE_PROMO,
          DR.START_MONTH_PROMO,
          DR.END_MONTH_PROMO,
          DR.YEAR_PROMO,
          DR.TYPE_PROMO,
          DR.PROGRAM_PROMO,
          DR.FLAG_ON_OFF,
          DR.START_DATE_HIST,
          DR.END_DATE_HIST,
          DR.HIST_BY,
          DR.KOMPENSASI,
          DR.NOTES,
          DR.CUST_REGION,
          DR.CUST_AREA,
          DR.CUST_LOC,
          DR.CUST_TYPE,
          DR.CUST_GROUP,
          DR.CUSTOMER,
          DR.PROD_CATEGORY_PROMO,
          DR.LINE,
          DR.LINE_ID,
          DR.PROMO_PRODUK_ID,
          DR.LINE_FLAG_APPROVAL,
          DR.PROD_CATEGORY,
          DR.PROD_CLASS,
          DR.PROD_BRAND,
          DR.PROD_EXTENSION,
          DR.PROD_PACKAGING,
          DR.PROD_VARIANT,
          DR.PRODUCT_DETAIL,
          DR.PROD_MEKANISME,
          DR.PROD_DESCRIPTION,
          DR.DETIL_PROMO,
          DR.QTY_AVG_SALES,
          DR.QTY_TARGET,
          DR.UOM_QTY_TARGET,
          DR.UNIT_PRICE,
          DR.VALUE_TARGET,
          CASE
             WHEN DR.TYPE_PROMO <> 'BIAYA'
             THEN
                ROUND (DR.ON_TOP_TPB / DR.QTY_TARGET, 2)
             ELSE
                0
          END
             ON_TOP_TPB_UOM,
          CASE
             WHEN DR.TYPE_PROMO <> 'BIAYA'
             THEN
                ROUND (MF_PB / DR.QTY_TARGET, 2)
             ELSE
                0
          END
             MF_PB_UOM,
          DR.ON_TOP_TPB,
          DR.MF_PB,
          DR.RASIO_ON_TOP_TPB,
          DR.RASIO_MF_PB,
          DR.TOTAL_RASIO,
          DR.POSTING_ON_TOP_TPB,
          DR.POSTING_MF_PB,
          DR.ITEM_EXPENSE,
          DR.BUDGET_KOMBINASI,
          DR.VALUE_BUDGET_KOMBINASI,
          CASE
             WHEN     (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB) - DR.AMOUNT_KOMBINASI_BUDGET <
                         1
                  AND   (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                      - DR.AMOUNT_KOMBINASI_BUDGET > 0
                  AND DR.REALISASI_ON_TOP_TPB > 0
             THEN
                DR.AMOUNT_KOMBINASI_BUDGET - DR.REALISASI_MF_PB
             ELSE
                DR.REALISASI_ON_TOP_TPB
          END
             AS REALISASI_ON_TOP_TPB,
          CASE
             WHEN     DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET < 1
                  AND DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET > 0
             THEN
                DR.AMOUNT_KOMBINASI_BUDGET
             ELSE
                DR.REALISASI_MF_PB
          END
             AS REALISASI_MF_PB,
          DR.FLAG_CLOSE_CANCEL,
          DR.CLOSE_CANCEL_BY,
          DR.CLOSE_CANCEL_DATE,
          CASE
             WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
             THEN
                  DR.ON_TOP_TPB
                - NVL (
                     CASE
                        WHEN       (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                                 - DR.AMOUNT_KOMBINASI_BUDGET < 1
                             AND   (  DR.REALISASI_ON_TOP_TPB
                                    + DR.REALISASI_MF_PB)
                                 - DR.AMOUNT_KOMBINASI_BUDGET > 0
                             AND DR.REALISASI_ON_TOP_TPB > 0
                        THEN
                           DR.AMOUNT_KOMBINASI_BUDGET - DR.REALISASI_MF_PB
                        ELSE
                           DR.REALISASI_ON_TOP_TPB
                     END,
                     0)
             ELSE
                NULL
          END
             CLOSE_CANCEL_OT_TPB,
          CASE
             WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
             THEN
                  DR.MF_PB
                - NVL (
                     CASE
                        WHEN     DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET <
                                    1
                             AND   DR.REALISASI_MF_PB
                                 - DR.AMOUNT_KOMBINASI_BUDGET > 0
                        THEN
                           DR.AMOUNT_KOMBINASI_BUDGET
                        ELSE
                           DR.REALISASI_MF_PB
                     END,
                     0)
             ELSE
                NULL
          END
             CLOSE_CANCEL_MF_PB,
            (  DR.ON_TOP_TPB
             - NVL (
                  CASE
                     WHEN       (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                              - DR.AMOUNT_KOMBINASI_BUDGET < 1
                          AND   (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                              - DR.AMOUNT_KOMBINASI_BUDGET > 0
                          AND DR.REALISASI_ON_TOP_TPB > 0
                     THEN
                        DR.AMOUNT_KOMBINASI_BUDGET - DR.REALISASI_MF_PB
                     ELSE
                        DR.REALISASI_ON_TOP_TPB
                  END,
                  0))
          - CASE
               WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    DR.ON_TOP_TPB
                  - NVL (
                       CASE
                          WHEN       (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                                   - DR.AMOUNT_KOMBINASI_BUDGET < 1
                               AND   (  DR.REALISASI_ON_TOP_TPB
                                      + DR.REALISASI_MF_PB)
                                   - DR.AMOUNT_KOMBINASI_BUDGET > 0
                               AND DR.REALISASI_ON_TOP_TPB > 0
                          THEN
                             DR.AMOUNT_KOMBINASI_BUDGET - DR.REALISASI_MF_PB
                          ELSE
                             DR.REALISASI_ON_TOP_TPB
                       END,
                       0)
               ELSE
                  0
            END
             REM_OT_TPB,
            (  DR.MF_PB
             - NVL (
                  CASE
                     WHEN     DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET <
                                 1
                          AND DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET >
                                 0
                     THEN
                        DR.AMOUNT_KOMBINASI_BUDGET
                     ELSE
                        DR.REALISASI_MF_PB
                  END,
                  0))
          - CASE
               WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    DR.MF_PB
                  - NVL (
                       CASE
                          WHEN     DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET <
                                      1
                               AND   DR.REALISASI_MF_PB
                                   - DR.AMOUNT_KOMBINASI_BUDGET > 0
                          THEN
                             DR.AMOUNT_KOMBINASI_BUDGET
                          ELSE
                             DR.REALISASI_MF_PB
                       END,
                       0)
               ELSE
                  0
            END
             REM_MF_PB,
            DR.ON_TOP_TPB
          - CASE
               WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    DR.ON_TOP_TPB
                  - NVL (
                       CASE
                          WHEN       (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                                   - DR.AMOUNT_KOMBINASI_BUDGET < 1
                               AND   (  DR.REALISASI_ON_TOP_TPB
                                      + DR.REALISASI_MF_PB)
                                   - DR.AMOUNT_KOMBINASI_BUDGET > 0
                               AND DR.REALISASI_ON_TOP_TPB > 0
                          THEN
                             DR.AMOUNT_KOMBINASI_BUDGET - DR.REALISASI_MF_PB
                          ELSE
                             DR.REALISASI_ON_TOP_TPB
                       END,
                       0)
               ELSE
                  0
            END
             NET_ON_TOP_TPB,
            DR.MF_PB
          - CASE
               WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    DR.MF_PB
                  - NVL (
                       CASE
                          WHEN     DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET <
                                      1
                               AND   DR.REALISASI_MF_PB
                                   - DR.AMOUNT_KOMBINASI_BUDGET > 0
                          THEN
                             DR.AMOUNT_KOMBINASI_BUDGET
                          ELSE
                             DR.REALISASI_MF_PB
                       END,
                       0)
               ELSE
                  0
            END
             NET_MF_PB,
          CASE
             WHEN (  (  DR.ON_TOP_TPB
                      - NVL (
                           CASE
                              WHEN       (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                                       - DR.AMOUNT_KOMBINASI_BUDGET < 1
                                   AND   (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                                       - DR.AMOUNT_KOMBINASI_BUDGET > 0
                                   AND DR.REALISASI_ON_TOP_TPB > 0
                              THEN
                                 DR.AMOUNT_KOMBINASI_BUDGET - DR.REALISASI_MF_PB
                              ELSE
                                 DR.REALISASI_ON_TOP_TPB
                           END,
                           0))
                   - CASE
                        WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
                        THEN
                             DR.ON_TOP_TPB
                           - NVL (
                                CASE
                                   WHEN       (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                                            - DR.AMOUNT_KOMBINASI_BUDGET < 1
                                        AND   (DR.REALISASI_ON_TOP_TPB + DR.REALISASI_MF_PB)
                                            - DR.AMOUNT_KOMBINASI_BUDGET > 0
                                        AND DR.REALISASI_ON_TOP_TPB > 0
                                   THEN
                                      DR.AMOUNT_KOMBINASI_BUDGET - DR.REALISASI_MF_PB
                                   ELSE
                                      DR.REALISASI_ON_TOP_TPB
                                END,
                                0)
                        ELSE
                           0
                     END) > 0
             THEN
                'Y'
             ELSE
                'N'
          END
             FLAG_OUTSTD_OT_TPB,
          CASE
             WHEN (  (  DR.MF_PB
                      - NVL (
                           CASE
                              WHEN     DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET <
                                          1
                                   AND DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET >
                                          0
                              THEN
                                 DR.AMOUNT_KOMBINASI_BUDGET
                              ELSE
                                 DR.REALISASI_MF_PB
                           END,
                           0))
                   - CASE
                        WHEN DR.FLAG_CLOSE_CANCEL = 'Y'
                        THEN
                             DR.MF_PB
                           - NVL (
                                CASE
                                   WHEN     DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET <
                                               1
                                        AND DR.REALISASI_MF_PB - DR.AMOUNT_KOMBINASI_BUDGET >
                                               0
                                   THEN
                                      DR.AMOUNT_KOMBINASI_BUDGET
                                   ELSE
                                      DR.REALISASI_MF_PB
                                END,
                                0)
                        ELSE
                           0
                     END) > 0
             THEN
                'Y'
             ELSE
                'N'
          END
             FLAG_OUTSTD_MF_PB
     FROM (  SELECT CASE WHEN PPPC.COMPANY_ID = 'I' THEN 'FDI' ELSE 'FDN' END
                       AS COMPANY,
                    PROD.PROMO_PRODUK_ID,
                    PPPC.REPORT_RUN_NUMBER                 AS PP_RCODE,
                    PPPC.PROPOSAL_ID                       AS PP_ID,
                    PPPC.PROPOSAL_NO                       AS PP_NO,
                    USR.FULL_NAME                          AS REQUESTER,
                    PPPC.USER_TYPE_CREATOR                 AS FLAG_AREA_HO,
                    PPPC.PROPOSAL_DATE                     AS PP_DATE,
                    PPPC.COPY_SOURCE                       AS PP_REFERENCE,
                    PPPC.STATUS                            AS PP_STATUS,
                    PPPC.CONFIRM_NO                        AS PC,
                    PPPC.ADDENDUM_KE                       AS ADDENDUM,
                    PPPC.CONFIRM_DATE                      AS PC_DATE,
                    CASE
                       WHEN PPPC.PR_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.PR_REQUEST_ID
                       WHEN PPPC.MOD_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.MOD_REQUEST_ID
                       ELSE
                          NULL
                    END
                       AS EBS_REQUEST_ID,
                    CASE
                       WHEN PPPC.PR_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.EBS_PR_STATUS
                       WHEN PPPC.MOD_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.EBS_MODIFIER_STATUS
                       ELSE
                          NULL
                    END
                       AS EBS_STATUS,
                    PPPC.PERIODE_PROG_FROM                 AS START_DATE_PROMO,
                    PPPC.PERIODE_PROG_TO                   AS END_DATE_PROMO,
                    TO_CHAR (PPPC.PERIODE_PROG_FROM, 'YYYYMM')
                       AS START_MONTH_PROMO,
                    TO_CHAR (PPPC.PERIODE_PROG_TO, 'YYYYMM') AS END_MONTH_PROMO,
                    TO_CHAR (PPPC.PERIODE_PROG_FROM, 'YYYY') AS YEAR_PROMO,
                    PPPC.DISCOUNT_TYPE                     AS TYPE_PROMO,
                    PPPC.PROG_PROMO                        AS PROGRAM_PROMO,
                    PPPC.MEKANISME_PENAGIHAN               AS FLAG_ON_OFF,
                    PPPC.HIST_TRAN_DT_FROM                 AS START_DATE_HIST,
                    PPPC.HIST_TRAN_DT_TO                   AS END_DATE_HIST,
                    PPPC.STD_STM                           AS HIST_BY,
                    PPPC.KOMPENSASI_DIPEROLEH              AS KOMPENSASI,
                    PPPC.NOTES,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          PCA.REGION_DESC_AREA
                       ELSE
                          PCH.REGION_DESC_HO
                    END
                       CUST_REGION,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          PCA.AREA_DESC_AREA
                       ELSE
                          PCH.AREA_DESC_HO
                    END
                       CUST_AREA,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          PCA.LOC_DESC_AREA
                       ELSE
                          PCH.LOC_DESC_HO
                    END
                       AS CUST_LOC,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          PCA.CUSTOMER_TYPE_AREA
                       ELSE
                          PCH.CUSTOMER_TYPE_HO
                    END
                       AS CUST_TYPE,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          PCA.CUSTGRP_DESC_AREA
                       ELSE
                          PCH.CUSTGRP_DESC_HO
                    END
                       AS CUST_GROUP,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          PCA.CUSTOMER_AREA
                       ELSE
                          PCH.CUSTOMER_HO
                    END
                       AS CUSTOMER,
                    PPPC.PROPOSAL_TYPE
                       AS PROD_CATEGORY_PROMO,
                    PROD.LINE_NO                           AS LINE,
                    PROD.PROMO_PRODUK_ID                   AS LINE_ID,
                    PROD.PRODUCT_APPROVAL
                       AS LINE_FLAG_APPROVAL,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                   PROD.PRODUCT_CATEGORY
                            AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                       AS PROD_CATEGORY,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_CLASS
                            AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                       AS PROD_CLASS,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_BRAND
                            AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                       AS PROD_BRAND,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_EXT
                            AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                       AS PROD_EXTENSION,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_PACK
                            AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                       AS PROD_PACKAGING,
                    (SELECT LISTAGG (VAR."VARIANT_DESC", ', ')
                               WITHIN GROUP (ORDER BY VAR."VARIANT_DESC")
                       FROM FOCUSPP.PRODUK_VARIANT VAR
                      WHERE     VAR.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                            AND VAR."VARIANT_DESC" IS NOT NULL)
                       AS PROD_VARIANT,
                    (SELECT LISTAGG (
                               CONCAT (ITM."PROD_ITEM",
                                       CONCAT (' ', ITM."ITEM_DESC")),
                               ', ')
                            WITHIN GROUP (ORDER BY
                                             CONCAT (
                                                ITM."PROD_ITEM",
                                                CONCAT (' ', ITM."ITEM_DESC")))
                       FROM FOCUSPP.PRODUK_ITEM ITM
                      WHERE     ITM.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                            AND CONCAT (ITM."PROD_ITEM",
                                        CONCAT (' ', ITM."ITEM_DESC"))
                                   IS NOT NULL
                            AND ROWNUM <= 80)
                       AS PRODUCT_DETAIL,
                    PROD.MEKANISME                         AS PROD_MEKANISME,
                    PROD.DESCR
                       AS PROD_DESCRIPTION,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                             POT.TIPE_PERHITUNGAN
                          || '; Qty From '
                          || POT.QTY_FROM
                          || ' To '
                          || POT.QTY_TO
                          || ' Disc By '
                          || (case when pot.TIPE_POTONGAN = 'AMOUNT' then '(Rp ' else '(' end) 
                          || trim(to_char((nvl(pot.DISC_YEARLY,0) + nvl(pot.DISC_NON_YEARLY,0)),'999999999990.00')) 
                          || (case when pot.TIPE_POTONGAN = 'PERCENT' then ' %)' else ')' end ) 
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          BIA.DESCR
                       WHEN     DISCOUNT_TYPE = 'PROMOBARANG'
                            AND ( (SELECT LISTAGG (
                                             BRI."ITEM_DESC",
                                             ', ')
                                          WITHIN GROUP (ORDER BY
                                                           BRI."ITEM_DESC")
                                     FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                                    WHERE     BRI.PROMO_BONUS_ID =
                                                 BNS.PROMO_BONUS_ID
                                          AND BRI."ITEM_DESC" IS NOT NULL
                                          AND ROWNUM <= 80))
                                   IS NULL
                       THEN
                             (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CATEGORY
                                     AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CLASS
                                     AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_BRAND
                                     AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_EXT
                                     AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_PACK
                                     AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                          || ' - '
                          || (SELECT LISTAGG (BRV."VARIANT_DESC", ', ')
                                     WITHIN GROUP (ORDER BY BRV."VARIANT_DESC")
                                FROM FOCUSPP.PROMO_BONUS_VARIANT BRV
                               WHERE     BRV.PROMO_BONUS_ID =
                                            BNS.PROMO_BONUS_ID
                                     AND BRV."VARIANT_DESC" IS NOT NULL)
                          || ' - Qty: '
                          || BNS.QTY_FROM
                          || ' '
                          || BNS.UOM
                          || ' @ Rp. '
                          || BNS.PRICE_VAL
                       WHEN     DISCOUNT_TYPE = 'PROMOBARANG'
                            AND ( (SELECT LISTAGG (
                                             BRI."ITEM_DESC",
                                             ', ')
                                          WITHIN GROUP (ORDER BY
                                                           BRI."ITEM_DESC")
                                     FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                                    WHERE     BRI.PROMO_BONUS_ID =
                                                 BNS.PROMO_BONUS_ID
                                          AND BRI."ITEM_DESC" IS NOT NULL
                                          AND ROWNUM <= 80))
                                   IS NOT NULL
                       THEN
                             (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CATEGORY
                                     AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CLASS
                                     AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_BRAND
                                     AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_EXT
                                     AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_PACK
                                     AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                          || ' - '
                          || (SELECT LISTAGG (BRV."VARIANT_DESC", ', ')
                                     WITHIN GROUP (ORDER BY BRV."VARIANT_DESC")
                                FROM FOCUSPP.PROMO_BONUS_VARIANT BRV
                               WHERE     BRV.PROMO_BONUS_ID =
                                            BNS.PROMO_BONUS_ID
                                     AND BRV."VARIANT_DESC" IS NOT NULL)
                          || ' - '
                          || (SELECT LISTAGG (BRI."ITEM_DESC", ', ')
                                        WITHIN GROUP (ORDER BY BRI."ITEM_DESC")
                                FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                               WHERE     BRI.PROMO_BONUS_ID =
                                            BNS.PROMO_BONUS_ID
                                     AND BRI."ITEM_DESC" IS NOT NULL
                                     AND ROWNUM <= 80)
                          || ' - Qty: '
                          || BNS.QTY_FROM
                          || ' '
                          || BNS.UOM
                          || ' @ Rp. '
                          || BNS.PRICE_VAL
                       ELSE
                          NULL
                    END
                       AS DETIL_PROMO,
                    TGT.AVG_QTY                            AS QTY_AVG_SALES,
                    TGT.QTY                                AS QTY_TARGET,
                    TGT.UOM                                AS UOM_QTY_TARGET,
                    TGT.PRICE                              AS UNIT_PRICE,
                    TGT.VALUE                              AS VALUE_TARGET,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_ON_TOP
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_ONTOP
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_ON_TOP
                       ELSE
                          NULL
                    END
                       AS ON_TOP_TPB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_MF
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_MF
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_MF
                       ELSE
                          NULL
                    END
                       AS MF_PB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_RASIO_ON_TOP
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_RASION_ONTOP
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_RASIO_ON_TOP
                       ELSE
                          NULL
                    END
                       AS RASIO_ON_TOP_TPB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_RASIO_MF
                       ELSE
                          NULL
                    END
                       AS RASIO_MF_PB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_RASIO_ON_TOP + PROD.DISC_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_RASION_ONTOP + PROD.BIA_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_RASIO_ON_TOP + PROD.BRG_BONUS_RASIO_MF
                       ELSE
                          NULL
                    END
                       AS TOTAL_RASIO,
                    (SELECT PROD.KODE_POSTING || ' ' || UPPER (msi.DESCRIPTION)
                       FROM APPS.mtl_system_items_b msi
                      WHERE     1 = 1
                            AND msi.item_type = 'PST'
                            AND msi.segment1 = PROD.KODE_POSTING
                            AND ROWNUM = 1)
                       AS POSTING_ON_TOP_TPB,
                    (SELECT    PROD.KODE_POSTING_MF
                            || ' '
                            || UPPER (msi.DESCRIPTION)
                       FROM APPS.mtl_system_items_b msi
                      WHERE     1 = 1
                            AND msi.item_type = 'PST'
                            AND msi.segment1 = PROD.KODE_POSTING_MF
                            AND ROWNUM = 1)
                       AS POSTING_MF_PB,
                    (SELECT PROD.ITEM_EXPENSE || ' ' || UPPER (msi.DESCRIPTION)
                       FROM APPS.mtl_system_items_b msi
                      WHERE     1 = 1
                            AND msi.item_type = 'EPR'
                            AND msi.segment1 = PROD.ITEM_EXPENSE
                            AND ROWNUM = 1)
                       AS ITEM_EXPENSE,
                    PBUD.BUDGET_KOMBINASI,
                    PBUD.VALUE_BUDGET_KOMBINASI,
                    PBUD.AMOUNT_KOMBINASI_BUDGET,
                    CASE
                       WHEN     PPPC.DISCOUNT_TYPE = 'POTONGAN'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                          FVRMT.AMOUNT_OT
                       WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
                       THEN
                            NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF = 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                  THEN
                                     FVRD.AMOUNT_CM
                                  WHEN       FVRD.AMOUNT_CM
                                           - PROD.DISC_MF
                                           - PROD.BRG_BONUS_MF
                                           - PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                       FVRD.AMOUNT_CM
                                     - PROD.DISC_MF
                                     - PROD.BRG_BONUS_MF
                                     - PROD.BIA_MF
                                  ELSE
                                     0
                               END,
                               0)
                          + NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF = 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                  THEN
                                     FVRGV.TOTAL
                                  WHEN       FVRGV.TOTAL
                                           - PROD.DISC_MF
                                           - PROD.BRG_BONUS_MF
                                           - PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                       FVRGV.TOTAL
                                     - PROD.DISC_MF
                                     - PROD.BRG_BONUS_MF
                                     - PROD.BIA_MF
                                  ELSE
                                     0
                               END,
                               0)
                       WHEN     PPPC.DISCOUNT_TYPE = 'PROMOBARANG'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                            (PROD.BRG_BONUS_ON_TOP * FVRP.TOTAL)
                          / (PROD.BRG_BONUS_MF + PROD.BRG_BONUS_ON_TOP)
                       ELSE
                          NULL
                    END
                       AS REALISASI_ON_TOP_TPB,
                    CASE
                       WHEN     PPPC.DISCOUNT_TYPE = 'POTONGAN'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                          FVRMT.AMOUNT_MF
                       WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
                       THEN
                            NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP = 0
                                  THEN
                                     FVRD.AMOUNT_CM
                                  WHEN       PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                       AND FVRD.AMOUNT_CM > 0
                                  THEN
                                     CASE
                                        WHEN   FVRD.AMOUNT_CM
                                             - PROD.DISC_MF
                                             - PROD.BRG_BONUS_MF
                                             - PROD.BIA_MF < 0
                                        THEN
                                           FVRD.AMOUNT_CM
                                        ELSE
                                             PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF
                                     END
                                  ELSE
                                     FVRD.AMOUNT_CM
                               END,
                               0)
                          + NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP = 0
                                  THEN
                                     FVRGV.TOTAL
                                  WHEN       PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                     CASE
                                        WHEN   FVRGV.TOTAL
                                             - PROD.DISC_MF
                                             - PROD.BRG_BONUS_MF
                                             - PROD.BIA_MF < 0
                                        THEN
                                           FVRGV.TOTAL
                                        ELSE
                                             PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF
                                     END
                                  ELSE
                                     0
                               END,
                               0)
                       WHEN     PPPC.DISCOUNT_TYPE = 'PROMOBARANG'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                            (PROD.BRG_BONUS_MF * FVRP.TOTAL)
                          / (PROD.BRG_BONUS_MF + PROD.BRG_BONUS_ON_TOP)
                       ELSE
                          NULL
                    END
                       AS REALISASI_MF_PB,
                    CASE
                       WHEN PPPC.STATUS IN ('CANCELED', 'CLOSED') THEN 'Y'
                       ELSE 'N'
                    END
                       AS FLAG_CLOSE_CANCEL,
                    PPPC.LAST_UPDATED_BY                   AS CLOSE_CANCEL_BY,
                    PPPC.LAST_UPDATE_DATE
                       AS CLOSE_CANCEL_DATE,
                    FVRD.AMOUNT_CM,
                    PCA.CUSTOMER_AREA,
                    PCH.CUSTOMER_HO
               --        FVRGV.TOTAL AS REALISASI_GR,
               --        FVRMT.AMOUNT_MF AS REALISASI_MODIFIER_MF,
               --        FVRMT.AMOUNT_OT AS REALISASI_MODIFIER_OT
               FROM FOCUSPP.PROPOSAL              PPPC,
                    (SELECT ROW_NUMBER ()
                            OVER (PARTITION BY pp.proposal_id
                                  ORDER BY pp.proposal_id, pp.PROMO_PRODUK_ID)
                               AS LINE_NO,
                            pp.*
                       FROM FOCUSPP.PROMO_PRODUK pp) PROD,
                    FOCUSPP.APP_USER_ACCESS       USR,
                    FOCUSPP.TARGET                TGT,
                    FOCUSPP.PROMO_BONUS           BNS,
                    FOCUSPP.BIAYA                 BIA,
                    FOCUSPP.DISCOUNT              POT,
--                    (  SELECT PROMO_PRODUK_ID,
--                              LISTAGG (KOMBINASI_BUDGET, ',')
--                                 WITHIN GROUP (ORDER BY BUDGET_BY_ID DESC)
--                                 AS BUDGET_KOMBINASI,
--                              LISTAGG (AMOUNT, ',')
--                                 WITHIN GROUP (ORDER BY BUDGET_BY_ID DESC)
--                                 AS VALUE_BUDGET_KOMBINASI,
--                              SUM (AMOUNT) AS AMOUNT_KOMBINASI_BUDGET
--                         FROM FOCUSPP.PROD_BUDGET_BY
--                     GROUP BY PROMO_PRODUK_ID) PBUD,
                    (SELECT PROMO_PRODUK_ID,
                          KOMBINASI_BUDGET AS BUDGET_KOMBINASI,
                          AMOUNT AS VALUE_BUDGET_KOMBINASI,
                          AMOUNT AS AMOUNT_KOMBINASI_BUDGET
                        FROM FOCUSPP.PROD_BUDGET_BY
                    ) PBUD,
                    --PROMO CUSTOMER AREA
                    (  SELECT PROPOSAL_ID,
                              LISTAGG (CUSTTYP_DESC, ', ')
                                 WITHIN GROUP (ORDER BY CUSTTYP_DESC)
                                 CUSTOMER_TYPE_AREA,
                              LISTAGG (CUSTOMER_NAME, ', ')
                                 WITHIN GROUP (ORDER BY CUSTOMER_NAME)
                                 CUSTOMER_AREA,
                              LISTAGG (REGION_DESC, ', ')
                                 WITHIN GROUP (ORDER BY REGION_DESC)
                                 REGION_DESC_AREA,
                              LISTAGG (AREA_DESC, ', ')
                                 WITHIN GROUP (ORDER BY AREA_DESC)
                                 AREA_DESC_AREA,
                              LISTAGG (LOC_DESC, ', ')
                                 WITHIN GROUP (ORDER BY LOC_DESC)
                                 LOC_DESC_AREA,
                              LISTAGG (CUSTGRP_DESC, ', ')
                                 WITHIN GROUP (ORDER BY CUSTGRP_DESC)
                                 CUSTGRP_DESC_AREA
                         FROM FOCUSPP.PROMO_CUSTOMER_AREA
                     GROUP BY PROPOSAL_ID) PCA,
                    --PROMO CUSTOMER HO
                    (  SELECT PROMO_PRODUK_ID,
                              LISTAGG (CUSTTYP_DESC, ', ')
                                 WITHIN GROUP (ORDER BY CUSTTYP_DESC)
                                 CUSTOMER_TYPE_HO,
                              LISTAGG (CUSTOMER_NAME, ', ')
                                 WITHIN GROUP (ORDER BY CUSTOMER_NAME)
                                 CUSTOMER_HO,
                              LISTAGG (REGION_DESC, ', ')
                                 WITHIN GROUP (ORDER BY REGION_DESC)
                                 REGION_DESC_HO,
                              LISTAGG (AREA_DESC, ', ')
                                 WITHIN GROUP (ORDER BY AREA_DESC)
                                 AREA_DESC_HO,
                              LISTAGG (LOC_DESC, ', ')
                                 WITHIN GROUP (ORDER BY LOC_DESC)
                                 LOC_DESC_HO,
                              LISTAGG (CUSTGRP_DESC, ', ')
                                 WITHIN GROUP (ORDER BY CUSTGRP_DESC)
                                 CUSTGRP_DESC_HO
                         FROM FOCUSPP.PROMO_CUSTOMER_HO
                     GROUP BY PROMO_PRODUK_ID) PCH,
                    (  SELECT ATTRIBUTE2, SUM (TOTAL) TOTAL
                         FROM APPS.FCS_VIEW_REALISASI_GR_VR
                     GROUP BY ATTRIBUTE2) FVRGV,
                    (  SELECT LINE_NO,
                              MAX (CONFIRM_NO) CONFIRM_NO,
                              SUM (MF)     AMOUNT_MF,
                              SUM (OT)     AMOUNT_OT
                         FROM (SELECT FVRM.PROPOSAL_ID,
                                      FVRM.PROPOSAL_NO,
                                      FVRM.CONFIRM_NO,
                                      FVRM.CONFIRM_NO_ORIG,
                                      FVRM.PROMO_PRODUK_ID,
                                      FVRM.LINE_NO,
                                      FVRM.AMOUNT OT,
                                      0       MF
                                 FROM APPS.FCS_VIEW_REALISASI_MODIFIER FVRM
                                WHERE KET = 'OT'
                               UNION ALL
                               SELECT FVRM.PROPOSAL_ID,
                                      FVRM.PROPOSAL_NO,
                                      FVRM.CONFIRM_NO,
                                      FVRM.CONFIRM_NO_ORIG,
                                      FVRM.PROMO_PRODUK_ID,
                                      FVRM.LINE_NO,
                                      0       OT,
                                      FVRM.AMOUNT MF
                                 FROM APPS.FCS_VIEW_REALISASI_MODIFIER FVRM
                                WHERE KET = 'MF')
                        WHERE 1 = 1
                     GROUP BY LINE_NO, CONFIRM_NO_ORIG) FVRMT,
                    APPS.fcs_view_realisasi_promobarang FVRP,
                    (  SELECT ATTRIBUTE7, SUM (AMOUNT_CM) AMOUNT_CM
                         FROM APPS.FCS_VIEW_REALISASI_DCV_VR
                     GROUP BY ATTRIBUTE7) FVRD
              WHERE     PROD.PROPOSAL_ID = PPPC.PROPOSAL_ID
                    AND TGT.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                    AND USR.USER_NAME(+) = PPPC.PEMOHON
                    AND PBUD.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND POT.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND BIA.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND BNS.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND FVRGV.ATTRIBUTE2(+) = PROD.PROMO_PRODUK_ID
                    AND FVRP.PROPOSAL_ID(+) = PPPC.PROPOSAL_ID
                    AND FVRP.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND FVRP.LINE_NO(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRMT.LINE_NO(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRMT.CONFIRM_NO(+) =
                              PPPC.CONFIRM_NO
                           || DECODE (PPPC.ADDENDUM_KE,
                                      NULL, '',
                                      '-' || PPPC.ADDENDUM_KE)
                    AND FVRD.ATTRIBUTE7(+) = PROD.PROMO_PRODUK_ID
                    AND PCA.PROPOSAL_ID(+) = PPPC.PROPOSAL_ID
                    AND PCH.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
           ORDER BY PPPC.PROPOSAL_NO, PROD.LINE_NO) DR
/

