create view FCS_PPPC_VR as
  SELECT LALA.COMPANY,
          LALA.PP_RCODE,
          LALA.PP_ID,
          LALA.PP_NO,
          LALA.REQUESTER,
          LALA.FLAG_AREA_HO,
          LALA.PP_DATE,
          LALA.PP_REFERENCE,
          LALA.PP_STATUS,
          LALA.PC,
          LALA.ADDENDUM,
          LALA.PC_DATE,
          LALA.EBS_REQUEST_ID,
          LALA.EBS_STATUS,
          LALA.START_DATE_PROMO,
          LALA.END_DATE_PROMO,
          LALA.START_MONTH_PROMO,
          LALA.END_MONTH_PROMO,
          LALA.YEAR_PROMO,
          LALA.TYPE_PROMO,
          LALA.PROGRAM_PROMO,
          LALA.FLAG_ON_OFF,
          LALA.START_DATE_HIST,
          LALA.END_DATE_HIST,
          LALA.HIST_BY,
          LALA.KOMPENSASI,
          LALA.NOTES,
          LALA.CUST_REGION,
          LALA.CUST_AREA,
          LALA.CUST_LOC,
          LALA.CUST_TYPE,
          LALA.CUST_GROUP,
          LALA.CUSTOMER,
          LALA.PROD_CATEGORY_PROMO,
          LALA.LINE,
          LALA.LINE_ID,
          LALA.LINE_FLAG_APPROVAL,
          LALA.PROD_CATEGORY,
          LALA.PROD_CLASS,
          LALA.PROD_BRAND,
          LALA.PROD_EXTENSION,
          LALA.PROD_PACKAGING,
          LALA.PROD_VARIANT,
          LALA.PRODUCT_DETAIL,
          LALA.PROD_MEKANISME,
          LALA.PROD_DESCRIPTION,
          LALA.DETIL_PROMO,
          LALA.QTY_AVG_SALES,
          LALA.QTY_TARGET,
          LALA.UOM_QTY_TARGET,
          LALA.UNIT_PRICE,
          LALA.VALUE_TARGET,
          CASE
             WHEN LALA.TYPE_PROMO <> 'BIAYA'
             THEN
                ROUND (LALA.ON_TOP_TPB / LALA.QTY_TARGET, 2)
             ELSE
                0
          END
             ON_TOP_TPB_UOM,
          CASE
             WHEN LALA.TYPE_PROMO <> 'BIAYA'
             THEN
                ROUND (MF_PB / LALA.QTY_TARGET, 2)
             ELSE
                0
          END
             MF_PB_UOM,
          LALA.ON_TOP_TPB,
          LALA.MF_PB,
          LALA.RASIO_ON_TOP_TPB,
          LALA.RASIO_MF_PB,
          LALA.TOTAL_RASIO,
          LALA.POSTING_ON_TOP_TPB,
          LALA.POSTING_MF_PB,
          LALA.ITEM_EXPENSE,
          LALA.BUDGET_KOMBINASI,
          LALA.VALUE_BUDGET_KOMBINASI,
          CASE
             WHEN       (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                      - LALA.VALUE_BUDGET_KOMBINASI < 1
                  AND   (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                      - LALA.VALUE_BUDGET_KOMBINASI > 0
                  AND LALA.REALISASI_ON_TOP_TPB > 0
             THEN
                LALA.VALUE_BUDGET_KOMBINASI - LALA.REALISASI_MF_PB
             ELSE
                LALA.REALISASI_ON_TOP_TPB
          END
             AS REALISASI_ON_TOP_TPB,
          CASE
             WHEN     LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI < 1
                  AND LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI > 0
             THEN
                LALA.VALUE_BUDGET_KOMBINASI
             ELSE
                LALA.REALISASI_MF_PB
          END
             AS REALISASI_MF_PB,
          LALA.FLAG_CLOSE_CANCEL,
          LALA.CLOSE_CANCEL_BY,
          LALA.CLOSE_CANCEL_DATE,
          CASE
             WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
             THEN
                  LALA.ON_TOP_TPB
                - NVL (
                     CASE
                        WHEN       (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                                 - LALA.VALUE_BUDGET_KOMBINASI < 1
                             AND   (  LALA.REALISASI_ON_TOP_TPB
                                    + LALA.REALISASI_MF_PB)
                                 - LALA.VALUE_BUDGET_KOMBINASI > 0
                             AND LALA.REALISASI_ON_TOP_TPB > 0
                        THEN
                           LALA.VALUE_BUDGET_KOMBINASI - LALA.REALISASI_MF_PB
                        ELSE
                           LALA.REALISASI_ON_TOP_TPB
                     END,
                     0)
             ELSE
                NULL
          END
             CLOSE_CANCEL_OT_TPB,
          CASE
             WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
             THEN
                  LALA.MF_PB
                - NVL (
                     CASE
                        WHEN     LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI <
                                    1
                             AND   LALA.REALISASI_MF_PB
                                 - LALA.VALUE_BUDGET_KOMBINASI > 0
                        THEN
                           LALA.VALUE_BUDGET_KOMBINASI
                        ELSE
                           LALA.REALISASI_MF_PB
                     END,
                     0)
             ELSE
                NULL
          END
             CLOSE_CANCEL_MF_PB,
            (  LALA.ON_TOP_TPB
             - NVL (
                  CASE
                     WHEN       (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                              - LALA.VALUE_BUDGET_KOMBINASI < 1
                          AND   (  LALA.REALISASI_ON_TOP_TPB
                                 + LALA.REALISASI_MF_PB)
                              - LALA.VALUE_BUDGET_KOMBINASI > 0
                          AND LALA.REALISASI_ON_TOP_TPB > 0
                     THEN
                        LALA.VALUE_BUDGET_KOMBINASI - LALA.REALISASI_MF_PB
                     ELSE
                        LALA.REALISASI_ON_TOP_TPB
                  END,
                  0))
          - CASE
               WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    LALA.ON_TOP_TPB
                  - NVL (
                       CASE
                          WHEN       (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                                   - LALA.VALUE_BUDGET_KOMBINASI < 1
                               AND   (  LALA.REALISASI_ON_TOP_TPB
                                      + LALA.REALISASI_MF_PB)
                                   - LALA.VALUE_BUDGET_KOMBINASI > 0
                               AND LALA.REALISASI_ON_TOP_TPB > 0
                          THEN
                               LALA.VALUE_BUDGET_KOMBINASI
                             - LALA.REALISASI_MF_PB
                          ELSE
                             LALA.REALISASI_ON_TOP_TPB
                       END,
                       0)
               ELSE
                  0
            END
             REM_OT_TPB,
            (  LALA.MF_PB
             - NVL (
                  CASE
                     WHEN     LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI <
                                 1
                          AND   LALA.REALISASI_MF_PB
                              - LALA.VALUE_BUDGET_KOMBINASI > 0
                     THEN
                        LALA.VALUE_BUDGET_KOMBINASI
                     ELSE
                        LALA.REALISASI_MF_PB
                  END,
                  0))
          - CASE
               WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    LALA.MF_PB
                  - NVL (
                       CASE
                          WHEN     LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI <
                                      1
                               AND   LALA.REALISASI_MF_PB
                                   - LALA.VALUE_BUDGET_KOMBINASI > 0
                          THEN
                             LALA.VALUE_BUDGET_KOMBINASI
                          ELSE
                             LALA.REALISASI_MF_PB
                       END,
                       0)
               ELSE
                  0
            END
             REM_MF_PB,
            LALA.ON_TOP_TPB
          - CASE
               WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    LALA.ON_TOP_TPB
                  - NVL (
                       CASE
                          WHEN       (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                                   - LALA.VALUE_BUDGET_KOMBINASI < 1
                               AND   (  LALA.REALISASI_ON_TOP_TPB
                                      + LALA.REALISASI_MF_PB)
                                   - LALA.VALUE_BUDGET_KOMBINASI > 0
                               AND LALA.REALISASI_ON_TOP_TPB > 0
                          THEN
                               LALA.VALUE_BUDGET_KOMBINASI
                             - LALA.REALISASI_MF_PB
                          ELSE
                             LALA.REALISASI_ON_TOP_TPB
                       END,
                       0)
               ELSE
                  0
            END
             NET_ON_TOP_TPB,
            LALA.MF_PB
          - CASE
               WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
               THEN
                    LALA.MF_PB
                  - NVL (
                       CASE
                          WHEN     LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI <
                                      1
                               AND   LALA.REALISASI_MF_PB
                                   - LALA.VALUE_BUDGET_KOMBINASI > 0
                          THEN
                             LALA.VALUE_BUDGET_KOMBINASI
                          ELSE
                             LALA.REALISASI_MF_PB
                       END,
                       0)
               ELSE
                  0
            END
             NET_MF_PB,
          CASE
             WHEN (  (  LALA.ON_TOP_TPB
                      - NVL (
                           CASE
                              WHEN       (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                                       - LALA.VALUE_BUDGET_KOMBINASI < 1
                                   AND   (LALA.REALISASI_ON_TOP_TPB + LALA.REALISASI_MF_PB)
                                       - LALA.VALUE_BUDGET_KOMBINASI > 0
                                   AND LALA.REALISASI_ON_TOP_TPB > 0
                              THEN
                                 LALA.VALUE_BUDGET_KOMBINASI - LALA.REALISASI_MF_PB
                              ELSE
                                 LALA.REALISASI_ON_TOP_TPB
                           END,
                           0))
                   - CASE
                        WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
                        THEN
                             LALA.ON_TOP_TPB
                           - NVL (
                                CASE
                                   WHEN       (  LALA.REALISASI_ON_TOP_TPB
                                               + LALA.REALISASI_MF_PB)
                                            - LALA.VALUE_BUDGET_KOMBINASI < 1
                                        AND   (  LALA.REALISASI_ON_TOP_TPB
                                               + LALA.REALISASI_MF_PB)
                                            - LALA.VALUE_BUDGET_KOMBINASI > 0
                                        AND LALA.REALISASI_ON_TOP_TPB > 0
                                   THEN
                                      LALA.VALUE_BUDGET_KOMBINASI - LALA.REALISASI_MF_PB
                                   ELSE
                                      LALA.REALISASI_ON_TOP_TPB
                                END,
                                0)
                        ELSE
                           0
                     END) > 0
             THEN
                'Y'
             ELSE
                'N'
          END
             FLAG_OUTSTD_OT_TPB,
          CASE
             WHEN (  (  LALA.MF_PB
                      - NVL (
                           CASE
                              WHEN     LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI <
                                          1
                                   AND LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI >
                                          0
                              THEN
                                 LALA.VALUE_BUDGET_KOMBINASI
                              ELSE
                                 LALA.REALISASI_MF_PB
                           END,
                           0))
                   - CASE
                        WHEN LALA.FLAG_CLOSE_CANCEL = 'Y'
                        THEN
                             LALA.MF_PB
                           - NVL (
                                CASE
                                   WHEN     LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI <
                                               1
                                        AND LALA.REALISASI_MF_PB - LALA.VALUE_BUDGET_KOMBINASI >
                                               0
                                   THEN
                                      LALA.VALUE_BUDGET_KOMBINASI
                                   ELSE
                                      LALA.REALISASI_MF_PB
                                END,
                                0)
                        ELSE
                           0
                     END) > 0
             THEN
                'Y'
             ELSE
                'N'
          END
             FLAG_OUTSTD_MF_PB
     FROM (  SELECT CASE WHEN PPPC.COMPANY_ID = 'I' THEN 'FDI' ELSE 'FDN' END
                       AS COMPANY,
                    PPPC.REPORT_RUN_NUMBER                 AS PP_RCODE,
                    PPPC.PROPOSAL_ID                       AS PP_ID,
                    PPPC.PROPOSAL_NO                       AS PP_NO,
                    USR.FULL_NAME                          AS REQUESTER,
                    PPPC.USER_TYPE_CREATOR                 AS FLAG_AREA_HO,
                    PPPC.PROPOSAL_DATE                     AS PP_DATE,
                    PPPC.COPY_SOURCE                       AS PP_REFERENCE,
                    PPPC.STATUS                            AS PP_STATUS,
                    PPPC.CONFIRM_NO                        AS PC,
                    PPPC.ADDENDUM_KE                       AS ADDENDUM,
                    PPPC.CONFIRM_DATE                      AS PC_DATE,
                    CASE
                       WHEN PPPC.PR_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.PR_REQUEST_ID
                       WHEN PPPC.MOD_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.MOD_REQUEST_ID
                       ELSE
                          NULL
                    END
                       AS EBS_REQUEST_ID,
                    CASE
                       WHEN PPPC.PR_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.EBS_PR_STATUS
                       WHEN PPPC.MOD_REQUEST_ID IS NOT NULL
                       THEN
                          PPPC.EBS_MODIFIER_STATUS
                       ELSE
                          NULL
                    END
                       AS EBS_STATUS,
                    PPPC.PERIODE_PROG_FROM                 AS START_DATE_PROMO,
                    PPPC.PERIODE_PROG_TO                   AS END_DATE_PROMO,
                    TO_CHAR (PPPC.PERIODE_PROG_FROM, 'YYYYMM')
                       AS START_MONTH_PROMO,
                    TO_CHAR (PPPC.PERIODE_PROG_TO, 'YYYYMM') AS END_MONTH_PROMO,
                    TO_CHAR (PPPC.PERIODE_PROG_FROM, 'YYYY') AS YEAR_PROMO,
                    PPPC.DISCOUNT_TYPE                     AS TYPE_PROMO,
                    PPPC.PROG_PROMO                        AS PROGRAM_PROMO,
                    PPPC.MEKANISME_PENAGIHAN               AS FLAG_ON_OFF,
                    PPPC.HIST_TRAN_DT_FROM                 AS START_DATE_HIST,
                    PPPC.HIST_TRAN_DT_TO                   AS END_DATE_HIST,
                    PPPC.STD_STM                           AS HIST_BY,
                    PPPC.KOMPENSASI_DIPEROLEH              AS KOMPENSASI,
                    PPPC.NOTES,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          (SELECT LISTAGG (CREG.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CREG.DESCRIPTION)
                             FROM (SELECT b.PROMO_PRODUK_ID,
                                          a.REGION_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                          FOCUSPP.PROMO_PRODUK      b
                                    WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CREG
                            WHERE     CREG.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CREG."DESCRIPTION" IS NOT NULL)
                       ELSE
                          (SELECT LISTAGG (CREG.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CREG.DESCRIPTION)
                             FROM (SELECT a.PROMO_PRODUK_ID,
                                          a.REGION_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_HO a) CREG
                            WHERE     CREG.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CREG."DESCRIPTION" IS NOT NULL)
                    END
                       AS CUST_REGION,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          (SELECT LISTAGG (CAREA.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CAREA.DESCRIPTION)
                             FROM (SELECT b.PROMO_PRODUK_ID,
                                          a.AREA_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                          FOCUSPP.PROMO_PRODUK      b
                                    WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CAREA
                            WHERE     CAREA.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CAREA."DESCRIPTION" IS NOT NULL)
                       ELSE
                          (SELECT LISTAGG (CAREA.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CAREA.DESCRIPTION)
                             FROM (SELECT a.PROMO_PRODUK_ID,
                                          a.AREA_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_HO a) CAREA
                            WHERE     CAREA.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CAREA."DESCRIPTION" IS NOT NULL)
                    END
                       AS CUST_AREA,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          (SELECT LISTAGG (CLOC.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CLOC.DESCRIPTION)
                             FROM (SELECT b.PROMO_PRODUK_ID,
                                          a.LOC_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                          FOCUSPP.PROMO_PRODUK      b
                                    WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CLOC
                            WHERE     CLOC.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CLOC."DESCRIPTION" IS NOT NULL)
                       ELSE
                          (SELECT LISTAGG (CLOC.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CLOC.DESCRIPTION)
                             FROM (SELECT a.PROMO_PRODUK_ID,
                                          a.LOC_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_HO a) CLOC
                            WHERE     CLOC.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CLOC."DESCRIPTION" IS NOT NULL)
                    END
                       AS CUST_LOC,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          (SELECT LISTAGG (CTYPE.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CTYPE.DESCRIPTION)
                             FROM (SELECT b.PROMO_PRODUK_ID,
                                          a.CUSTTYP_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                          FOCUSPP.PROMO_PRODUK      b
                                    WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CTYPE
                            WHERE     CTYPE.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CTYPE."DESCRIPTION" IS NOT NULL)
                       ELSE
                          (SELECT LISTAGG (CTYPE.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CTYPE.DESCRIPTION)
                             FROM (SELECT a.PROMO_PRODUK_ID,
                                          a.CUSTTYP_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_HO a) CTYPE
                            WHERE     CTYPE.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CTYPE."DESCRIPTION" IS NOT NULL)
                    END
                       AS CUST_TYPE,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          (SELECT LISTAGG (CGROUP.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CGROUP.DESCRIPTION)
                             FROM (SELECT b.PROMO_PRODUK_ID,
                                          a.CUSTGRP_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                          FOCUSPP.PROMO_PRODUK      b
                                    WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CGROUP
                            WHERE     CGROUP.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CGROUP."DESCRIPTION" IS NOT NULL)
                       ELSE
                          (SELECT LISTAGG (CGROUP.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CGROUP.DESCRIPTION)
                             FROM (SELECT a.PROMO_PRODUK_ID,
                                          a.CUSTGRP_DESC AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_HO a) CGROUP
                            WHERE     CGROUP.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CGROUP."DESCRIPTION" IS NOT NULL)
                    END
                       AS CUST_GROUP,
                    CASE
                       WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
                       THEN
                          (SELECT LISTAGG (CCUST.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CCUST.DESCRIPTION)
                             FROM (SELECT b.PROMO_PRODUK_ID,
                                          a.CUSTOMER_NAME AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                          FOCUSPP.PROMO_PRODUK      b
                                    WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CCUST
                            WHERE     CCUST.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CCUST."DESCRIPTION" IS NOT NULL)
                       ELSE
                          (SELECT LISTAGG (CCUST.DESCRIPTION, ', ')
                                     WITHIN GROUP (ORDER BY CCUST.DESCRIPTION)
                             FROM (SELECT a.PROMO_PRODUK_ID,
                                          a.CUSTOMER_NAME AS DESCRIPTION
                                     FROM FOCUSPP.PROMO_CUSTOMER_HO a) CCUST
                            WHERE     CCUST.PROMO_PRODUK_ID =
                                         PROD.PROMO_PRODUK_ID
                                  AND CCUST."DESCRIPTION" IS NOT NULL)
                    END
                       AS CUSTOMER,
                    PPPC.PROPOSAL_TYPE
                       AS PROD_CATEGORY_PROMO,
                    PROD.LINE_NO                           AS LINE,
                    PROD.PROMO_PRODUK_ID                   AS LINE_ID,
                    PROD.PRODUCT_APPROVAL
                       AS LINE_FLAG_APPROVAL,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                   PROD.PRODUCT_CATEGORY
                            AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                       AS PROD_CATEGORY,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_CLASS
                            AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                       AS PROD_CLASS,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_BRAND
                            AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                       AS PROD_BRAND,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_EXT
                            AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                       AS PROD_EXTENSION,
                    (SELECT MCV.DESCRIPTION
                       FROM APPS.MTL_CATEGORIES_V MCV
                      WHERE     MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_PACK
                            AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                       AS PROD_PACKAGING,
                    (SELECT LISTAGG (VAR."VARIANT_DESC", ', ')
                               WITHIN GROUP (ORDER BY VAR."VARIANT_DESC")
                       FROM FOCUSPP.PRODUK_VARIANT VAR
                      WHERE     VAR.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                            AND VAR."VARIANT_DESC" IS NOT NULL)
                       AS PROD_VARIANT,
                    (SELECT LISTAGG (
                               CONCAT (ITM."PROD_ITEM",
                                       CONCAT (' ', ITM."ITEM_DESC")),
                               ', ')
                            WITHIN GROUP (ORDER BY
                                             CONCAT (
                                                ITM."PROD_ITEM",
                                                CONCAT (' ', ITM."ITEM_DESC")))
                       FROM FOCUSPP.PRODUK_ITEM ITM
                      WHERE     ITM.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                            AND CONCAT (ITM."PROD_ITEM",
                                        CONCAT (' ', ITM."ITEM_DESC"))
                                   IS NOT NULL
                            AND ROWNUM <= 80)
                       AS PRODUCT_DETAIL,
                    PROD.MEKANISME                         AS PROD_MEKANISME,
                    PROD.DESCR
                       AS PROD_DESCRIPTION,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                             pot.TIPE_PERHITUNGAN
                          || '; Qty From '
                          || pot.QTY_FROM
                          || ' To '
                          || pot.QTY_TO
                          || ' Disc By '
                          || (CASE
                                 WHEN pot.TIPE_POTONGAN = 'AMOUNT' THEN '(Rp '
                                 ELSE '('
                              END)
                          || TRIM (
                                TO_CHAR (
                                   (  NVL (pot.DISC_YEARLY, 0)
                                    + NVL (pot.DISC_NON_YEARLY, 0)),
                                   '999999999990.00'))
                          || (CASE
                                 WHEN pot.TIPE_POTONGAN = 'PERCENT' THEN ' %)'
                                 ELSE ')'
                              END)
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          BIA.DESCR
                       WHEN     DISCOUNT_TYPE = 'PROMOBARANG'
                            AND ( (SELECT LISTAGG (
                                             BRI."ITEM_DESC",
                                             ', ')
                                          WITHIN GROUP (ORDER BY
                                                           BRI."ITEM_DESC")
                                     FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                                    WHERE     BRI.PROMO_BONUS_ID =
                                                 BNS.PROMO_BONUS_ID
                                          AND BRI."ITEM_DESC" IS NOT NULL
                                          AND ROWNUM <= 80))
                                   IS NULL
                       THEN
                             (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CATEGORY
                                     AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CLASS
                                     AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_BRAND
                                     AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_EXT
                                     AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_PACK
                                     AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                          || ' - '
                          || (SELECT LISTAGG (BRV."VARIANT_DESC", ', ')
                                     WITHIN GROUP (ORDER BY BRV."VARIANT_DESC")
                                FROM FOCUSPP.PROMO_BONUS_VARIANT BRV
                               WHERE     BRV.PROMO_BONUS_ID =
                                            BNS.PROMO_BONUS_ID
                                     AND BRV."VARIANT_DESC" IS NOT NULL)
                          || ' - Qty: '
                          || BNS.QTY_FROM
                          || ' '
                          || BNS.UOM
                          || ' @ Rp. '
                          || BNS.PRICE_VAL
                       WHEN     DISCOUNT_TYPE = 'PROMOBARANG'
                            AND ( (SELECT LISTAGG (
                                             BRI."ITEM_DESC",
                                             ', ')
                                          WITHIN GROUP (ORDER BY
                                                           BRI."ITEM_DESC")
                                     FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                                    WHERE     BRI.PROMO_BONUS_ID =
                                                 BNS.PROMO_BONUS_ID
                                          AND BRI."ITEM_DESC" IS NOT NULL
                                          AND ROWNUM <= 80))
                                   IS NOT NULL
                       THEN
                             (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CATEGORY
                                     AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_CLASS
                                     AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_BRAND
                                     AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_EXT
                                     AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                          || ' - '
                          || (SELECT MCV.DESCRIPTION
                                FROM APPS.MTL_CATEGORIES_V MCV
                               WHERE     MCV.CATEGORY_CONCAT_SEGS =
                                            BNS.PRODUCT_PACK
                                     AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                          || ' - '
                          || (SELECT LISTAGG (BRV."VARIANT_DESC", ', ')
                                     WITHIN GROUP (ORDER BY BRV."VARIANT_DESC")
                                FROM FOCUSPP.PROMO_BONUS_VARIANT BRV
                               WHERE     BRV.PROMO_BONUS_ID =
                                            BNS.PROMO_BONUS_ID
                                     AND BRV."VARIANT_DESC" IS NOT NULL)
                          || ' - '
                          || (SELECT LISTAGG (BRI."ITEM_DESC", ', ')
                                        WITHIN GROUP (ORDER BY BRI."ITEM_DESC")
                                FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                               WHERE     BRI.PROMO_BONUS_ID =
                                            BNS.PROMO_BONUS_ID
                                     AND BRI."ITEM_DESC" IS NOT NULL
                                     AND ROWNUM <= 80)
                          || ' - Qty: '
                          || BNS.QTY_FROM
                          || ' '
                          || BNS.UOM
                          || ' @ Rp. '
                          || BNS.PRICE_VAL
                       ELSE
                          NULL
                    END
                       AS DETIL_PROMO,
                    TGT.AVG_QTY                            AS QTY_AVG_SALES,
                    TGT.QTY                                AS QTY_TARGET,
                    TGT.UOM                                AS UOM_QTY_TARGET,
                    TGT.PRICE                              AS UNIT_PRICE,
                    TGT.VALUE                              AS VALUE_TARGET,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_ON_TOP
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_ONTOP
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_ON_TOP
                       ELSE
                          NULL
                    END
                       AS ON_TOP_TPB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_MF
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_MF
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_MF
                       ELSE
                          NULL
                    END
                       AS MF_PB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_RASIO_ON_TOP
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_RASION_ONTOP
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_RASIO_ON_TOP
                       ELSE
                          NULL
                    END
                       AS RASIO_ON_TOP_TPB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_RASIO_MF
                       ELSE
                          NULL
                    END
                       AS RASIO_MF_PB,
                    CASE
                       WHEN DISCOUNT_TYPE = 'POTONGAN'
                       THEN
                          PROD.DISC_RASIO_ON_TOP + PROD.DISC_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'BIAYA'
                       THEN
                          PROD.BIA_RASION_ONTOP + PROD.BIA_RASIO_MF
                       WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                       THEN
                          PROD.BRG_BONUS_RASIO_ON_TOP + PROD.BRG_BONUS_RASIO_MF
                       ELSE
                          NULL
                    END
                       AS TOTAL_RASIO,
                    (SELECT PROD.KODE_POSTING || ' ' || UPPER (msi.DESCRIPTION)
                       FROM APPS.FCS_INV_VIEW_MSTR_ITEM msi
                      WHERE     1 = 1
                            AND msi.item_type = 'PST'
                            AND msi.item = PROD.KODE_POSTING)
                       AS POSTING_ON_TOP_TPB,
                    (SELECT    PROD.KODE_POSTING_MF
                            || ' '
                            || UPPER (msi.DESCRIPTION)
                       FROM APPS.FCS_INV_VIEW_MSTR_ITEM msi
                      WHERE     1 = 1
                            AND msi.item_type = 'PST'
                            AND msi.item = PROD.KODE_POSTING_MF)
                       AS POSTING_MF_PB,
                    (SELECT PROD.ITEM_EXPENSE || ' ' || UPPER (msi.DESCRIPTION)
                       FROM APPS.FCS_INV_VIEW_MSTR_ITEM msi
                      WHERE     1 = 1
                            AND msi.item_type = 'EPR'
                            AND msi.item = PROD.ITEM_EXPENSE)
                       AS ITEM_EXPENSE,
                    PBUD.KOMBINASI_BUDGET
                       AS BUDGET_KOMBINASI,
                    PBUD.AMOUNT
                       AS VALUE_BUDGET_KOMBINASI,
                    CASE
                       WHEN     PPPC.DISCOUNT_TYPE = 'POTONGAN'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                          FVRMT.AMOUNT_OT
                       WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
                       THEN
                            NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF = 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                  THEN
                                     FVRD.AMOUNT_CM
                                  WHEN       FVRD.AMOUNT_CM
                                           - PROD.DISC_MF
                                           - PROD.BRG_BONUS_MF
                                           - PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                       FVRD.AMOUNT_CM
                                     - PROD.DISC_MF
                                     - PROD.BRG_BONUS_MF
                                     - PROD.BIA_MF
                                  ELSE
                                     0
                               END,
                               0)
                          + NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF = 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                  THEN
                                     FVRG.TOTAL
                                  WHEN       FVRG.TOTAL
                                           - PROD.DISC_MF
                                           - PROD.BRG_BONUS_MF
                                           - PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                       FVRG.TOTAL
                                     - PROD.DISC_MF
                                     - PROD.BRG_BONUS_MF
                                     - PROD.BIA_MF
                                  ELSE
                                     0
                               END,
                               0)
                       WHEN     PPPC.DISCOUNT_TYPE = 'PROMOBARANG'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                            (PROD.BRG_BONUS_ON_TOP * FVRP.TOTAL)
                          / (PROD.BRG_BONUS_MF + PROD.BRG_BONUS_ON_TOP)
                       ELSE
                          NULL
                    END
                       AS REALISASI_ON_TOP_TPB,
                    CASE
                       WHEN     PPPC.DISCOUNT_TYPE = 'POTONGAN'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                          FVRMT.AMOUNT_MF
                       WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
                       THEN
                            NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP = 0
                                  THEN
                                     FVRD.AMOUNT_CM
                                  WHEN       PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                       AND FVRD.AMOUNT_CM > 0
                                  THEN
                                     CASE
                                        WHEN   FVRD.AMOUNT_CM
                                             - PROD.DISC_MF
                                             - PROD.BRG_BONUS_MF
                                             - PROD.BIA_MF < 0
                                        THEN
                                           FVRD.AMOUNT_CM
                                        ELSE
                                             PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF
                                     END
                                  ELSE
                                     FVRD.AMOUNT_CM
                               END,
                               0)
                          + NVL (
                               CASE
                                  WHEN       PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP = 0
                                  THEN
                                     FVRG.TOTAL
                                  WHEN       PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                     CASE
                                        WHEN   FVRG.TOTAL
                                             - PROD.DISC_MF
                                             - PROD.BRG_BONUS_MF
                                             - PROD.BIA_MF < 0
                                        THEN
                                           FVRG.TOTAL
                                        ELSE
                                             PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF
                                     END
                                  ELSE
                                     0
                               END,
                               0)
                       WHEN     PPPC.DISCOUNT_TYPE = 'PROMOBARANG'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                            (PROD.BRG_BONUS_MF * FVRP.TOTAL)
                          / (PROD.BRG_BONUS_MF + PROD.BRG_BONUS_ON_TOP)
                       ELSE
                          NULL
                    END
                       AS REALISASI_MF_PB,
                    --                CASE
                    --                  WHEN FVRG.TOTAL - PBUD.AMOUNT < 1 AND FVRG.TOTAL - PBUD.AMOUNT > 0
                    --                   THEN FVRG.TOTAL - PBUD.AMOUNT
                    --                  ELSE 0
                    --                END AS PEMBULATAN_REALISASI,
                    CASE
                       WHEN PPPC.STATUS IN ('CANCELED', 'CLOSED') THEN 'Y'
                       ELSE 'N'
                    END
                       AS FLAG_CLOSE_CANCEL,
                    PPPC.last_updated_by                   AS CLOSE_CANCEL_BY,
                    PPPC.last_update_date
                       AS CLOSE_CANCEL_DATE,
                    NULL
                       AS CLOSE_CANCEL_OT_TPB,
                    NULL
                       AS CLOSE_CANCEL_MF_PB,
                    NULL
                       AS CLOSE_CANCEL_REM_OT_TPB,
                    NULL
                       AS CLOSE_CANCEL_REM_MF_PB,
                    NULL                                   AS NET_ON_TOP_TPB,
                    NULL                                   AS NET_MF_PB,
                    NULL
                       AS FLAG_OUTSTD_OT_TPB,
                    NULL
                       AS FLAG_OUTSTD_MF_PB
               FROM FOCUSPP.PROPOSAL              PPPC,
                    (SELECT ROW_NUMBER ()
                            OVER (PARTITION BY pp.proposal_id
                                  ORDER BY pp.proposal_id, pp.PROMO_PRODUK_ID)
                               AS LINE_NO,
                            pp.*
                       FROM FOCUSPP.PROMO_PRODUK pp) PROD,
                    FOCUSPP.APP_USER_ACCESS       USR,
                    FOCUSPP.TARGET                TGT,
                    FOCUSPP.DISCOUNT              POT,
                    FOCUSPP.BIAYA                 BIA,
                    FOCUSPP.PROMO_BONUS           BNS,
                    FOCUSPP.PROD_BUDGET_BY        PBUD,
                    APPS.FCS_VIEW_REALISASI_PROMOBARANG FVRP,
                    APPS.FCS_VIEW_REALISASI_GR    FVRG,
                    APPS.FCS_VIEW_REALISASI_DCV   FVRD,
                    (  SELECT LINE_NO,
                              MAX (CONFIRM_NO) CONFIRM_NO,
                              SUM (MF)     AMOUNT_MF,
                              SUM (OT)     AMOUNT_OT
                         FROM ( /*SELECT FVRM.PROPOSAL_ID,
                                       FVRM.PROPOSAL_NO,
                                       FVRM.CONFIRM_NO,
                                       FVRM.CONFIRM_NO_ORIG,
                                       FVRM.PROMO_PRODUK_ID,
                                       FVRM.LINE_NO,
                                       FVRM.AMOUNT OT,
                                       0 MF
                                  FROM APPS.FCS_VIEW_REALISASI_MODIFIER FVRM
                                 WHERE KET = 'OT'
                                UNION ALL
                                SELECT FVRM.PROPOSAL_ID,
                                       FVRM.PROPOSAL_NO,
                                       FVRM.CONFIRM_NO,
                                       FVRM.CONFIRM_NO_ORIG,
                                       FVRM.PROMO_PRODUK_ID,
                                       FVRM.LINE_NO,
                                       0 OT,
                                       FVRM.AMOUNT MF
                                  FROM APPS.FCS_VIEW_REALISASI_MODIFIER FVRM
                                 WHERE KET = 'MF'*/
                               SELECT FVRM.PROPOSAL_ID,
                                      FVRM.PROPOSAL_NO,
                                      FVRM.CONFIRM_NO,
                                      FVRM.CONFIRM_NO_ORIG,
                                      FVRM.PROMO_PRODUK_ID,
                                      FVRM.LINE_NO,
                                      DECODE (KET, 'OT', FVRM.AMOUNT, 0) OT,
                                      DECODE (KET, 'MF', FVRM.AMOUNT, 0) MF
                                 FROM APPS.FCS_VIEW_REALISASI_MODIFIER FVRM
                                WHERE KET IN ('OT', 'MF'))
                        WHERE 1 = 1
                     GROUP BY LINE_NO, CONFIRM_NO_ORIG) FVRMT
              WHERE     PROD.PROPOSAL_ID = PPPC.PROPOSAL_ID
                    AND USR.USER_NAME(+) = PPPC.PEMOHON
                    AND TGT.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                    AND POT.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND BIA.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND BNS.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND PBUD.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    --              AND PPPC.PROPOSAL_NO = 'AHY18020009'
                    AND FVRG.NO_KONFIRMASI(+) =
                              PPPC.CONFIRM_NO
                           || DECODE (PPPC.ADDENDUM_KE,
                                      NULL, '',
                                      '-' || PPPC.ADDENDUM_KE)
                    AND FVRG.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND FVRG.LINE_NO(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRD.PROPOSAL_ID(+) = PPPC.PROPOSAL_ID
                    AND FVRD.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND FVRD.LINE_NUM_PC(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRP.PROPOSAL_ID(+) = PPPC.PROPOSAL_ID
                    AND FVRP.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND FVRP.LINE_NO(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRMT.LINE_NO(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRMT.CONFIRM_NO(+) =
                              PPPC.CONFIRM_NO
                           || DECODE (PPPC.ADDENDUM_KE,
                                      NULL, '',
                                      '-' || PPPC.ADDENDUM_KE)
           ORDER BY PPPC.PROPOSAL_NO, PROD.LINE_NO) LALA
/

