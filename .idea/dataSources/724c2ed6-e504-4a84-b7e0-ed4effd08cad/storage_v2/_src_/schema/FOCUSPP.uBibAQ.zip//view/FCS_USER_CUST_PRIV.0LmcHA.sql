create view FCS_USER_CUST_PRIV as
  select 
case when region = 'Y' or area = 'Y' or loc = 'Y' or custtype = 'Y' or custgroup = 'Y' or cust = 'Y' then 'VALID'
else 'INVALID' end as user_customer,
region || ';' || area || ';' || loc || ';' || custtype || ';' || custgroup || ';' || cust  as user_cust_priv,
user_name
from (
select case when sum(uregion) > 0 then 'Y' else 'N' end as region, 
case when sum(uarea) > 0 then 'Y' else 'N' end as area, 
case when sum(uloc) > 0 then 'Y' else 'N' end as loc, 
case when sum(ucusttype) > 0 then 'Y' else 'N' end as custtype, 
case when sum(ucustgroup) > 0 then 'Y' else 'N' end as custgroup, 
case when sum(ucust) > 0 then 'Y' else 'N' end as cust,
user_name
from (
select count(uc.region_code) as uregion, 0 as uarea, 0 as uloc, 0 as ucusttype, 0 as ucustgroup, 0 as ucust, ua.user_name from app_user_region uc, app_user_access ua WHERE uc.user_name(+) = ua.user_name group by ua.user_name
union
select 0 as uregion, count(uc.area_code) as uarea, 0 as uloc, 0 as ucusttype, 0 as ucustgroup, 0 as ucust, ua.user_name from app_user_area uc, app_user_access ua WHERE uc.user_name(+) = ua.user_name group by ua.user_name
union
select 0 as uregion, 0 as uarea, count(uc.location_code) as uloc, 0 as ucusttype, 0 as ucustgroup, 0 as ucust, ua.user_name from app_user_loc uc, app_user_access ua WHERE uc.user_name(+) = ua.user_name group by ua.user_name
union
select 0 as uregion, 0 as uarea, 0 as uloc, count(uc.cust_type) as ucusttype, 0 as ucustgroup, 0 as ucust, ua.user_name from app_user_cust_type uc, app_user_access ua WHERE uc.user_name(+) = ua.user_name group by ua.user_name
union
select 0 as uregion, 0 as uarea, 0 as uloc, 0 as ucusttype, count(uc.cust_group) as ucustgroup, 0 as ucust, ua.user_name from app_user_cust_group uc, app_user_access ua WHERE uc.user_name(+) = ua.user_name group by ua.user_name
union
select 0 as uregion, 0 as uarea, 0 as uloc, 0 as ucusttype, 0 as ucustgroup, count(uc.customer_id) as ucust, ua.user_name from app_user_cust uc, app_user_access ua WHERE uc.user_name(+) = ua.user_name group by ua.user_name
) group by user_name)
/

