create view FCS_VIEW_PB as
  SELECT
    PP.PROPOSAL_ID,
--    PP.PROPOSAL_NO,
    PP.CONFIRM_NO,
--    PR.LINE_NO,
--    PP.PROPOSAL_TYPE,
--    PP.DISCOUNT_TYPE,
--    PP.MEKANISME_PENAGIHAN,
    RIP.PROMO_PRODUK_ID
--    msi.INVENTORY_ITEM_ID,
--    msi.organization_id,
--    RCTLA.LINE_NUMBER,
--    rcta.CUSTOMER_TRX_ID
--    (SELECT /*MIN (pco.proposal_id)*/ pco.proposal_id
--       FROM focuspp.proposal pco
--      WHERE     pco.confirm_no = pp.confirm_no
--            AND pco.discount_type = 'PROMOBARANG'
--            AND pco.mekanisme_penagihan = 'ONINVOICE')
--       proposal_id_ori,
--    PR.line_no,
--    rip.kd_item_paket,
--    rip.promo_produk_id,
--    ooh.order_number,
--    SUM (
--       NVL (rctla.quantity_ordered, rctla.quantity_invoiced)
--       + NVL (sk_data.qty_sk, 0))
--       qty_inv
FROM APPS.FND_LOOKUP_VALUES FLV, 
    FOCUSPP.REALISASI_ITEM_PAKET rip,
    FOCUSPP.PROPOSAL PP,
    (SELECT ROW_NUMBER ()
        OVER (
           PARTITION BY pc_line.proposal_id
           ORDER BY pc_line.proposal_id, pc_line.promo_produk_id)
           line_no,
        pc_line.*
        FROM focuspp.promo_produk pc_line) pr,
    APPS.ra_customer_trx_all rcta,
    APPS.ra_customer_trx_lines_all rctla,
    APPS.ra_cust_trx_types_all rctta,
    APPS.mtl_system_items_b msi,
    APPS.oe_order_headers_all ooh,
    (SELECT ool1.reference_line_id,
          SUM (rctla1.quantity_credited) qty_sk
     FROM APPS.oe_order_headers_all ooh1,
          APPS.oe_order_lines_all ool1,
          APPS.oe_transaction_types_tl oot1,
          APPS.ar_lookups al1,
          APPS.ra_customer_trx_all rcta1,
          APPS.ra_customer_trx_lines_all rctla1
     WHERE     1 = 1
          AND ooh1.header_id = ool1.header_id
          AND ool1.return_reason_code = al1.lookup_code
          AND al1.lookup_type = 'CREDIT_MEMO_REASON'
          AND ooh1.order_type_id = oot1.transaction_type_id
          AND oot1.NAME LIKE 'SK%'
          AND TO_CHAR (ooh1.order_number) =
                 rctla1.interface_line_attribute1
          AND NVL (rctla1.interface_line_attribute11, 0) NOT IN
                 (SELECT TO_CHAR (opa.price_adjustment_id)
                    FROM APPS.oe_price_adjustments opa)
          AND ool1.line_id = rctla1.interface_line_attribute6
          AND rcta1.customer_trx_id = rctla1.customer_trx_id
     GROUP BY ool1.reference_line_id) SK_DATA
WHERE FLV.ATTRIBUTE1 = 'PROMO'
--    AND PP.PROPOSAL_NO = 'SIS19100031'
    AND FLV.LOOKUP_TYPE = RIP.KD_ITEM_PAKET
    AND PP.PROPOSAL_ID = PR.PROPOSAL_ID
    AND RIP.PROMO_PRODUK_ID = PR.PROMO_PRODUK_ID
    AND rcta.cust_trx_type_id = rctta.cust_trx_type_id
    AND rcta.cust_trx_type_id = rctta.cust_trx_type_id
    AND rctta.TYPE = 'INV'
    AND rcta.complete_flag = 'Y'
    AND rcta.customer_trx_id = rctla.customer_trx_id
    AND msi.item_type = 'PKT'
    AND msi.segment1 = rip.kd_item_paket
    AND rctla.inventory_item_id = msi.inventory_item_id
    AND rctla.warehouse_id = msi.organization_id
    AND TRUNC (ooh.ordered_date) >= TRUNC (pp.periode_prog_from)
    AND TRUNC (ooh.ordered_date) <= TRUNC (pp.periode_prog_to)
    AND rctla.interface_line_attribute6 = sk_data.reference_line_id(+)
    AND TO_CHAR (ooh.order_number) = rctla.interface_line_attribute1
--GROUP BY 
--        rcta.trx_number,
--        rcta.customer_trx_id,
--        NVL (pp.brg_bonus_mf, 0),
--        pp.confirm_no,
--        pp.proposal_id,
--        pp.line_no,
--        rip.kd_item_paket,
--        rip.promo_produk_id
--        ooh.order_number,
--        rctla.tax_classification_code
/

