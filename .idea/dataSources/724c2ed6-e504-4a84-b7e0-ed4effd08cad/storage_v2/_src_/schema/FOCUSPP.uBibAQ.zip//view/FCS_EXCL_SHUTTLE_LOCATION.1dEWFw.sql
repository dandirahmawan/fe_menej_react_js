create view FCS_EXCL_SHUTTLE_LOCATION as
  select arc.attribute5 AS loc_code,
            arc.attribute5 || ' ' || flex.description AS loc_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION_CUST_GROUP rcg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute1 = rcg.cust_group
and aur.region_code = arc.attribute3    
and arc.status = 'A'
and prod.promo_produk_id = rcg.promo_produk_id
and flex.flex_value = arc.attribute5
group by arc.attribute5, aur.user_name, arc.attribute4, arc.attribute3, prod.promo_produk_id, flex.description
union
select arc.attribute5 AS loc_code,
            arc.attribute5 || ' ' || flex.description AS loc_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION pg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute3 = pg.region_code
and aur.region_code = arc.attribute3 
and arc.status = 'A'
and prod.promo_produk_id = pg.promo_produk_id
and flex.flex_value = arc.attribute5
group by arc.attribute5, aur.user_name, arc.attribute4, arc.attribute3, prod.promo_produk_id, flex.description
union
select arc.attribute5 AS loc_code,
            arc.attribute5 || ' ' || flex.description AS loc_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION_AREA pra, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute4 = pra.area_code
and aur.region_code = arc.attribute3  
and arc.status = 'A'
and prod.promo_produk_id = pra.promo_produk_id
and flex.flex_value = arc.attribute5
group by arc.attribute5, aur.user_name, arc.attribute4, arc.attribute3, prod.promo_produk_id, flex.description
order by 1
/

