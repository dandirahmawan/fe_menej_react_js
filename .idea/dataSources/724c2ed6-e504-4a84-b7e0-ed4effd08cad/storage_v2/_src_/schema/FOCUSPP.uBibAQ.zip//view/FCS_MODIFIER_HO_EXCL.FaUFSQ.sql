create view FCS_MODIFIER_HO_EXCL as
  SELECT   DENSE_RANK ()
                 OVER (ORDER BY LALA.NO_CONFIRM,
                                LALA.BREAK_TYPE,
                                LALA.PRODUCT_VALUE,
                                LALA.KET)
                 AS LINE_NUM,
              LALA."NO_CONFIRM",
              LALA."CURRENCY",
              LALA."START_DATE",
              LALA."END_DATE",
              LALA."ACTIVE",
              LALA."AUTOMATIC",
              LALA."LINE_LEVEL",
              LALA."LINE_TYPE",
              LALA."START_DATE_LINE",
              LALA."END_DATE_LINE",
              LALA."AUTOMATIC_LINE",
              LALA."PRICING_PHASE",
              LALA."BUCKET",
              LALA."PRODUCT_ATTRIBUTE",
              LALA."PRODUCT_VALUE",
              LALA."VOLUME_TYPE",
              LALA."BREAK_TYPE",
              LALA."UOM",
              LALA."VALUE_FROM",
              LALA."VALUE_TO",
              LALA."APPLICATION_METHOD",
              LALA."VALUE",
              LALA."GROUPING_NO",
              LALA."QUALIFIER_CONTEXT",
              LALA."QUALIFIER_ATTR",
              LALA."OPERATOR_SIGN",
              LALA."VALUE_QUALIFIER",
              LALA."CONFIRM_NO_DEF",
              LALA."PROMO_PRODUK_ID",
              LALA."DISC_YEARLY",
              LALA."KET"
       FROM   (  SELECT   (CASE
                              WHEN PROP.ADDENDUM_KE IS NULL THEN PROP.CONFIRM_NO
                              ELSE PROP.CONFIRM_NO || '-' || PROP.ADDENDUM_KE
                           END)
                             AS NO_CONFIRM,
                          PROP.CURRENCY,
                          PROP.PERIODE_PROG_FROM AS START_DATE,
                          PROP.PERIODE_PROG_TO AS END_DATE,
                          'Y' AS ACTIVE,
                          'Y' AS AUTOMATIC,
                          (CASE
                              WHEN PROP.MIX_QTY_PROMO = 'N' THEN 'Line'
                              ELSE 'Group of Line'
                           END)
                             AS LINE_LEVEL,
                          'Discount' AS LINE_TYPE,
                          PROP.PERIODE_PROG_FROM AS START_DATE_LINE,
                          PROP.PERIODE_PROG_TO AS END_DATE_LINE,
                          'Y' AS AUTOMATIC_LINE,
                          'All Lines Adjustment' AS PRICING_PHASE,
                          PROD.KODE_POSTING AS BUCKET,
                          (CASE
                              WHEN ITCV.SET_VARIANT_DESC = 'ALL'
                                   AND PROD_ITEM IS NOT NULL
                              THEN
                                 PROD_ITEM.PROD_ITEM
                              ELSE
                                 (   PROD.PRODUCT_CATEGORY
                                  || '.'
                                  || PROD.PRODUCT_CLASS
                                  || '.'
                                  || PROD.PRODUCT_BRAND
                                  || '.'
                                  || PROD.PRODUCT_EXT
                                  || '.'
                                  || PROD.PRODUCT_PACK
                                  || '.'
                                  || PROD_VARIANT)
                           END)
                             AS PRODUCT_ATTRIBUTE,
                          (CASE
                              WHEN ITCV.SET_VARIANT_DESC = 'ALL'
                                   AND PROD_ITEM IS NOT NULL
                              THEN
                                 PROD_ITEM.PROD_ITEM
                              ELSE
                                 (   PROD.PRODUCT_CATEGORY
                                  || '.'
                                  || PROD.PRODUCT_CLASS
                                  || '.'
                                  || PROD.PRODUCT_BRAND
                                  || '.'
                                  || PROD.PRODUCT_EXT
                                  || '.'
                                  || PROD.PRODUCT_PACK
                                  || '.'
                                  || PROD_VARIANT)
                           END)
                             AS PRODUCT_VALUE,
                          'Item Quantity' AS VOLUME_TYPE,
                          (CASE
                              WHEN DISC.TIPE_PERHITUNGAN = 'TDKKELIPATAN'
                              THEN
                                 'Point'
                              ELSE
                                 'Recurring'
                           END)
                             AS BREAK_TYPE,
                          DISC.UOM AS UOM,
                          DISC.QTY_FROM AS VALUE_FROM,
                          NVL (DISC.QTY_TO, 999999) AS VALUE_TO,
                          DISC.TIPE_POTONGAN AS APPLICATION_METHOD,
                          --DECODE(unpivot_row,1,DISC.DISC_YEARLY,2,DISC.DISC_NON_YEARLY,NULL) AS VALUE,
                          DISC.DISC_YEARLY AS VALUE,
                          2 AS LINE_NUM,
                          -1 AS GROUPING_NO,
                          'Customer' AS QUALIFIER_CONTEXT,
                          (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 'FCS_REGION'
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 'FCS_AREA'
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 'SOLD_TO_ORG_ID'
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 'FCS_LOCATION'
                              ELSE
                                 'NOT DEFINED'
                           END)
                             AS QUALIFIER_ATTR,
                          'NOT =' AS OPERATOR_SIGN,
                          (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 REG.REGION_CODE
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 AREA.AREA_CODE
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 TO_CHAR (CUST.CUSTOMER_ID)
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 TO_CHAR (LOC.LOCATION_CODE)
                           END)
                             AS VALUE_QUALIFIER,
                          PROP.CONFIRM_NO AS CONFIRM_NO_DEF,
                          PROD.PROMO_PRODUK_ID,
                          DISC.DISC_YEARLY,
                          'MF' KET
                   FROM   PROPOSAL PROP,
                          PROMO_PRODUK PROD,
                          DISCOUNT DISC,
                          EXCL_CUST_REGION REG,
                          EXCL_CUST_CUST CUST,
                          EXCL_CUST_AREA AREA,
                          EXCL_CUST_LOC LOC,
                          (    SELECT   LEVEL AS unpivot_row
                                 FROM   DUAL
                           CONNECT BY   LEVEL <= 2),
                          PRODUK_VARIANT PROD_VARIANT,
                          PRODUK_ITEM PROD_ITEM,
                          APPS.FCS_VIEW_ITEM_MASTER_CATEGORY ITCV
                  WHERE       PROP.CONFIRM_NO IS NOT NULL
                          AND PROD.PROPOSAL_ID = PROP.PROPOSAL_ID
                          AND DISC.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                          AND REG.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND CUST.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND AREA.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND LOC.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          --AND DECODE(unpivot_row,1,DISC.DISC_YEARLY,2,DISC.DISC_NON_YEARLY,NULL) IS NOT NULL
                          AND DISC.DISC_YEARLY IS NOT NULL
                          AND PROD_VARIANT.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                          AND PROD_ITEM.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND ITCV.SET_VARIANT = PROD_VARIANT
                          AND PROD.EXCL_CUST_BY IS NOT NULL
                          AND PROP.USER_TYPE_CREATOR = 'HO'
                          AND DISC.DISC_YEARLY <> 0
               GROUP BY   (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 'FCS_REGION'
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 'FCS_AREA'
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 'SOLD_TO_ORG_ID'
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 'FCS_LOCATION'
                              ELSE
                                 'NOT DEFINED'
                           END),
                          (CASE
                              WHEN PROP.ADDENDUM_KE IS NULL
                              THEN
                                 PROP.CONFIRM_NO
                              ELSE
                                 PROP.CONFIRM_NO || '-' || PROP.ADDENDUM_KE
                           END),
                          PROP.CURRENCY,
                          PROP.PERIODE_PROG_FROM,
                          PROP.PERIODE_PROG_TO,
                          PROP.PERIODE_PROG_FROM,
                          PROP.PERIODE_PROG_TO,
                          PROD.KODE_POSTING,
                          (   PROD.PRODUCT_CATEGORY
                           || '.'
                           || PROD.PRODUCT_CLASS
                           || '.'
                           || PROD.PRODUCT_BRAND
                           || '.'
                           || PROD.PRODUCT_EXT
                           || '.'
                           || PROD.PRODUCT_PACK
                           || '.'
                           || PROD_VARIANT),
                          (CASE
                              WHEN DISC.TIPE_PERHITUNGAN = 'TDKKELIPATAN'
                              THEN
                                 'Point'
                              ELSE
                                 'Recurring'
                           END),
                          DISC.UOM,
                          DISC.QTY_FROM,
                          NVL (DISC.QTY_TO, 999999),
                          PROD_ITEM.PROD_ITEM,
                          ITCV.SET_VARIANT_DESC,
                          DISC.TIPE_POTONGAN,
                          (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 REG.REGION_CODE
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 AREA.AREA_CODE
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 TO_CHAR (CUST.CUSTOMER_ID)
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 TO_CHAR (LOC.LOCATION_CODE)
                           END),
                          --DECODE(unpivot_row,1,DISC.DISC_YEARLY,2,DISC.DISC_NON_YEARLY,NULL),
                          DISC.DISC_YEARLY,
                          PROP.CONFIRM_NO,
                          PROD.PROMO_PRODUK_ID,
                          (CASE
                              WHEN PROP.MIX_QTY_PROMO = 'N' THEN 'Line'
                              ELSE 'Group of Line'
                           END)
               UNION ALL
                 SELECT   (CASE
                              WHEN PROP.ADDENDUM_KE IS NULL THEN PROP.CONFIRM_NO
                              ELSE PROP.CONFIRM_NO || '-' || PROP.ADDENDUM_KE
                           END)
                             AS NO_CONFIRM,
                          PROP.CURRENCY,
                          PROP.PERIODE_PROG_FROM AS START_DATE,
                          PROP.PERIODE_PROG_TO AS END_DATE,
                          'Y' AS ACTIVE,
                          'Y' AS AUTOMATIC,
                          (CASE
                              WHEN PROP.MIX_QTY_PROMO = 'N' THEN 'Line'
                              ELSE 'Group of Line'
                           END)
                             AS LINE_LEVEL,
                          'Discount' AS LINE_TYPE,
                          PROP.PERIODE_PROG_FROM AS START_DATE_LINE,
                          PROP.PERIODE_PROG_TO AS END_DATE_LINE,
                          'Y' AS AUTOMATIC_LINE,
                          'All Lines Adjustment' AS PRICING_PHASE,
                          PROD.KODE_POSTING AS BUCKET,
                          (CASE
                              WHEN ITCV.SET_VARIANT_DESC = 'ALL'
                                   AND PROD_ITEM IS NOT NULL
                              THEN
                                 PROD_ITEM.PROD_ITEM
                              ELSE
                                 (   PROD.PRODUCT_CATEGORY
                                  || '.'
                                  || PROD.PRODUCT_CLASS
                                  || '.'
                                  || PROD.PRODUCT_BRAND
                                  || '.'
                                  || PROD.PRODUCT_EXT
                                  || '.'
                                  || PROD.PRODUCT_PACK
                                  || '.'
                                  || PROD_VARIANT)
                           END)
                             AS PRODUCT_ATTRIBUTE,
                          (CASE
                              WHEN ITCV.SET_VARIANT_DESC = 'ALL'
                                   AND PROD_ITEM IS NOT NULL
                              THEN
                                 PROD_ITEM.PROD_ITEM
                              ELSE
                                 (   PROD.PRODUCT_CATEGORY
                                  || '.'
                                  || PROD.PRODUCT_CLASS
                                  || '.'
                                  || PROD.PRODUCT_BRAND
                                  || '.'
                                  || PROD.PRODUCT_EXT
                                  || '.'
                                  || PROD.PRODUCT_PACK
                                  || '.'
                                  || PROD_VARIANT)
                           END)
                             AS PRODUCT_VALUE,
                          'Item Quantity' AS VOLUME_TYPE,
                          (CASE
                              WHEN DISC.TIPE_PERHITUNGAN = 'TDKKELIPATAN'
                              THEN
                                 'Point'
                              ELSE
                                 'Recurring'
                           END)
                             AS BREAK_TYPE,
                          DISC.UOM AS UOM,
                          DISC.QTY_FROM AS VALUE_FROM,
                          NVL (DISC.QTY_TO, 999999) AS VALUE_TO,
                          DISC.TIPE_POTONGAN AS APPLICATION_METHOD,
                          --DECODE(unpivot_row,1,DISC.DISC_YEARLY,2,DISC.DISC_NON_YEARLY,NULL) AS VALUE,
                          DISC.DISC_NON_YEARLY AS VALUE,
                          1 AS LINE_NUM,
                          -1 AS GROUPING_NO,
                          'Customer' AS QUALIFIER_CONTEXT,
                          (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 'FCS_REGION'
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 'FCS_AREA'
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 'SOLD_TO_ORG_ID'
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 'FCS_LOCATION'
                              ELSE
                                 'NOT DEFINED'
                           END)
                             AS QUALIFIER_ATTR,
                          'NOT =' AS OPERATOR_SIGN,
                          (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 REG.REGION_CODE
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 AREA.AREA_CODE
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 TO_CHAR (CUST.CUSTOMER_ID)
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 TO_CHAR (LOC.LOCATION_CODE)
                           END)
                             AS VALUE_QUALIFIER,
                          PROP.CONFIRM_NO AS CONFIRM_NO_DEF,
                          PROD.PROMO_PRODUK_ID,
                          DISC.DISC_NON_YEARLY,
                          'OT' KET
                   FROM   PROPOSAL PROP,
                          PROMO_PRODUK PROD,
                          DISCOUNT DISC,
                          EXCL_CUST_REGION REG,
                          EXCL_CUST_CUST CUST,
                          EXCL_CUST_AREA AREA,
                          EXCL_CUST_LOC LOC,
                          (    SELECT   LEVEL AS unpivot_row
                                 FROM   DUAL
                           CONNECT BY   LEVEL <= 2),
                          PRODUK_VARIANT PROD_VARIANT,
                          PRODUK_ITEM PROD_ITEM,
                          APPS.FCS_VIEW_ITEM_MASTER_CATEGORY ITCV
                  WHERE       PROP.CONFIRM_NO IS NOT NULL
                          AND PROD.PROPOSAL_ID = PROP.PROPOSAL_ID
                          AND DISC.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                          AND REG.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND CUST.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND AREA.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND LOC.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          --AND DECODE(unpivot_row,1,DISC.DISC_YEARLY,2,DISC.DISC_NON_YEARLY,NULL) IS NOT NULL
                          AND DISC.DISC_NON_YEARLY IS NOT NULL
                          AND PROD_VARIANT.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                          AND PROD_ITEM.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                          AND ITCV.SET_VARIANT = PROD_VARIANT
                          AND PROD.EXCL_CUST_BY IS NOT NULL
                          AND PROP.USER_TYPE_CREATOR = 'HO'
                          AND DISC.DISC_NON_YEARLY <> 0
               GROUP BY   (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 'FCS_REGION'
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 'FCS_AREA'
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 'SOLD_TO_ORG_ID'
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 'FCS_LOCATION'
                              ELSE
                                 'NOT DEFINED'
                           END),
                          (CASE
                              WHEN PROP.ADDENDUM_KE IS NULL
                              THEN
                                 PROP.CONFIRM_NO
                              ELSE
                                 PROP.CONFIRM_NO || '-' || PROP.ADDENDUM_KE
                           END),
                          PROP.CURRENCY,
                          PROP.PERIODE_PROG_FROM,
                          PROP.PERIODE_PROG_TO,
                          PROP.PERIODE_PROG_FROM,
                          PROP.PERIODE_PROG_TO,
                          PROD.KODE_POSTING,
                          (   PROD.PRODUCT_CATEGORY
                           || '.'
                           || PROD.PRODUCT_CLASS
                           || '.'
                           || PROD.PRODUCT_BRAND
                           || '.'
                           || PROD.PRODUCT_EXT
                           || '.'
                           || PROD.PRODUCT_PACK
                           || '.'
                           || PROD_VARIANT),
                          (CASE
                              WHEN DISC.TIPE_PERHITUNGAN = 'TDKKELIPATAN'
                              THEN
                                 'Point'
                              ELSE
                                 'Recurring'
                           END),
                          DISC.UOM,
                          DISC.QTY_FROM,
                          NVL (DISC.QTY_TO, 999999),
                          PROD_ITEM.PROD_ITEM,
                          ITCV.SET_VARIANT_DESC,
                          DISC.TIPE_POTONGAN,
                          (CASE
                              WHEN PROD.EXCL_CUST_BY = 'REGION'
                              THEN
                                 REG.REGION_CODE
                              WHEN PROD.EXCL_CUST_BY = 'AREA'
                              THEN
                                 AREA.AREA_CODE
                              WHEN PROD.EXCL_CUST_BY = 'CUSTOMER'
                              THEN
                                 TO_CHAR (CUST.CUSTOMER_ID)
                              WHEN PROD.EXCL_CUST_BY = 'LOCATION'
                              THEN
                                 TO_CHAR (LOC.LOCATION_CODE)
                           END),
                          --DECODE(unpivot_row,1,DISC.DISC_YEARLY,2,DISC.DISC_NON_YEARLY,NULL),
                          DISC.DISC_NON_YEARLY,
                          PROP.CONFIRM_NO,
                          PROD.PROMO_PRODUK_ID,
                          (CASE
                              WHEN PROP.MIX_QTY_PROMO = 'N' THEN 'Line'
                              ELSE 'Group of Line'
                           END)) LALA
   ORDER BY   1 ASC
/

