create view FCS_UN_USER_ACCESS_ROLES as
  select uuar.role, uuar.user_name from ut_user_access_roles uuar
    union all
    select auar.role, auar.user_name from app_user_access_roles auar where auar.user_name not in (select uuar.user_name from ut_user_access_roles uuar)
/

