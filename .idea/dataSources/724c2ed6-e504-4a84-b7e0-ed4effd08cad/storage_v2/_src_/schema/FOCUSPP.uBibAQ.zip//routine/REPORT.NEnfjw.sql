create PROCEDURE report (
   prop_id IN VARCHAR2,
   p_refcur OUT SYS_REFCURSOR
)
IS
BEGIN
null;
END
  /

