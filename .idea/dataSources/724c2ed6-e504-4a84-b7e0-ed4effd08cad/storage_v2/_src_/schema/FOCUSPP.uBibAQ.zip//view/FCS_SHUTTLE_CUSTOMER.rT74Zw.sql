create view FCS_SHUTTLE_CUSTOMER as
  SELECT   ArCustomers.CUSTOMER_ID,
          ArCustomers.CUSTOMER_NAME,
          ArCustomers.CUSTOMER_NUMBER,
          (ArCustomers.CUSTOMER_NUMBER
                    || ' - '
                    || CAV.ACCOUNT_NAME
                    || ' - ' 
                    || flex.DESCRIPTION)
             AS CUSTOMER_FULL_NAME,
          ArCustomers.ATTRIBUTE3 AS REGION_CODE,
          AUR.USER_NAME,
          ArCustomers.ATTRIBUTE4 AS AREA_CODE,
          ArCustomers.ATTRIBUTE5 AS LOC_CODE,
          ArCustomers.ATTRIBUTE1 AS CUSTGROUP_CODE
   FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_REGION AUR, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
  WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE
          AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5 
          AND ArCustomers.STATUS = 'A'
          AND ArCustomers.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
          AND (SELECT COUNT(*) FROM APP_USER_AREA AUA WHERE AUA.USER_NAME = AUR.USER_NAME) = 0
          AND (SELECT COUNT(*) FROM APP_USER_LOC AUL WHERE AUL.USER_NAME = AUR.USER_NAME) = 0
          AND (SELECT COUNT(*) FROM APP_USER_CUST_GROUP ACG WHERE ACG.USER_NAME = AUR.USER_NAME) = 0
          AND (SELECT COUNT(*) FROM APP_USER_CUST AUC WHERE AUC.USER_NAME = AUR.USER_NAME) = 0  
          AND (ArCustomers.attribute9 IS NULL or (ArCustomers.attribute9 IS NOT NULL AND to_date(substr(ArCustomers.attribute9,0,10),'yyyy/mm/dd') > sysdate))
GROUP BY  ArCustomers.CUSTOMER_ID,
          ArCustomers.CUSTOMER_NAME,
          ArCustomers.CUSTOMER_NUMBER,
          ArCustomers.ATTRIBUTE1,
          ArCustomers.ATTRIBUTE3,
          ArCustomers.ATTRIBUTE4,
          ArCustomers.ATTRIBUTE5,
          CAV.ACCOUNT_NAME,
          AUR.USER_NAME,
          flex.DESCRIPTION
UNION ALL
SELECT   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              (ArCustomers.CUSTOMER_NUMBER
                        || ' - '
                        || CAV.ACCOUNT_NAME
                        || ' - ' 
                        || flex.DESCRIPTION)
                 AS CUSTOMER_FULL_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              AppUserArea.USER_NAME,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE,
              ArCustomers.ATTRIBUTE1 AS CUSTGROUP_CODE
       FROM   APPS.FCS_FLEX_VALUES_VL flex,
              APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_AREA AppUserArea, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
      WHERE   flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.ATTRIBUTE4 = AppUserArea.AREA_CODE
              AND ArCustomers.STATUS = 'A'
              AND ArCustomers.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
              AND (SELECT COUNT(*) FROM APP_USER_LOC AUL WHERE AUL.USER_NAME = AppUserArea.USER_NAME) = 0
              AND (SELECT COUNT(*) FROM APP_USER_CUST_GROUP ACG WHERE ACG.USER_NAME = AppUserArea.USER_NAME) = 0
              AND (SELECT COUNT(*) FROM APP_USER_CUST AUC WHERE AUC.USER_NAME = AppUserArea.USER_NAME) = 0  
              AND (ArCustomers.attribute9 IS NULL or (ArCustomers.attribute9 IS NOT NULL AND to_date(substr(ArCustomers.attribute9,0,10),'yyyy/mm/dd') > sysdate))
   GROUP BY   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              ArCustomers.ATTRIBUTE1,
              ArCustomers.ATTRIBUTE3,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              CAV.ACCOUNT_NAME,
              AppUserArea.USER_NAME,
              flex.DESCRIPTION
UNION ALL
SELECT   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              (ArCustomers.CUSTOMER_NUMBER
                        || ' - '
                        || CAV.ACCOUNT_NAME
                        || ' - ' 
                        || flex.DESCRIPTION)
                 AS CUSTOMER_FULL_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              AppUserLoc.USER_NAME,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE,
              ArCustomers.ATTRIBUTE1 AS CUSTGROUP_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_LOC AppUserLoc, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
      WHERE   flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.ATTRIBUTE5 = AppUserLoc.LOCATION_CODE
              AND ArCustomers.STATUS = 'A'
              AND ArCustomers.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
              AND (SELECT COUNT(*) FROM APP_USER_CUST_GROUP ACG WHERE ACG.USER_NAME = AppUserLoc.USER_NAME) = 0  
              AND (SELECT COUNT(*) FROM APP_USER_CUST AUC WHERE AUC.USER_NAME = AppUserLoc.USER_NAME) = 0 
              AND (ArCustomers.attribute9 IS NULL or (ArCustomers.attribute9 IS NOT NULL AND to_date(substr(ArCustomers.attribute9,0,10),'yyyy/mm/dd') > sysdate)) 
   GROUP BY   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              ArCustomers.ATTRIBUTE1,
              ArCustomers.ATTRIBUTE3,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              CAV.ACCOUNT_NAME,
              AppUserLoc.USER_NAME,
              flex.DESCRIPTION
UNION ALL
SELECT   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              (ArCustomers.CUSTOMER_NUMBER
                        || ' - '
                        || CAV.ACCOUNT_NAME
                        || ' - ' 
                        || flex.DESCRIPTION)
                 AS CUSTOMER_FULL_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              AppUserCustGroup.USER_NAME,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE,
              ArCustomers.ATTRIBUTE1 AS CUSTGROUP_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_CUST_GROUP AppUserCustGroup, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
      WHERE   flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.ATTRIBUTE1 = AppUserCustGroup.CUST_GROUP
              AND ArCustomers.STATUS = 'A'
              AND ArCustomers.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
              AND (SELECT COUNT(*) FROM APP_USER_CUST AUC WHERE AUC.USER_NAME = AppUserCustGroup.USER_NAME) = 0  
              AND (ArCustomers.attribute9 IS NULL or (ArCustomers.attribute9 IS NOT NULL AND to_date(substr(ArCustomers.attribute9,0,10),'yyyy/mm/dd') > sysdate))
   GROUP BY   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              ArCustomers.ATTRIBUTE1,
              ArCustomers.ATTRIBUTE3,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              CAV.ACCOUNT_NAME,
              AppUserCustGroup.USER_NAME,
              flex.DESCRIPTION
UNION ALL
SELECT   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              (ArCustomers.CUSTOMER_NUMBER
                        || ' - '
                        || CAV.ACCOUNT_NAME
                        || ' - ' 
                        || flex.DESCRIPTION)
                 AS CUSTOMER_FULL_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              AppUserCust.USER_NAME,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE,
              ArCustomers.ATTRIBUTE1 AS CUSTGROUP_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_CUST AppUserCust, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
      WHERE   ArCustomers.CUSTOMER_ID = AppUserCust.CUSTOMER_ID
              AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.STATUS = 'A'
              AND AppUserCust.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
              AND ArCustomers.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
              AND (SELECT COUNT(*) FROM APP_USER_CUST AUC WHERE AUC.USER_NAME = AppUserCust.USER_NAME) > 0  
              AND (ArCustomers.attribute9 IS NULL or (ArCustomers.attribute9 IS NOT NULL AND to_date(substr(ArCustomers.attribute9,0,10),'yyyy/mm/dd') > sysdate))
   GROUP BY   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              ArCustomers.ATTRIBUTE1,
              ArCustomers.ATTRIBUTE3,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              CAV.ACCOUNT_NAME,
              AppUserCust.USER_NAME,
              flex.DESCRIPTION
   ORDER BY   "CUSTOMER_FULL_NAME"
/

