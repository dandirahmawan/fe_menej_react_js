create view FCS_SHUTTLE_CUST_GROUP as
  SELECT   ArCustomers.ATTRIBUTE1 AS CUST_GROUP_CODE,
                 ArCustomers.ATTRIBUTE1
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE1)
                 CUST_GROUP_LABEL,
              AUR.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_REGION AUR,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE
              AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE3
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_AREA AUA
                    WHERE   AUA.USER_NAME = AUR.USER_NAME) = 0
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_LOC AUL
                    WHERE   AUL.USER_NAME = AUR.USER_NAME) = 0
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_GROUP ACG
                    WHERE   ACG.USER_NAME = AUR.USER_NAME) = 0
   GROUP BY   ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE1,
              ArCustomers.ATTRIBUTE5,
              ArCustomers.ATTRIBUTE3,
              flex.DESCRIPTION,
              AUR.USER_NAME
   UNION ALL
     SELECT   ArCustomers.ATTRIBUTE1 AS CUST_GROUP_CODE,
                 ArCustomers.ATTRIBUTE1
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE1)
                 CUST_GROUP_LABEL,
              AppUserArea.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.FCS_FLEX_VALUES_VL flex,
              APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_AREA AppUserArea
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE4
              AND ArCustomers.ATTRIBUTE4 = AppUserArea.AREA_CODE
              AND ArCustomers.STATUS = 'A'
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_LOC AUL
                    WHERE   AUL.USER_NAME = AppUserArea.USER_NAME) = 0
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_GROUP ACG
                    WHERE   ACG.USER_NAME = AppUserArea.USER_NAME) = 0
   GROUP BY   ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              ArCustomers.ATTRIBUTE1,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE3,
              AppUserArea.USER_NAME
   UNION ALL
     SELECT   ArCustomers.ATTRIBUTE1 AS CUST_GROUP_CODE,
                 ArCustomers.ATTRIBUTE1
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE1)
                 CUST_GROUP_LABEL,
              AppUserLoc.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_LOC AppUserLoc,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.ATTRIBUTE5 = AppUserLoc.LOCATION_CODE
              AND ArCustomers.STATUS = 'A'
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_GROUP ACG
                    WHERE   ACG.USER_NAME = AppUserLoc.USER_NAME) = 0
   GROUP BY   ArCustomers.ATTRIBUTE5,
              ArCustomers.ATTRIBUTE1,
              AppUserLoc.USER_NAME,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE3
   UNION ALL
     SELECT   ArCustomers.ATTRIBUTE1 AS CUST_GROUP_CODE,
              ArCustomers.ATTRIBUTE1 || ' ' || flex.DESCRIPTION
                 CUST_GROUP_LABEL,
              AppUserCustGroup.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_CUST_GROUP AppUserCustGroup,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE1
              AND ArCustomers.ATTRIBUTE1 = AppUserCustGroup.CUST_GROUP
              AND ArCustomers.STATUS = 'A'
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_GROUP ACG
                    WHERE   ACG.USER_NAME = AppUserCustGroup.USER_NAME) > 0
   GROUP BY   ArCustomers.ATTRIBUTE1,
              AppUserCustGroup.USER_NAME,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE3,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS CUST_GROUP_CODE,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS CUST_GROUP_LABEL,
              AppUserCustGroup.USER_NAME,
              'REGIONX' AS REGION_CODE,
              'AREAX' AS AREA_CODE,
              'LOCATIONX' AS LOC_CODE
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_CUST_GROUP AppUserCustGroup
      WHERE   AppUserCustGroup.CUST_GROUP = FcsViewAttrExcl.VALUE
              AND FcsViewAttrExcl.TYPE = 'CGROUP'
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserCustGroup.USER_NAME
   ORDER BY   "CUST_GROUP_LABEL"
/

