create view FCS_RPT_VIEW_JOIN as
  select 
    PP.PRODUCT_BRAND as PP_BRAND,
    PP.PRODUCT_CATEGORY as PP_CATEGORY,
    PP.PRODUCT_CLASS as PP_CLASS,
    PP.PRODUCT_EXT as PP_EXT,
    PP.PRODUCT_PACK as PP_PACK,   
    PA.PROPOSAL_ID as PROPOSAL_ID_AA,        
    PA.DISCOUNT_TYPE,
    pp.promo_produk_id,                              
    PP.BRG_BONUS_MF,
    PP.BRG_BONUS_ON_TOP,     
    PP.MEKANISME as PP_MEKANISME ,
    PP.DESCR as PP_DESCR,         
    BI.BIAYA_YEARLY, 
    BI.BIAYA_NON_YEARLY,  
    BU.DISC_YEARLY as BONUS_YEARLY,           
    BU.DISC_NON_YEARLY as BONUS_NON_YEARLY,    
    BU.UOM  as BONUS_UOM,      
    BU.PRODUCT_PACK as BONUS_PACK,    
    BU.PRODUCT_CLASS as BONUS_CLASS, 
    BU.PRODUCT_CATEGORY as BONUS_CATEGORY,
    BU.PRICE_VAL as BONUS_PRICE,       
    BU.PRODUCT_BRAND as BONUS_BRAND,
    BU.PRODUCT_EXT as BONUS_EXT,
    PI.PROD_ITEM, 
       (  
    select  listagg(item_description , ', ') within group (order by item_description) as item_descript
    from(
    select sum(panjang) over (partition by promo_produk_id order by item_description) as total_panjang, panjang, PROMO_PRODUK_ID,ITEM_DESCRIPTION
    from(
    select  distinct  PROMO_PRODUK_ID,FVI.ITEM_DESCRIPTION, length(item_description) as panjang, sum(length(item_description)) over (partition by promo_produk_id order by item_description)
    from FOCUSPP.PRODUK_ITEM PI,  APPS.FCS_VIEW_ITEM_MASTER_CATEGORY fvi
    where PI.PROD_ITEM = FVI.ITEM
    and PROMO_PRODUK_ID = pp.promo_produk_id
    order by 
    promo_produk_id, item_description
    )
    )
    where total_panjang <3500
    group by
    promo_produk_id
    ) as PROD_NAME,
    ( 
    select listagg(var.SET_VARIANT_DESC , ', ') within group (order by var.SET_VARIANT_DESC) as BONUS_VARIANT
    from(
    select  FVI.SET_VARIANT_DESC
    from FOCUSPP.PROMO_BONUS_VARIANT PBV, PROMO_BONUS BU, APPS.FCS_VIEW_ITEM_MASTER_CATEGORY fvi
    where PP.PROMO_PRODUK_ID =  BU.PROMO_PRODUK_ID(+) 
    and BU.PROMO_BONUS_ID = PBV.PROMO_BONUS_ID
    and PBV.PROD_VARIANT = fvi.SET_VARIANT
    group by
    BU.PROMO_PRODUK_ID,
    FVI.SET_VARIANT_DESC
    )var
    ) 
    as BONUS_VARIANT,
      ( select listagg(var.SET_VARIANT_DESC , ', ') within group (order by var.SET_VARIANT_DESC) as BONUS_VARIANT
    from(
    select  FVI.SET_VARIANT_DESC
    from FOCUSPP.produk_variant pv, APPS.FCS_VIEW_ITEM_MASTER_CATEGORY fvi
      where PP.PROMO_PRODUK_ID =PV.PROMO_PRODUK_ID
      and PV.PROD_VARIANT = FVI.SET_VARIANT
    group by
    PV.PROMO_PRODUK_ID,
    FVI.SET_VARIANT_DESC
    )var
    ) 
    as set_variant_desc,
    BU.QTY_FROM as BONUS_QTY,
    BI.DESCR as DESC_BIAYA,      
    DI.DISC_NON_YEARLY,
    DI.DISC_YEARLY,        
    DI.QTY_FROM as DISCOUNT_QTY_FORM,
    DI.QTY_TO as DISCOUNT_QTY_TO,       
    DI.KELIPATAN as DISCOUNT_KELIPATAN,
    DI.TIPE_PERHITUNGAN as DISCOUNT_PERHITUNGAN,          
    DI.TIPE_POTONGAN as DISCOUNT_TIPE,              
    TA.AVG_QTY as TA_AVG_QTY,
    TA.QTY as TA_QTY,
    TA.UOM as TA_UOM, 
    TA.PRICE as TA_PRICE,                     
    DI.UOM as UOM_DISCOUNT,       
    PP.DISC_MF,
    PP.DISC_ON_TOP,                   
    PP.BRG_BONUS_RASIO_MF,
    PP.BRG_BONUS_RASIO_ON_TOP,
    PP.BRG_BONUS_RASIO_TOTAL, 
    PP.DISC_RASIO_MF,
    PP.DISC_RASIO_ON_TOP,
    PP.DISC_RASIO_TOTAL
    From 
   FOCUSPP.PROPOSAL pa, 
   FOCUSPP.PROMO_PRODUK pp, 
   FOCUSPP.TARGET ta,
   FOCUSPP.BIAYA bi,
   FOCUSPP.PROMO_BONUS bu,
   FOCUSPP.DISCOUNT di,
   FOCUSPP.PRODUK_ITEM pi
   where PA.PROPOSAL_ID = PP.PROPOSAL_ID(+)
   and PP.PROMO_PRODUK_ID = TA.PROMO_PRODUK_ID (+)
   and PP.PROMO_PRODUK_ID = BI.PROMO_PRODUK_ID(+)
   and PP.PROMO_PRODUK_ID = BU.PROMO_PRODUK_ID(+)
   and PP.PROMO_PRODUK_ID = DI.PROMO_PRODUK_ID(+)
   and PP.PROMO_PRODUK_ID = PI.PROMO_PRODUK_ID(+)
    group by 
    PP.PRODUCT_BRAND,
    PP.PRODUCT_CATEGORY,
    PP.PRODUCT_CLASS,
    PP.PRODUCT_EXT,
    PP.PRODUCT_PACK,   
    PA.PROPOSAL_ID,    
    PA.DISCOUNT_TYPE,  
    pp.promo_produk_id,                              
    PP.BRG_BONUS_MF,
    PP.BRG_BONUS_ON_TOP,     
    PP.MEKANISME ,
    PP.DESCR,         
    BI.BIAYA_YEARLY, 
    BI.BIAYA_NON_YEARLY,  
    BU.DISC_YEARLY,           
    BU.DISC_NON_YEARLY,    
    BU.UOM,      
    BU.PRODUCT_PACK,         
    BU.PRODUCT_CLASS, 
    BU.PRODUCT_CATEGORY,  
    BU.PRODUCT_BRAND,
    BU.PRODUCT_EXT,   
    BU.PRICE_VAL,
    BU.QTY_FROM,
    BI.DESCR,      
    DI.DISC_NON_YEARLY,
    DI.DISC_YEARLY,        
    DI.QTY_FROM,
    DI.QTY_TO,
    DI.TIPE_PERHITUNGAN,          
    DI.TIPE_POTONGAN,       
    DI.KELIPATAN,      
    TA.AVG_QTY,
    TA.QTY,
    TA.UOM,        
    TA.PRICE,              
     DI.UOM,       
     PP.DISC_MF,
     PP.DISC_ON_TOP,
     PP.BRG_BONUS_RASIO_MF,
     PP.BRG_BONUS_RASIO_ON_TOP,
     PP.BRG_BONUS_RASIO_TOTAL, 
     PP.DISC_RASIO_MF,
     PP.DISC_RASIO_ON_TOP,
     PP.DISC_RASIO_TOTAL,
     PI.PROD_ITEM
/

