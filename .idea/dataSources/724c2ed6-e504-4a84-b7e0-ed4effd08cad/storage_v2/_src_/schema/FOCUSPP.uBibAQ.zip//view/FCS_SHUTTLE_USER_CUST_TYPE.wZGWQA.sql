create view FCS_SHUTTLE_USER_CUST_TYPE as
  SELECT   ArCustomers.ATTRIBUTE8 AS CUST_TYPE_CODE,
                 ArCustomers.ATTRIBUTE8
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE8)
                 CUST_TYPE_LABEL,
              AppUserLoc.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_LOC AppUserLoc,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.ATTRIBUTE5 = AppUserLoc.LOCATION_CODE
              AND ArCustomers.STATUS = 'A'
   GROUP BY   ArCustomers.ATTRIBUTE5,
              ArCustomers.ATTRIBUTE8,
              AppUserLoc.USER_NAME,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE3
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS CUST_TYPE_CODE,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS CUST_TYPE_LABEL,
              AppUserAccess.USER_NAME,
              'REGIONX' AS REGION_CODE,
              'AREAX' AS AREA_CODE,
              'LOCATIONX' AS LOC_CODE
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_ACCESS AppUserAccess
      WHERE   FcsViewAttrExcl.TYPE = 'CTYPES'  AND FcsViewAttrExcl.VALUE NOT IN (SELECT ArCustomers.ATTRIBUTE8
       FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_REGION AUR
      WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE AND AUR.USER_NAME = AppUserAccess.USER_NAME)
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserAccess.USER_NAME
/

