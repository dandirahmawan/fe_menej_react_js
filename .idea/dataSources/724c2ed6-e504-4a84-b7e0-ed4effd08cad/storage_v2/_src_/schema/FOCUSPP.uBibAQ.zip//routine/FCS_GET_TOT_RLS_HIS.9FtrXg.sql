create function fcs_get_tot_rls_his (in_pp_id in number, discount_type in string) return number
is
--declare
    ppid number := in_pp_id;
    ppidx number;
    tempnum number := 0;
    tempmf number := 0;
    tot number := 0;
begin
    while ppid is not null
    loop
--        dbms_output.put_line('pp: ' || ppid);
--        dbms_output.put_line('total: ' || tot);
        begin
            if discount_type = 'BIAYA' then
                select nvl(total, 0) into tempnum from apps.fcs_view_realisasi_gr where promo_produk_id = ppid;
            elsif discount_type = 'POTONGAN' then
                select nvl(amount, 0) into tempnum from apps.fcs_view_realisasi_modifier where promo_produk_id = ppid;
            else
                select nvl(total, 0) into tempnum from apps.fcs_view_realisasi_promobarang where promo_produk_id = ppid;
            end if;
        end;
        
        begin
--            select bia_mf into tempmf from focuspp.promo_produk where promo_produk_id = ppid;
            select nvl(sum(amount), 0) into tempmf from focuspp.prod_budget_by where promo_produk_id = ppid group by promo_produk_id;
        end;
        
        if tempnum > tempmf then
            tot := tot + tempmf;
        else
            tot := tot + tempnum;
        end if;
        
        begin
            select ppid_ref into ppidx from focuspp.promo_produk where promo_produk_id = ppid;
        exception
            when others then ppid := null;
        end;
        
        if ppidx is null or ppidx = 0 then
            ppid := null;
        else
            ppid := ppidx;
        end if;
    end loop;
    return tot;
--    dbms_output.put_line('xxx: ' || tot);
end;
/

