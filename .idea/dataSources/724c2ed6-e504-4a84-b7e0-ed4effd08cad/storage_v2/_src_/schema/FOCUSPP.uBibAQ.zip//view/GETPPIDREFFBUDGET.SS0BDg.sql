create view GETPPIDREFFBUDGET as
  SELECT Proposal.PROPOSAL_ID,
            PROMPROD.PROMO_PRODUK_ID,
            PROMPROD.PPID_REF,
            PROMPROD.PRODUCT_APPROVAL,
            PRODBUDBY.BUDGET_BY_ID,
            PRODBUDBY.BUDGET_CUST_ID,
            PRODBUDBY.AMOUNT,
            PRODBUDBY.OVER_BUDGET_AMT,
            PRODBUDBY.STATUS,
            PRODBUDBY.FLAG_STATUS_OVER,
            Proposal.PROPOSAL_NO,
            Proposal.CONFIRM_DATE,
            Proposal.CONFIRM_NO,
            Proposal.ADDENDUM_KE,
            Proposal.CATEGORY_PC
       FROM PROPOSAL Proposal, promo_produk promprod, prod_budget_by prodBudBy
      WHERE NVL (Proposal.ADDENDUM_KE, 0) =
               (SELECT MAX (NVL (PROP.ADDENDUM_KE, 0))
                  FROM PROPOSAL PROP
                 WHERE PROP.CONFIRM_NO = Proposal.CONFIRM_NO)
            AND PROPOSAL.PROPOSAL_ID = promprod.PROPOSAL_ID
            AND PROMPROD.PROMO_PRODUK_ID = PRODBUDBY.PROMO_PRODUK_ID(+)
            AND PROMPROD.PPID_REF IS NOT NULL
            AND PROMPROD.PPID_REF != '0'
   ORDER BY BUDGET_BY_ID
/

