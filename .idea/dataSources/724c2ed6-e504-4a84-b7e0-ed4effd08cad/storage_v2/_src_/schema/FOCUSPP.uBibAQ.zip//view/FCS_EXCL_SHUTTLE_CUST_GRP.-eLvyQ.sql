create view FCS_EXCL_SHUTTLE_CUST_GRP as
  select arc.attribute1 AS cust_group_code,
            arc.attribute1 || ' ' || flex.description AS cust_group_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
            arc.attribute5 AS loc_code,
            arc.attribute8 AS cust_type_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION pg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute3 = pg.region_code
and aur.region_code = arc.attribute3 
and arc.status = 'A'
and prod.promo_produk_id = pg.promo_produk_id
and flex.flex_value = arc.attribute1
group by arc.attribute8, aur.user_name, arc.attribute4, arc.attribute3, arc.attribute5, arc.attribute1, prod.promo_produk_id, flex.description
union
select arc.attribute1 AS cust_group_code,
            arc.attribute1 || ' ' || flex.description AS cust_group_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
            arc.attribute5 AS loc_code,
            arc.attribute8 AS cust_type_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION_AREA pra, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute4 = pra.area_code
and aur.region_code = arc.attribute3 
and arc.status = 'A'
and prod.promo_produk_id = pra.promo_produk_id
and flex.flex_value = arc.attribute1
group by arc.attribute1, aur.user_name, arc.attribute4, arc.attribute3, arc.attribute5, arc.attribute1,arc.attribute8, prod.promo_produk_id, flex.description
union
select arc.attribute1 AS cust_group_code,
            arc.attribute1 || ' ' || flex.description AS cust_group_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
            arc.attribute5 AS loc_code,
            arc.attribute8 AS cust_type_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION_LOC prl, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute5 = prl.location_code
and aur.region_code = arc.attribute3  
and arc.status = 'A'
and prod.promo_produk_id = prl.promo_produk_id
and flex.flex_value = arc.attribute1
group by arc.attribute8, aur.user_name, arc.attribute4, arc.attribute3, arc.attribute5, arc.attribute1,arc.attribute8, prod.promo_produk_id, flex.description
union
select arc.attribute1 AS cust_group_code,
            arc.attribute1 || ' ' || flex.description AS cust_group_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
            arc.attribute5 AS loc_code,
            arc.attribute8 AS cust_type_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION_CUST_TYPE prct, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute8 = prct.cust_type
and aur.region_code = arc.attribute3  
and arc.status = 'A'
and prod.promo_produk_id = prct.promo_produk_id
and flex.flex_value = arc.attribute1
group by arc.attribute8, aur.user_name, arc.attribute4, arc.attribute3, arc.attribute5, arc.attribute1,arc.attribute8, prod.promo_produk_id, flex.description
order by 1
/

