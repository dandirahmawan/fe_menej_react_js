create view FCS_EXCL_SHUTTLE_CUSTOMER_PROP as
  select arc.customer_id AS customer_id,
            arc.customer_name AS customer_name,
            arc.customer_number AS customer_number,
            arc.customer_number || ' - ' || CAV.ACCOUNT_NAME || ' - ' || flex.description AS customer_full_name,
            aur.user_name AS user_name,
            arc.attribute5 AS location_code,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION_CUST_GROUP rcg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
where arc.attribute1 = rcg.cust_group
and aur.region_code = arc.attribute3 
and flex.flex_value = arc.attribute5
and arc.status = 'A'
AND arc.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
and prod.proposal_id = rcg.proposal_id
GROUP BY arc.customer_id,
            arc.customer_number,
            arc.customer_name,
            CAV.ACCOUNT_NAME,
            aur.user_name,
            arc.attribute3,
            arc.attribute4,
            arc.attribute5,
            prod.promo_produk_id,
            flex.description
union
select arc.customer_id AS customer_id,
            arc.customer_name AS customer_name,
            arc.customer_number AS customer_number,
            arc.customer_number || ' - ' || CAV.ACCOUNT_NAME || ' - ' || flex.description AS customer_full_name,
            aur.user_name AS user_name,
            arc.attribute5 AS location_code,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION pg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
where arc.attribute3 = pg.region_code
and aur.region_code = arc.attribute3 
and flex.flex_value = arc.attribute5
and arc.status = 'A'
AND arc.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
and prod.proposal_id = pg.proposal_id
GROUP BY arc.customer_id,
            arc.customer_number,
            arc.customer_name,
            CAV.ACCOUNT_NAME,
            aur.user_name,
            arc.attribute3,
            arc.attribute4,
            arc.attribute5,
            prod.promo_produk_id,
            flex.description
union
select arc.customer_id AS customer_id,
            arc.customer_name AS customer_name,
            arc.customer_number AS customer_number,
            arc.customer_number || ' - ' || CAV.ACCOUNT_NAME || ' - ' || flex.description AS customer_full_name,
            aur.user_name AS user_name,
            arc.attribute5 AS location_code,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION_AREA pra, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
where arc.attribute4 = pra.area_code
and aur.region_code = arc.attribute3 
and flex.flex_value = arc.attribute5
and arc.status = 'A'
AND arc.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
and prod.proposal_id = pra.proposal_id
GROUP BY arc.customer_id,
            arc.customer_number,
            arc.customer_name,
            CAV.ACCOUNT_NAME,
            aur.user_name,
            arc.attribute3,
            arc.attribute4,
            arc.attribute5,
            prod.promo_produk_id,
            flex.description
union
select arc.customer_id AS customer_id,
            arc.customer_name AS customer_name,
            arc.customer_number AS customer_number,
            arc.customer_number || ' - ' || CAV.ACCOUNT_NAME || ' - ' || flex.description AS customer_full_name,
            aur.user_name AS user_name,
            arc.attribute5 AS location_code,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION_LOC prl, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex, APPS.FCS_CUST_ACCOUNTS_VIEW CAV
where arc.attribute5 = prl.location_code
and aur.region_code = arc.attribute3 
and flex.flex_value = arc.attribute5
and arc.status = 'A'
AND arc.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
and prod.proposal_id = prl.proposal_id
GROUP BY arc.customer_id,
            arc.customer_number,
            arc.customer_name,
            CAV.ACCOUNT_NAME,
            aur.user_name,
            arc.attribute3,
            arc.attribute4,
            arc.attribute5,
            prod.promo_produk_id,
            flex.description
order by 1
/

