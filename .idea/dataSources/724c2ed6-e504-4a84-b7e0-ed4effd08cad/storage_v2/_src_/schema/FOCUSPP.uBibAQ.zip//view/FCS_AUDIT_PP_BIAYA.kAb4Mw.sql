create view FCS_AUDIT_PP_BIAYA as
  select produk_line, full_name, task_role, proposal_id, promo_produk_id, field_name, field_value from (
SELECT B.PRODUK_LINE,
       B.PROPOSAL_ID,
       B.AUDIT_ID,
       B.PROMO_PRODUK_ID,
       UPPER(B.FULL_NAME) AS FULL_NAME,
       B.TASK_ROLE,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_PRODUCT_CLASS = B.PRODUCT_CLASS))  THEN '' ELSE (SELECT mc.description FROM apps.mtl_categories_v mc WHERE mc.category_concat_segs = B.PRODUCT_CLASS AND mc.structure_name = 'FCS_CLASS') END AS PRODUK_CLASS,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_PRODUCT_BRAND = B.PRODUCT_BRAND))  THEN '' ELSE (SELECT MC.DESCRIPTION FROM APPS.MTL_CATEGORIES_V MC WHERE MC.CATEGORY_CONCAT_SEGS = B.PRODUCT_BRAND AND MC.STRUCTURE_NAME = 'FCS_BRAND') END AS PRODUK_BRAND,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_PRODUCT_EXT = B.PRODUCT_EXT))  THEN '' ELSE (SELECT MC.DESCRIPTION FROM APPS.MTL_CATEGORIES_V MC WHERE MC.CATEGORY_CONCAT_SEGS = B.PRODUCT_EXT AND MC.STRUCTURE_NAME = 'FCS_EXTENTION') END AS PRODUK_EXTENTION,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_PRODUCT_PACK = B.PRODUCT_PACK))  THEN '' ELSE (SELECT MC.DESCRIPTION FROM APPS.MTL_CATEGORIES_V MC WHERE MC.CATEGORY_CONCAT_SEGS = B.PRODUCT_PACK AND MC.STRUCTURE_NAME = 'FCS_PACKAGING') END AS PRODUK_PACKAGING,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_PRODUCT_VARIANT = B.PRODUCT_VARIANT))  THEN '' ELSE B.PRODUCT_VARIANT END AS PRODUK_VARIANT,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_PRODUCT_ITEM = B.PRODUCT_ITEM))  THEN '' ELSE B.PRODUCT_ITEM END AS PRODUK_ITEM,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_TARGET_PRICE = B.TARGET_PRICE))  THEN '' ELSE B.TARGET_PRICE END AS PRICE_TARGET,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_BIAYA_NON_YEARLY = B.BIAYA_NON_YEARLY))  THEN '' ELSE B.BIAYA_NON_YEARLY END AS BIAYA_TPB_OT,
       CASE WHEN (B.TASK_ROLE = 'Approver' AND (B.PREV_BIAYA_YEARLY = B.BIAYA_YEARLY))  THEN '' ELSE B.BIAYA_YEARLY END AS BIAYA_PB_MF,
       B.APPROVAL_ACTION AS APPROVE_ACTION
FROM (
SELECT row_number() over (partition by ap.proposal_id, ap.audit_id order by app.promo_produk_id) as produk_line, 
       ap.proposal_id,
       ap.audit_id,
       app.promo_produk_id,
       ap.approval_action,
       NVL (ap.modified_by, ap.created_by) AS user_name,
       NVL (ua.full_name, ap.created_by) AS full_name,
       CASE WHEN modified_date IS NULL THEN 'Requester' ELSE 'Approver' END  AS task_role,
       APP.PRODUCT_CLASS,
       NVL(LAG (APP.PRODUCT_CLASS,1) OVER (partition by app.promo_produk_id ORDER BY APP.PRODUCT_CLASS),APP.PRODUCT_CLASS) AS PREV_PRODUCT_CLASS,
       APP.PRODUCT_BRAND,
       NVL(LAG (APP.PRODUCT_BRAND,1) OVER (partition by app.promo_produk_id ORDER BY APP.PRODUCT_BRAND),APP.PRODUCT_BRAND) AS PREV_PRODUCT_BRAND,
       APP.PRODUCT_EXT,
       NVL(LAG(APP.PRODUCT_EXT,1) OVER (partition by app.promo_produk_id ORDER BY APP.PRODUCT_EXT),APP.PRODUCT_EXT) AS PREV_PRODUCT_EXT,
       APP.PRODUCT_PACK,
       NVL(LAG(APP.PRODUCT_PACK,1) OVER (partition by app.promo_produk_id ORDER BY APP.PRODUCT_PACK),APP.PRODUCT_PACK) AS PREV_PRODUCT_PACK,
       (SELECT RTRIM(dbms_lob.substr(REPLACE(          REPLACE(            XMLAGG(              XMLELEMENT("A",PV.VARIANT_DESC)            ORDER BY 1).getClobVal(),          '<A>',''),        '</A>',', '), 1995, 1 ), ', ') FROM AUDIT_PRODUK_VARIANT PV  WHERE PV.PROMO_PRODUK_ID = APP.PROMO_PRODUK_ID AND PV.AUDIT_ID = APP.AUDIT_ID GROUP BY PV.PROMO_PRODUK_ID) AS PRODUCT_VARIANT,
       NVL(LAG((SELECT RTRIM(dbms_lob.substr(REPLACE(          REPLACE(            XMLAGG(              XMLELEMENT("A",PV.VARIANT_DESC)            ORDER BY 1).getClobVal(),          '<A>',''),        '</A>',', '), 1995, 1 ), ', ') FROM AUDIT_PRODUK_VARIANT PV  WHERE PV.PROMO_PRODUK_ID = APP.PROMO_PRODUK_ID AND PV.AUDIT_ID = APP.AUDIT_ID GROUP BY PV.PROMO_PRODUK_ID),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id,APP.PROMO_PRODUK_ID),(SELECT RTRIM(dbms_lob.substr(REPLACE(          REPLACE(            XMLAGG(              XMLELEMENT("A",PV.VARIANT_DESC)            ORDER BY 1).getClobVal(),          '<A>',''),        '</A>',','), 1995, 1 ), ',') FROM AUDIT_PRODUK_VARIANT PV  WHERE PV.PROMO_PRODUK_ID = APP.PROMO_PRODUK_ID AND PV.AUDIT_ID = APP.AUDIT_ID GROUP BY PV.PROMO_PRODUK_ID)) AS PREV_PRODUCT_VARIANT,
       (SELECT RTRIM(dbms_lob.substr(REPLACE(          REPLACE(            XMLAGG(              XMLELEMENT("A",PI.ITEM_DESC)            ORDER BY 1).getClobVal(),          '<A>',''),        '</A>',', '), 1995, 1 ), ', ') FROM AUDIT_PRODUK_ITEM PI  WHERE PI.PROMO_PRODUK_ID = APP.PROMO_PRODUK_ID AND PI.AUDIT_ID = APP.AUDIT_ID GROUP BY PI.PROMO_PRODUK_ID) AS PRODUCT_ITEM,
       NVL(LAG((SELECT RTRIM(dbms_lob.substr(REPLACE(          REPLACE(            XMLAGG(              XMLELEMENT("A",PI.ITEM_DESC)            ORDER BY 1).getClobVal(),          '<A>',''),        '</A>',', '), 1995, 1 ), ', ') FROM AUDIT_PRODUK_ITEM PI  WHERE PI.PROMO_PRODUK_ID = APP.PROMO_PRODUK_ID AND PI.AUDIT_ID = APP.AUDIT_ID GROUP BY PI.PROMO_PRODUK_ID),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id,APP.PROMO_PRODUK_ID),(SELECT RTRIM(dbms_lob.substr(REPLACE(          REPLACE(            XMLAGG(              XMLELEMENT("A",PI.ITEM_DESC)            ORDER BY 1).getClobVal(),          '<A>',''),        '</A>',','), 1995, 1 ), ',') FROM AUDIT_PRODUK_ITEM PI  WHERE PI.PROMO_PRODUK_ID = APP.PROMO_PRODUK_ID AND PI.AUDIT_ID = APP.AUDIT_ID GROUP BY PI.PROMO_PRODUK_ID)) AS PREV_PRODUCT_ITEM,
       to_char(nvl(tgt.qty,0)) AS target_qty,
       NVL(LAG(to_char(nvl(tgt.qty,0)),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id),to_char(nvl(tgt.qty,0))) AS prev_target_qty,
       to_char(nvl(tgt.price,0)) as target_price,
       NVL(LAG(to_char(nvl(tgt.price,0)),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id),to_char(nvl(tgt.price,0))) as prev_target_price,
       to_char(nvl(bia.biaya_qty,0)) AS biaya_qty,
       NVL(LAG(to_char(nvl(bia.biaya_qty,0)),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id),to_char(nvl(bia.biaya_qty,0))) AS prev_biaya_qty,
       to_char(nvl(bia.biaya_price,0)) AS biaya_price,
       NVL(LAG(to_char(nvl(bia.biaya_price,0)),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id),to_char(nvl(bia.biaya_price,0))) AS prev_biaya_price,
       bia.biaya_uom, 
       NVL(LAG(bia.biaya_uom,1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id),bia.biaya_uom) as prev_biaya_uom,
       to_char(nvl(bia.biaya_non_yearly,0)) AS biaya_non_yearly,
       NVL(LAG(to_char(nvl(bia.biaya_non_yearly,0)),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id),bia.biaya_non_yearly) as prev_biaya_non_yearly,
       to_char(nvl(bia.biaya_yearly,0)) AS biaya_yearly,
       NVL(LAG(to_char(nvl(bia.biaya_yearly,0)),1) OVER (partition by app.promo_produk_id ORDER BY ap.proposal_id, ap.audit_id),bia.biaya_yearly) as prev_biaya_yearly
    FROM   audit_proposal ap, app_user_access ua, audit_promo_produk app, audit_target tgt, audit_biaya bia
   WHERE   NVL (ap.modified_by, ap.created_by) = ua.user_name
           AND app.audit_id = ap.audit_id
           and app.proposal_id = ap.proposal_id
           and tgt.audit_id = ap.audit_id
           and tgt.promo_produk_id = app.promo_produk_id
           and bia.audit_id = ap.audit_id
           and bia.promo_produk_id = app.promo_produk_id
ORDER BY ap.audit_id
) B
) unpivot include nulls (field_value for field_name in (approve_action, produk_class, produk_brand, produk_extention, produk_packaging, produk_variant, produk_item, price_target, BIAYA_TPB_OT, biaya_pb_mf))
/

