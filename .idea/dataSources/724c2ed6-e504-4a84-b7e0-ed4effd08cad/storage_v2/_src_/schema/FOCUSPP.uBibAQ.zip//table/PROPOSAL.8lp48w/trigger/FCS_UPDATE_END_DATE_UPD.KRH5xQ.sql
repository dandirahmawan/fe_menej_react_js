create trigger FCS_UPDATE_END_DATE_UPD
  after update
  on PROPOSAL
  for each row
  DECLARE
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    -- CREATED BY   : MII - SODIQ MR.
    -- CREATE DATE  : 13-APR-2018
    -- REASON       : DIGUNAKAN UNTUK UPDATE END DATE KETIKA ADDENDUM DI CANCEL

    IF :OLD.ADDENDUM_KE IS NOT NULL AND :NEW.STATUS = 'CANCELED' AND :OLD.DISCOUNT_TYPE <> 'BIAYA' THEN
        
        UPDATE FOCUSPP.PROPOSAL PC
        SET PC.PERIODE_PROG_TO = (
                                    SELECT PC3.PP_PROG_TO_ORI
                                    FROM FOCUSPP.PROPOSAL PC3
                                    WHERE PC3.CONFIRM_NO = :OLD.CONFIRM_NO
                                    AND NVL(PC3.ADDENDUM_KE,0) = 
                                    (
                                        SELECT MAX(NVL(PC2.ADDENDUM_KE,0))
                                        FROM FOCUSPP.PROPOSAL PC2
                                        WHERE PC2.CONFIRM_NO = :OLD.CONFIRM_NO
                                        AND PC2.STATUS = 'ACTIVE'
                                        AND NVL(PC2.ADDENDUM_KE,0) < :OLD.ADDENDUM_KE
                                    )
                                 )
            , PC.PROG_DAYS = (
                                SELECT (PC3.PP_PROG_TO_ORI - PC3.PP_PROG_FROM_ORI)+1
                                FROM FOCUSPP.PROPOSAL PC3
                                WHERE PC3.CONFIRM_NO = :OLD.CONFIRM_NO
                                AND NVL(PC3.ADDENDUM_KE,0) = 
                                (
                                    SELECT MAX(NVL(PC2.ADDENDUM_KE,0))
                                    FROM FOCUSPP.PROPOSAL PC2
                                    WHERE PC2.CONFIRM_NO = :OLD.CONFIRM_NO
                                    AND PC2.STATUS = 'ACTIVE'
                                    AND NVL(PC2.ADDENDUM_KE,0) < :OLD.ADDENDUM_KE
                                )
                             )
        WHERE PC.CONFIRM_NO = :OLD.CONFIRM_NO
        AND NVL(PC.ADDENDUM_KE,0) =
        (
            SELECT MAX(NVL(PC1.ADDENDUM_KE,0))
            FROM FOCUSPP.PROPOSAL PC1
            WHERE PC1.CONFIRM_NO = :OLD.CONFIRM_NO
            AND PC1.STATUS = 'ACTIVE'
            AND NVL(PC1.ADDENDUM_KE,0) < :OLD.ADDENDUM_KE
        );
        
        COMMIT;
        
    END IF;
    
    IF NVL(:NEW.ADDENDUM_KE,'0') > NVL(:OLD.ADDENDUM_KE,'0') AND NVL(:NEW.ADDENDUM_KE,'0') > 0 AND :NEW.STATUS = 'ACTIVE' AND :OLD.DISCOUNT_TYPE <> 'BIAYA' THEN
    
        UPDATE FOCUSPP.PROPOSAL PC
        SET PC.PERIODE_PROG_TO = :NEW.PERIODE_PROG_FROM-1
          , PC.PROG_DAYS = (:NEW.PERIODE_PROG_FROM - PC.PERIODE_PROG_FROM)
        WHERE PC.CONFIRM_NO = :NEW.CONFIRM_NO
        AND NVL(PC.ADDENDUM_KE,0) =
        (
            SELECT MAX(NVL(PC1.ADDENDUM_KE,0))
            FROM FOCUSPP.PROPOSAL PC1
            WHERE PC1.CONFIRM_NO = :NEW.CONFIRM_NO
            AND PC1.STATUS = 'ACTIVE'
            AND NVL(PC1.ADDENDUM_KE,0) < :NEW.ADDENDUM_KE
        );
        
        COMMIT;
        
    END IF;
    
    IF NVL(:NEW.ADDENDUM_KE,'0') > NVL(:OLD.ADDENDUM_KE,'0') AND NVL(:NEW.ADDENDUM_KE,'0') > 0 AND :NEW.STATUS = 'ACTIVE' AND :OLD.DISCOUNT_TYPE = 'BIAYA' THEN
        UPDATE FOCUSPP.PROPOSAL PC
        SET STATUS = 'CANCELED'
        WHERE PC.CONFIRM_NO = :NEW.CONFIRM_NO
        AND NVL(PC.ADDENDUM_KE,0) =
        (
            SELECT MAX(NVL(PC1.ADDENDUM_KE,0))
            FROM FOCUSPP.PROPOSAL PC1
            WHERE PC1.CONFIRM_NO = :NEW.CONFIRM_NO
            AND PC1.STATUS = 'ACTIVE'
            AND NVL(PC1.ADDENDUM_KE,0) < :NEW.ADDENDUM_KE
        );
        
        COMMIT;
        
    END IF;
    
    
END;
/

