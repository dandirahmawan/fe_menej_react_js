create view FCS_SHUTTLE_REGION as
  SELECT   ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE3 || ' ' || flex.DESCRIPTION AS REGION_LABEL,
              AUR.USER_NAME
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_REGION AUR,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE
              AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE3
   GROUP BY   ArCustomers.ATTRIBUTE3, flex.DESCRIPTION, AUR.USER_NAME
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS REGION_CODE,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS REGION_LABEL,
              AppUserRegion.USER_NAME
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_REGION AppUserRegion
      WHERE   FcsViewAttrExcl.VALUE = AppUserRegion.REGION_CODE
              AND FcsViewAttrExcl.TYPE = 'REGION'
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserRegion.USER_NAME
   ORDER BY   "REGION_LABEL"
/

