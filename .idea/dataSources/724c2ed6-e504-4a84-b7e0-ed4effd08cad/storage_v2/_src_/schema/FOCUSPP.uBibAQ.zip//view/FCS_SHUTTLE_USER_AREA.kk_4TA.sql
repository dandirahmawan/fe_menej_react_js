create view FCS_SHUTTLE_USER_AREA as
  SELECT   ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE4 AS DESCRIPTION,
              (   ArCustomers.ATTRIBUTE4
               || ' '
               || (SELECT   flex2.DESCRIPTION
                     FROM   APPS.FCS_FLEX_VALUES_VL flex2
                    WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE4))
                 AS AREA_LABEL,
              AUR.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_REGION AUR,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE
              AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE3
   GROUP BY   ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE3,
              flex.DESCRIPTION,
              AUR.USER_NAME 
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS AREA_CODE,
              FcsViewAttrExcl.DESCRIPTION,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS AREA_LABEL,
              AppUserAccess.USER_NAME,
              'REGIONX' AS REGION_CODE
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_ACCESS AppUserAccess
      WHERE   FcsViewAttrExcl.TYPE = 'AREA' AND  FcsViewAttrExcl.VALUE NOT IN (SELECT ArCustomers.ATTRIBUTE4
       FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_REGION AUR
      WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE AND AUR.USER_NAME = AppUserAccess.USER_NAME)
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserAccess.USER_NAME
   ORDER BY   "AREA_LABEL"
/

