create FUNCTION get_posting_c (  p_proposal nvarchar2(20)
                            ) RETURN   nvarchar2
IS
 posting_c nvarchar2 (200) ;
begin
select 
fvi.item_description
into posting_c
from 
proposal pa,
promo_produk pp,
PROD_BUDGET_BY pbb, 
budget_customer bc,
budget_cust_hdr bch,
APPS.FCS_VIEW_ITEM_MASTER_CATEGORY fvi
where 1=1
and pa.proposal_ID = PP.PROPOSAL_ID
and PP.PROMO_PRODUK_ID = PBB.PROMO_PRODUK_ID 
and PBB.BUDGET_CUST_ID = BC.BUDGET_CUSTOMER_ID
and BC.BUDGET_CUST_HDR_ID = BCH.BUDGET_CUST_HDR_ID
and BCH.KODE_POSTING = fvi.item
and BCH.BUDGET_TYPE = 'POSTING'
and pa.proposal_id = p_proposal
  /

