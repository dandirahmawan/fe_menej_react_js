create view FCS_SHUTTLE_USER_REGION as
  SELECT   ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE3 || ' ' || flex.DESCRIPTION AS REGION_LABEL,
              AUR.USER_NAME
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_REGION AUR,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE
              AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE3
   GROUP BY   ArCustomers.ATTRIBUTE3, flex.DESCRIPTION, AUR.USER_NAME
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS REGION_CODE,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS REGION_LABEL,
              AppUserAccess.USER_NAME
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_ACCESS AppUserAccess
      WHERE   FcsViewAttrExcl.TYPE = 'REGION'  AND FcsViewAttrExcl.VALUE NOT IN (SELECT ArCustomers.ATTRIBUTE3
       FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_REGION AUR
      WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE AND AUR.USER_NAME = AppUserAccess.USER_NAME)
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserAccess.USER_NAME
   ORDER BY   "REGION_LABEL"
/

