create function         rpt_f_barang (p1 number) 
return varchar2
as
  MAX_FIELD_LEN constant number := 3500;
  toret varchar2(4000);
  v_type varchar2(1000);
  v_variant varchar2(1000);
  v_produk varchar2(4000);
BEGIN
    BEGIN
      select 
     (SELECT description
       FROM apps.mtl_categories_v
      WHERE category_concat_segs = pp.PRODUCT_CATEGORY
        AND structure_name = 'FCS_CATEGORY')||' - '||
     (SELECT description
       FROM apps.mtl_categories_v
      WHERE category_concat_segs = pp.PRODUCT_CLASS
        AND structure_name = 'FCS_CLASS')||' - '||
     (SELECT description
       FROM apps.mtl_categories_v
      WHERE category_concat_segs = pp.PRODUCT_BRAND
        AND structure_name = 'FCS_BRAND')||' - '||
     (SELECT description
       FROM apps.mtl_categories_v
      WHERE category_concat_segs = pp.PRODUCT_EXT
        AND structure_name = 'FCS_EXTENTION')||' - '||
     (SELECT description
       FROM apps.mtl_categories_v
      WHERE category_concat_segs = pp.PRODUCT_PACK
        AND structure_name = 'FCS_PACKAGING')
    INTO v_type
    from focuspp.promo_produk pp
    where pp.promo_produk_id = p1;

    BEGIN
        SELECT listagg(var.description , ', ') within group (order by var.description)
        INTO v_variant
        from(    
        select  description
        from FOCUSPP.produk_variant pv, apps.mtl_categories_v
        where PV.PROD_VARIANT = category_concat_segs
        and PV.PROMO_PRODUK_ID = p1
        and structure_name = 'FCS_VARIANT'
        ) var ;
        IF v_variant IS NOT NULL THEN 
            v_variant := ' - '||v_variant;
        END IF;
    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
    END;

    IF ltrim(rtrim(v_variant)) = '- ALL' THEN
        SELECT listagg(pr.item_description,', ') within group (order by pr.item_description) ||
        decode(trunc(t/3600),0,'',', ...') dd
        INTO v_produk
        FROM (        
            select v.item_description, length(v.item_description) l
            ,sum(length(v.item_description)) over (order by v.item_description) r
            ,sum(length(v.item_description)+2) over () t
            from produk_item i, apps.fcs_view_item_master_category v
            where v.item = i.prod_item
            and v.type_table = 'MASTER'
            and promo_produk_id = p1
        ) pr
        WHERE r < 3600
        group by t;

        IF v_produk IS NOT NULL THEN 
            v_produk := ' - '||v_produk;
        END IF;
    END IF;

    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
    END;
    
        toret := v_type || v_variant || v_produk;

  RETURN (toret);
END;
/

