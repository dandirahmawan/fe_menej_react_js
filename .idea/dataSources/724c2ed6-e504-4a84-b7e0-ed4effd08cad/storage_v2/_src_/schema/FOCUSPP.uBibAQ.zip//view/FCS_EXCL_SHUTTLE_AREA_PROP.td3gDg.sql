create view FCS_EXCL_SHUTTLE_AREA_PROP as
  select arc.attribute4 AS area_code,
arc.attribute4 AS description,
arc.attribute4 || ' ' || flex.description AS area_label,
aur.user_name AS user_name,           
arc.attribute1 AS cust_group_code,
arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION_CUST_GROUP rcg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute1 = rcg.cust_group
and aur.region_code = arc.attribute3
and arc.status = 'A'
and prod.proposal_id = rcg.proposal_id
and flex.flex_value = arc.attribute4
group by arc.attribute4, arc.attribute1, arc.attribute3, aur.user_name, prod.promo_produk_id, flex.description
union
select arc.attribute4 AS area_code,
arc.attribute4 AS description,
arc.attribute4 || ' ' || flex.description AS area_label,
aur.user_name AS user_name,           
arc.attribute1 AS cust_group_code,
arc.attribute3 AS region_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION pg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute3 = pg.region_code
and aur.region_code = arc.attribute3
and arc.status = 'A'
and prod.proposal_id = pg.proposal_id
and flex.flex_value = arc.attribute4
group by arc.attribute4, arc.attribute1, arc.attribute3, aur.user_name, prod.promo_produk_id, flex.description
order by 1
/

