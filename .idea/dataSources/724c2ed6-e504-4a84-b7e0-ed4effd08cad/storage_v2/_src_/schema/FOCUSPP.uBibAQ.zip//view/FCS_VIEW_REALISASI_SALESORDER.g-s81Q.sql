create view FCS_VIEW_REALISASI_SALESORDER as
  SELECT pr.proposal_no, pr.confirm_no, 'Yes' order_ket
     FROM proposal pr
    WHERE pr.mekanisme_penagihan = 'ONINVOICE'
          AND EXISTS
                 (SELECT 1
                    FROM promo_produk pp,
                         realisasi_item_paket rip,
                         apps.oe_order_headers_all ooh,
                         apps.oe_order_lines_all ool,
                         apps.mtl_system_items_b msi
                   WHERE     pr.proposal_id = pp.proposal_id
                         AND rip.promo_produk_id = pp.promo_produk_id
                         AND rip.kd_item_paket = msi.segment1
                         AND msi.inventory_item_id = ool.inventory_item_id
                         AND msi.organization_id = ool.ship_from_org_id
                         AND ooh.header_id = ool.header_id
                         AND TRUNC (ooh.ordered_date) >=
                                TRUNC (pr.periode_prog_from)
                         AND TRUNC (ooh.ordered_date) <=
                                TRUNC (pr.periode_prog_to))
/

