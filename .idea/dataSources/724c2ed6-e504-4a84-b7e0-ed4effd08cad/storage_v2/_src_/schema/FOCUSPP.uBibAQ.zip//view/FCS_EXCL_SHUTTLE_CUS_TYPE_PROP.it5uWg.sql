create view FCS_EXCL_SHUTTLE_CUS_TYPE_PROP as
  select arc.attribute8 AS cust_type_code,
            arc.attribute8 || ' ' || flex.description AS cust_type_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
            arc.attribute5 AS loc_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION pg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute3 = pg.region_code
and aur.region_code = arc.attribute3 
and arc.status = 'A'
and prod.proposal_id = pg.proposal_id
and flex.flex_value = arc.attribute8
group by arc.attribute8, aur.user_name, arc.attribute4, arc.attribute3, arc.attribute5, prod.promo_produk_id, flex.description
union
select arc.attribute8 AS cust_type_code,
            arc.attribute8 || ' ' || flex.description AS cust_type_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
            arc.attribute5 AS loc_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION_AREA pra, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute4 = pra.area_code
and aur.region_code = arc.attribute3 
and arc.status = 'A'
and prod.proposal_id = pra.proposal_id
and flex.flex_value = arc.attribute8
group by arc.attribute8, aur.user_name, arc.attribute4, arc.attribute3, arc.attribute5, prod.promo_produk_id, flex.description
union
select arc.attribute8 AS cust_type_code,
            arc.attribute8 || ' ' || flex.description AS cust_type_label, 
            aur.user_name AS user_name,
            arc.attribute4 AS area_code,
            arc.attribute3 AS region_code,
            arc.attribute5 AS loc_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROP_REGION_LOC prl, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute4 = prl.location_code
and aur.region_code = arc.attribute3  
and arc.status = 'A'
and prod.proposal_id = prl.proposal_id
and flex.flex_value = arc.attribute8
group by arc.attribute8, aur.user_name, arc.attribute4, arc.attribute3, arc.attribute5, prod.promo_produk_id, flex.description
order by 1
/

