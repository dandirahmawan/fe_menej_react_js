create view MASTER_CUSTOMER as
  select 
    a.customer_id as cust_id,
    a.customer_number as cust_code,
    --a.customer_name as cust_name,
    g.account_name as cust_name,
    --(a.customer_number || ' - ' || a.customer_name || ' - ' || b.description) as cust_fullname,
    (a.customer_number || ' - ' || g.account_name || ' - ' || b.description) as cust_fullname,
    a.attribute3 as region_code,
	c.description as region_name,
    (a.attribute3 || ' ' || c.description) as region_fullname,
    a.attribute4 as area_code,
	d.description as area_name,
    (a.attribute4 || ' ' || d.description) as area_fullname,
    a.attribute5 as location_code,
	b.description as location_name,
    (a.attribute5 || ' ' || b.description) as location_fullname,
    a.attribute8 as type_code,
	f.description as type_name,
    (a.attribute8 || ' ' || f.description) as type_fullname,
    a.attribute1 as group_code,
	e.description as group_name,
    (a.attribute1 || ' ' || e.description) as group_fullname,
	a.status as cust_status
from 
    apps.ar_customers a,
    apps.fcs_flex_values_vl b,
    apps.fcs_flex_values_vl c,
    apps.fcs_flex_values_vl d,
    apps.fcs_flex_values_vl e,
    apps.fcs_flex_values_vl f,
    apps.hz_cust_accounts g
where 
    a.customer_id = g.cust_account_id and
    a.attribute5 = b.flex_value and 
	a.attribute3 = c.flex_value and
    a.attribute4 = d.flex_value and
	a.attribute1 = e.flex_value and
	a.attribute8 = f.flex_value
order by region_code, area_code, location_code, cust_fullname
/

