create PROCEDURE test_report (
   prop_id IN VARCHAR2,
   p_refcur OUT SYS_REFCURSOR
)
IS
BEGIN
   -- pre-processing steps here
insert into REPORT_NO ( CONFIRM_NO, UNIQUE_NO)
select 
pa.confirm_no,
round(extract(day    from (systimestamp - timestamp '1970-01-01 00:00:00')) * 86400000
     + extract(hour   from (systimestamp - timestamp '1970-01-01 00:00:00')) * 3600000
     + extract(minute from (systimestamp - timestamp '1970-01-01 00:00:00')) * 60000
     + extract(second from (systimestamp - timestamp '1970-01-01 00:00:00')) * 1000) unix_time
from proposal pa
where proposal_id = prop_id ;
   -- open the cursor
   OPEN p_refcur FOR SELECT * FROM proposal
   where proposal_id =  prop_id;
END;
/

