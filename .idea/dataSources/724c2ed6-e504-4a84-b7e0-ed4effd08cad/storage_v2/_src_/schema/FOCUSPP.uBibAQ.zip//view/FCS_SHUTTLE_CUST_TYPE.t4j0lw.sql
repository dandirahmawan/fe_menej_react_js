create view FCS_SHUTTLE_CUST_TYPE as
  SELECT   ArCustomers.ATTRIBUTE8 AS CUST_TYPE_CODE,
                 ArCustomers.ATTRIBUTE8
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE8)
                 CUST_TYPE_LABEL,
              AUR.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_REGION AUR,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE
              AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE3
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_AREA AUA
                    WHERE   AUA.USER_NAME = AUR.USER_NAME) = 0
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_LOC AUL
                    WHERE   AUL.USER_NAME = AUR.USER_NAME) = 0
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_TYPE ACT
                    WHERE   ACT.USER_NAME = AUR.USER_NAME) = 0
   GROUP BY   ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE8,
              ArCustomers.ATTRIBUTE5,
              ArCustomers.ATTRIBUTE3,
              flex.DESCRIPTION,
              AUR.USER_NAME
   UNION ALL
     SELECT   ArCustomers.ATTRIBUTE8 AS CUST_TYPE_CODE,
                 ArCustomers.ATTRIBUTE8
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE8)
                 CUST_TYPE_LABEL,
              AppUserArea.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.FCS_FLEX_VALUES_VL flex,
              APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_AREA AppUserArea
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE4
              AND ArCustomers.ATTRIBUTE4 = AppUserArea.AREA_CODE
              AND ArCustomers.STATUS = 'A'
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_LOC AUL
                    WHERE   AUL.USER_NAME = AppUserArea.USER_NAME) = 0
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_TYPE ACT
                    WHERE   ACT.USER_NAME = AppUserArea.USER_NAME) = 0
   GROUP BY   ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              ArCustomers.ATTRIBUTE8,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE3,
              AppUserArea.USER_NAME
   UNION ALL
     SELECT   ArCustomers.ATTRIBUTE8 AS CUST_TYPE_CODE,
                 ArCustomers.ATTRIBUTE8
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE8)
                 CUST_TYPE_LABEL,
              AppUserLoc.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_LOC AppUserLoc,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.ATTRIBUTE5 = AppUserLoc.LOCATION_CODE
              AND ArCustomers.STATUS = 'A'
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_TYPE ACT
                    WHERE   ACT.USER_NAME = AppUserLoc.USER_NAME) = 0
   GROUP BY   ArCustomers.ATTRIBUTE5,
              ArCustomers.ATTRIBUTE8,
              AppUserLoc.USER_NAME,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE3
   UNION ALL
     SELECT   ArCustomers.ATTRIBUTE8 AS CUST_TYPE_CODE,
              ArCustomers.ATTRIBUTE8 || ' ' || flex.DESCRIPTION
                 CUST_TYPE_LABEL,
              AppUserCustType.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_CUST_TYPE AppUserCustType,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE1
              AND ArCustomers.ATTRIBUTE8 = AppUserCustType.CUST_TYPE
              AND ArCustomers.STATUS = 'A'
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_CUST_TYPE ACT
                    WHERE   ACT.USER_NAME = AppUserCustType.USER_NAME) > 0
   GROUP BY   ArCustomers.ATTRIBUTE8,
              AppUserCustType.USER_NAME,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE3,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS CUST_TYPE_CODE,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS CUST_TYPE_LABEL,
              AppUserCustType.USER_NAME,
              'REGIONX' AS REGION_CODE,
              'AREAX' AS AREA_CODE,
              'LOCATIONX' AS LOC_CODE
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_CUST_TYPE AppUserCustType
      WHERE   AppUserCustType.CUST_TYPE = FcsViewAttrExcl.VALUE
              AND FcsViewAttrExcl.TYPE = 'CTYPE'
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserCustType.USER_NAME
   ORDER BY   "CUST_TYPE_LABEL"
/

