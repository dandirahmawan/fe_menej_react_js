create view FCS_SHUTTLE_USER_LOCATION as
  SELECT   ArCustomers.ATTRIBUTE5 AS LOC_CODE,
                 ArCustomers.ATTRIBUTE5
              || ' '
              || (SELECT   flex2.DESCRIPTION
                    FROM   APPS.FCS_FLEX_VALUES_VL flex2
                   WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE5)
                 AS LOC_LABEL,
              AppUserArea.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE
       FROM   APPS.FCS_FLEX_VALUES_VL flex,
              APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_AREA AppUserArea
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE4
              AND ArCustomers.ATTRIBUTE4 = AppUserArea.AREA_CODE
              --AND ArCustomers.STATUS = 'A'
   GROUP BY   ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE3,
              AppUserArea.USER_NAME
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS LOC_CODE,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS LOC_LABEL,
              AppUserAccess.USER_NAME,
              'REGIONX' AS REGION_CODE,
              'AREAX' AS AREA_CODE
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_ACCESS AppUserAccess
      WHERE   FcsViewAttrExcl.TYPE = 'LOCATION'  AND FcsViewAttrExcl.VALUE NOT IN (SELECT ArCustomers.ATTRIBUTE5
       FROM   APPS.AR_CUSTOMERS ArCustomers, APP_USER_REGION AUR
      WHERE   ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE AND AUR.USER_NAME = AppUserAccess.USER_NAME)
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserAccess.USER_NAME
   ORDER BY   "LOC_LABEL"
/

