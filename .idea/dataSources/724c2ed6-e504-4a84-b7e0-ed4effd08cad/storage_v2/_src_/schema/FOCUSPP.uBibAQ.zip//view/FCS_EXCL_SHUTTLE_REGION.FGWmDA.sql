create view FCS_EXCL_SHUTTLE_REGION as
  select arc.attribute3 AS region_code, 
arc.attribute3 || ' ' || flex.description AS region_label, 
aur.user_name AS user_name, 
arc.attribute1 AS cust_group_code,
prod.promo_produk_id AS promo_produk_id,
null AS proposal_id
from apps.ar_customers arc, app_user_region aur, PROD_REGION_CUST_GROUP rcg, PROMO_PRODUK prod, APPS.FCS_FLEX_VALUES_VL flex
where arc.attribute1 = rcg.cust_group
and aur.region_code = arc.attribute3   
and arc.status = 'A'
and prod.promo_produk_id = rcg.promo_produk_id
and flex.flex_value = arc.attribute3
group by arc.attribute3, aur.user_name, arc.attribute1, prod.promo_produk_id, flex.description
order by 1
/

