create view FCS_SHUTTLE_AREA as
  SELECT   ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE4 AS DESCRIPTION,
              (   ArCustomers.ATTRIBUTE4
               || ' '
               || (SELECT   flex2.DESCRIPTION
                     FROM   APPS.FCS_FLEX_VALUES_VL flex2
                    WHERE   flex2.FLEX_VALUE = ArCustomers.ATTRIBUTE4))
                 AS AREA_LABEL,
              AUR.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_REGION AUR,
              APPS.FCS_FLEX_VALUES_VL flex
      WHERE       ArCustomers.ATTRIBUTE3 = AUR.REGION_CODE
              AND flex.FLEX_VALUE = ArCustomers.ATTRIBUTE3
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_AREA AUA
                    WHERE   AUA.USER_NAME = AUR.USER_NAME) = 0
   GROUP BY   ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE3,
              flex.DESCRIPTION,
              AUR.USER_NAME
   UNION ALL
     SELECT   ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE4 AS DESCRIPTION,
              (ArCustomers.ATTRIBUTE4 || ' ' || flex.DESCRIPTION) AS AREA_LABEL,
              AppUserArea.USER_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE
       FROM   APPS.FCS_FLEX_VALUES_VL flex,
              APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_AREA AppUserArea
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE4
              AND ArCustomers.ATTRIBUTE4 = AppUserArea.AREA_CODE
              AND ArCustomers.STATUS = 'A'
              AND (SELECT   COUNT ( * )
                     FROM   APP_USER_AREA AUA
                    WHERE   AUA.USER_NAME = AppUserArea.USER_NAME) > 0
   GROUP BY   ArCustomers.ATTRIBUTE4,
              flex.DESCRIPTION,
              ArCustomers.ATTRIBUTE3,
              AppUserArea.USER_NAME
   UNION ALL
     SELECT   FcsViewAttrExcl.VALUE AS AREA_CODE,
              FcsViewAttrExcl.DESCRIPTION,
              (FcsViewAttrExcl.VALUE || ' ' || FcsViewAttrExcl.DESCRIPTION)
                 AS AREA_LABEL,
              AppUserArea.USER_NAME,
              'REGIONX' AS REGION_CODE
       FROM   APPS.FCS_VIEW_CUST_ATTR_EXCL FcsViewAttrExcl,
              APP_USER_AREA AppUserArea
      WHERE   FcsViewAttrExcl.VALUE = AppUserArea.AREA_CODE
              AND FcsViewAttrExcl.TYPE = 'AREA'
   GROUP BY   FcsViewAttrExcl.VALUE,
              FcsViewAttrExcl.DESCRIPTION,
              AppUserArea.USER_NAME
   ORDER BY   "AREA_LABEL"
/

