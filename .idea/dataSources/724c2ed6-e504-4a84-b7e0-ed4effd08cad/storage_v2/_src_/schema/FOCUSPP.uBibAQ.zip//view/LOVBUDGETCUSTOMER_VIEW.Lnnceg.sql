create view LOVBUDGETCUSTOMER_VIEW as
  SELECT BudgetCustHdr.BUDGET_CUST_HDR_ID,
          BudgetCustHdr.CUSTOMER_ID,
          BudgetCustHdr.BUDGET_YEAR,
          BudgetCustomer.BUDGET_CUSTOMER_ID,
          (   BudgetCustomer.BUDGET_CATEGORY
           || '.'
           || BudgetCustomer.BUDGET_CLASS
           || '.'
           || BudgetCustomer.BUDGET_BRAND
           || '.'
           || BudgetCustomer.BUDGET_EXTENTION
           || '.'
           || BudgetCustomer.BUDGET_PACKAGING
           || '.'
           || BudgetCustomer.BUDGET_VARIANT)
             AS KOMBINASI_CODE,
          BudgetCustHdr.budget_type,
          BUDGETCUSTHDR.KODE_POSTING
     FROM BUDGET_CUST_HDR BudgetCustHdr, BUDGET_CUSTOMER BudgetCustomer
    WHERE BudgetCustHdr.BUDGET_CUST_HDR_ID =
             BudgetCustomer.BUDGET_CUST_HDR_ID
    AND BudgetCustomer.STATUS = 'ACTIVE'
/

