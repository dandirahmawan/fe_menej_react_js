create view APP_USER_CUSTOMERS as
  select distinct
	a.user_name,
	m.cust_id,
	m.cust_code,
	m.cust_name,
	m.cust_fullname,
	m.region_code,
	m.region_name,
	m.region_fullname,
	m.area_code,
	m.area_name,
	m.area_fullname,
	m.location_code,
	m.location_name,
	m.location_fullname,
	m.type_code,
	m.type_name,
	m.type_fullname,
	m.group_code,
	m.group_name,
	m.group_fullname,
	m.cust_status
from
	master_customer m,
	app_user_cust_inc a
where
	((a.cust_code is null) or (m.cust_code = a.cust_code)) and
	((a.region_code is null) or (m.region_code = a.region_code)) and
	((a.area_code is null) or (m.area_code = a.area_code)) and
	((a.location_code is null) or (m.location_code = a.location_code)) and
	((a.type_code is null) or (m.type_code = a.type_code)) and
	((a.group_code is null) or (m.group_code = a.group_code))
order by
	user_name, region_code, area_code, location_code, cust_code
/

