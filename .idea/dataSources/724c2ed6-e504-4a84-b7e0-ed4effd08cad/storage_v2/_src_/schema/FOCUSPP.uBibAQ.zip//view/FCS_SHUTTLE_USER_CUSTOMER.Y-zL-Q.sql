create view FCS_SHUTTLE_USER_CUSTOMER as
  SELECT   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              (   ArCustomers.CUSTOMER_NUMBER
               || ' - '
               || CAV.ACCOUNT_NAME
               || ' - '
               || flex.DESCRIPTION)
                 AS CUSTOMER_FULL_NAME,
              ArCustomers.ATTRIBUTE3 AS REGION_CODE,
              AppUserCustGroup.USER_NAME,
              ArCustomers.ATTRIBUTE4 AS AREA_CODE,
              ArCustomers.ATTRIBUTE5 AS LOC_CODE,
              ArCustomers.ATTRIBUTE1 AS CUSTGROUP_CODE
       FROM   APPS.AR_CUSTOMERS ArCustomers,
              APP_USER_CUST_GROUP AppUserCustGroup,
              APPS.FCS_FLEX_VALUES_VL flex,
              APPS.FCS_CUST_ACCOUNTS_VIEW CAV
      WHERE       flex.FLEX_VALUE = ArCustomers.ATTRIBUTE5
              AND ArCustomers.ATTRIBUTE1 = AppUserCustGroup.CUST_GROUP
              AND ArCustomers.STATUS = 'A'
              AND ArCustomers.CUSTOMER_ID = CAV.CUST_ACCOUNT_ID
   GROUP BY   ArCustomers.CUSTOMER_ID,
              ArCustomers.CUSTOMER_NAME,
              ArCustomers.CUSTOMER_NUMBER,
              ArCustomers.ATTRIBUTE1,
              ArCustomers.ATTRIBUTE3,
              ArCustomers.ATTRIBUTE4,
              ArCustomers.ATTRIBUTE5,
              CAV.ACCOUNT_NAME,
              AppUserCustGroup.USER_NAME,
              flex.DESCRIPTION
   ORDER BY   "CUSTOMER_FULL_NAME"
/

