create view FCS_VIEW_REALISASI_PPPC_BCK as
  SELECT PPPC.PROPOSAL_NO,
          CASE WHEN PPPC.COMPANY_ID = 'I' THEN 'FDI' ELSE 'FDN' END
             AS COMPANY_ID,
          PPPC.PEMOHON,
          PPPC.PROPOSAL_NO AS PP,
          PPPC.PROPOSAL_DATE AS PP_DATE,
          PPPC.COPY_SOURCE AS PP_REFERENCE,
          PPPC.STATUS AS PP_STATUS,
          PPPC.CONFIRM_NO AS PC,
          PPPC.ADDENDUM_KE,
          PPPC.CONFIRM_DATE AS PC_DATE,
          NVL (PPPC.EBS_PR_STATUS, PPPC.EBS_MODIFIER_STATUS) AS PC_STATUS,
          PPPC.PERIODE_PROG_FROM AS START_DATE,
          PPPC.PERIODE_PROG_TO AS END_DATE,
          TO_CHAR (PPPC.PERIODE_PROG_FROM, 'MONTH') AS MONTH_START,
          TO_CHAR (PPPC.PERIODE_PROG_TO, 'MONTH') AS MONTH_END,
          TO_CHAR (PPPC.PERIODE_PROG_FROM, 'YYYY') AS YEAR_PROMO,
          PPPC.PROG_PROMO,
          PPPC.PROPOSAL_TYPE,
          PPPC.MEKANISME_PENAGIHAN,
          --PRODUK
          PROD.PRODUK_ROW_NUM AS LINE,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (CREG.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CREG.DESCRIPTION)
                   FROM (SELECT b.PROMO_PRODUK_ID,
                                a.REGION_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                FOCUSPP.PROMO_PRODUK b
                          WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CREG
                  WHERE CREG.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CREG."DESCRIPTION" IS NOT NULL)
             ELSE
                (SELECT LISTAGG (CREG.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CREG.DESCRIPTION)
                   FROM (SELECT a.PROMO_PRODUK_ID,
                                a.REGION_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_HO a) CREG
                  WHERE CREG.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CREG."DESCRIPTION" IS NOT NULL)
          END
             AS CUST_REGION,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (CAREA.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CAREA.DESCRIPTION)
                   FROM (SELECT b.PROMO_PRODUK_ID, a.AREA_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                FOCUSPP.PROMO_PRODUK b
                          WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CAREA
                  WHERE CAREA.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CAREA."DESCRIPTION" IS NOT NULL)
             ELSE
                (SELECT LISTAGG (CAREA.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CAREA.DESCRIPTION)
                   FROM (SELECT a.PROMO_PRODUK_ID, a.AREA_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_HO a) CAREA
                  WHERE CAREA.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CAREA."DESCRIPTION" IS NOT NULL)
          END
             AS CUST_AREA,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (CLOC.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CLOC.DESCRIPTION)
                   FROM (SELECT b.PROMO_PRODUK_ID, a.LOC_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                FOCUSPP.PROMO_PRODUK b
                          WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CLOC
                  WHERE CLOC.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CLOC."DESCRIPTION" IS NOT NULL)
             ELSE
                (SELECT LISTAGG (CLOC.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CLOC.DESCRIPTION)
                   FROM (SELECT a.PROMO_PRODUK_ID, a.LOC_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_HO a) CLOC
                  WHERE CLOC.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CLOC."DESCRIPTION" IS NOT NULL)
          END
             AS CUST_LOC,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (CTYPE.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CTYPE.DESCRIPTION)
                   FROM (SELECT b.PROMO_PRODUK_ID,
                                a.CUSTTYP_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                FOCUSPP.PROMO_PRODUK b
                          WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CTYPE
                  WHERE CTYPE.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CTYPE."DESCRIPTION" IS NOT NULL)
             ELSE
                (SELECT LISTAGG (CTYPE.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CTYPE.DESCRIPTION)
                   FROM (SELECT a.PROMO_PRODUK_ID,
                                a.CUSTTYP_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_HO a) CTYPE
                  WHERE CTYPE.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CTYPE."DESCRIPTION" IS NOT NULL)
          END
             AS CUST_TYPE,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (CGROUP.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CGROUP.DESCRIPTION)
                   FROM (SELECT b.PROMO_PRODUK_ID,
                                a.CUSTGRP_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                FOCUSPP.PROMO_PRODUK b
                          WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CGROUP
                  WHERE CGROUP.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CGROUP."DESCRIPTION" IS NOT NULL)
             ELSE
                (SELECT LISTAGG (CGROUP.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CGROUP.DESCRIPTION)
                   FROM (SELECT a.PROMO_PRODUK_ID,
                                a.CUSTGRP_DESC AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_HO a) CGROUP
                  WHERE CGROUP.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CGROUP."DESCRIPTION" IS NOT NULL)
          END
             AS CUST_GROUP,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (CCUST.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CCUST.DESCRIPTION)
                   FROM (SELECT b.PROMO_PRODUK_ID,
                                a.CUSTOMER_NAME AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_AREA a,
                                FOCUSPP.PROMO_PRODUK b
                          WHERE a.PROPOSAL_ID = b.PROPOSAL_ID) CCUST
                  WHERE CCUST.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CCUST."DESCRIPTION" IS NOT NULL)
             ELSE
                (SELECT LISTAGG (CCUST.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY CCUST.DESCRIPTION)
                   FROM (SELECT a.PROMO_PRODUK_ID,
                                a.CUSTOMER_NAME AS DESCRIPTION
                           FROM FOCUSPP.PROMO_CUSTOMER_HO a) CCUST
                  WHERE CCUST.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                        AND CCUST."DESCRIPTION" IS NOT NULL)
          END
             AS CUST_DETAIL,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (XREG.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XREG.DESCRIPTION)
                   FROM (SELECT ECR.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_AREA ECR,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECR.REGION_CODE) XREG
                  WHERE XREG.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
             ELSE
                (SELECT LISTAGG (XREG.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XREG.DESCRIPTION)
                   FROM (SELECT ECR.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_HO ECR,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECR.REGION_CODE) XREG
                  WHERE XREG.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
          END
             AS EXCLUDED_CUST_REGION,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (XAREA.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XAREA.DESCRIPTION)
                   FROM (SELECT ECA.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_AREA ECA,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECA.AREA_CODE) XAREA
                  WHERE XAREA.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
             ELSE
                (SELECT LISTAGG (XAREA.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XAREA.DESCRIPTION)
                   FROM (SELECT ECA.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_HO ECA,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECA.AREA_CODE) XAREA
                  WHERE XAREA.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
          END
             AS EXCLUDED_CUST_AREA,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (XLOC.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XLOC.DESCRIPTION)
                   FROM (SELECT ECL.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_AREA ECL,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECL.LOC_CODE) XLOC
                  WHERE XLOC.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
             ELSE
                (SELECT LISTAGG (XLOC.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XLOC.DESCRIPTION)
                   FROM (SELECT ECL.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_HO ECL,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECL.LOC_CODE) XLOC
                  WHERE XLOC.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
          END
             AS EXCLUDED_CUST_LOC,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (XCTY.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XCTY.DESCRIPTION)
                   FROM (SELECT ECTY.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_AREA ECTY,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECTY.CUSTTYP_CODE) XCTY
                  WHERE XCTY.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
             ELSE
                (SELECT LISTAGG (XCTY.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XCTY.DESCRIPTION)
                   FROM (SELECT ECTY.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_HO ECTY,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECTY.CUSTTYP_CODE) XCTY
                  WHERE XCTY.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
          END
             AS EXCLUDED_CUST_TYPE,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (XCGR.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XCGR.DESCRIPTION)
                   FROM (SELECT ECGR.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_AREA ECGR,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECGR.CUSTGRP_CODE) XCGR
                  WHERE XCGR.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
             ELSE
                (SELECT LISTAGG (XCGR.DESCRIPTION, ', ')
                           WITHIN GROUP (ORDER BY XCGR.DESCRIPTION)
                   FROM (SELECT ECGR.PROMO_PRODUK_ID, FVL.DESCRIPTION
                           FROM PROMO_CUSTX_HO ECGR,
                                APPS.FCS_FLEX_VALUES_VL FVL
                          WHERE FVL.FLEX_VALUE = ECGR.CUSTGRP_CODE) XCGR
                  WHERE XCGR.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
          END
             AS EXCLUDED_CUST_GROUP,
          CASE
             WHEN PPPC.USER_TYPE_CREATOR = 'AREA'
             THEN
                (SELECT LISTAGG (XCCS.CUSTOMER_NAME, ', ')
                           WITHIN GROUP (ORDER BY XCCS.CUSTOMER_NAME)
                   FROM (SELECT ECCS.PROMO_PRODUK_ID, ARC.CUSTOMER_NAME
                           FROM PROMO_CUSTX_AREA ECCS, APPS.AR_CUSTOMERS ARC
                          WHERE ARC.CUSTOMER_ID = ECCS.CUSTOMER_ID) XCCS
                  WHERE XCCS.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
             ELSE
                (SELECT LISTAGG (XCCS.CUSTOMER_NAME, ', ')
                           WITHIN GROUP (ORDER BY XCCS.CUSTOMER_NAME)
                   FROM (SELECT ECCS.PROMO_PRODUK_ID, ARC.CUSTOMER_NAME
                           FROM PROMO_CUSTX_HO ECCS, APPS.AR_CUSTOMERS ARC
                          WHERE ARC.CUSTOMER_ID = ECCS.CUSTOMER_ID) XCCS
                  WHERE XCCS.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
          END
             AS EXCLUDED_CUST_DETAIL,
          (SELECT MCV.DESCRIPTION
             FROM APPS.MTL_CATEGORIES_V MCV
            WHERE MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_CATEGORY
                  AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
             AS PROD_CATEGORY,
          (SELECT MCV.DESCRIPTION
             FROM APPS.MTL_CATEGORIES_V MCV
            WHERE MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_CLASS
                  AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
             AS PROD_CLASS,
          (SELECT MCV.DESCRIPTION
             FROM APPS.MTL_CATEGORIES_V MCV
            WHERE MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_BRAND
                  AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
             AS PROD_BRAND,
          (SELECT MCV.DESCRIPTION
             FROM APPS.MTL_CATEGORIES_V MCV
            WHERE MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_EXT
                  AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
             AS PROD_EXTENSION,
          (SELECT MCV.DESCRIPTION
             FROM APPS.MTL_CATEGORIES_V MCV
            WHERE MCV.CATEGORY_CONCAT_SEGS = PROD.PRODUCT_PACK
                  AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
             AS PROD_PACKAGING,
          (SELECT LISTAGG (VAR."VARIANT_DESC", ', ')
                     WITHIN GROUP (ORDER BY VAR."VARIANT_DESC")
             FROM FOCUSPP.PRODUK_VARIANT VAR
            WHERE VAR.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                  AND VAR."VARIANT_DESC" IS NOT NULL)
             AS PROD_VARIANT,
          (SELECT LISTAGG (
                     CONCAT (ITM."PROD_ITEM", CONCAT (' ', ITM."ITEM_DESC")),
                     ', ')
                  WITHIN GROUP (ORDER BY
                                   CONCAT (ITM."PROD_ITEM",
                                           CONCAT (' ', ITM."ITEM_DESC")))
             FROM FOCUSPP.PRODUK_ITEM ITM
            WHERE ITM.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
                  AND CONCAT (ITM."PROD_ITEM", CONCAT (' ', ITM."ITEM_DESC"))
                         IS NOT NULL
                  AND ROWNUM <= 80)
             AS PRODUCT_DETAIL,
          PROD.MEKANISME AS PROD_MEKANISME,
          CASE
             WHEN DISCOUNT_TYPE = 'POTONGAN'
             THEN
                   POT.TIPE_PERHITUNGAN
                || '; Qty From '
                || POT.QTY_FROM
                || ' To '
                || POT.QTY_TO
                || ' Disc By '
                || POT.TIPE_POTONGAN
             WHEN DISCOUNT_TYPE = 'BIAYA'
             THEN
                BIA.DESCR
             WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                  AND ( (SELECT LISTAGG (BRI."ITEM_DESC", ', ')
                                   WITHIN GROUP (ORDER BY BRI."ITEM_DESC")
                           FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                          WHERE     BRI.PROMO_BONUS_ID = BNS.PROMO_BONUS_ID
                                AND BRI."ITEM_DESC" IS NOT NULL
                                AND ROWNUM <= 80))
                         IS NULL
             THEN
                (SELECT MCV.DESCRIPTION
                   FROM APPS.MTL_CATEGORIES_V MCV
                  WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_CATEGORY
                        AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_CLASS
                           AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_BRAND
                           AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_EXT
                           AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_PACK
                           AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                || ' - '
                || (SELECT LISTAGG (BRV."VARIANT_DESC", ', ')
                              WITHIN GROUP (ORDER BY BRV."VARIANT_DESC")
                      FROM FOCUSPP.PROMO_BONUS_VARIANT BRV
                     WHERE BRV.PROMO_BONUS_ID = BNS.PROMO_BONUS_ID
                           AND BRV."VARIANT_DESC" IS NOT NULL)
                || ' - Qty: '
                || BNS.QTY_FROM
                || ' '
                || BNS.UOM
                || ' @ Rp. '
                || BNS.PRICE_VAL
             WHEN DISCOUNT_TYPE = 'PROMOBARANG'
                  AND ( (SELECT LISTAGG (BRI."ITEM_DESC", ', ')
                                   WITHIN GROUP (ORDER BY BRI."ITEM_DESC")
                           FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                          WHERE     BRI.PROMO_BONUS_ID = BNS.PROMO_BONUS_ID
                                AND BRI."ITEM_DESC" IS NOT NULL
                                AND ROWNUM <= 80))
                         IS NOT NULL
             THEN
                (SELECT MCV.DESCRIPTION
                   FROM APPS.MTL_CATEGORIES_V MCV
                  WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_CATEGORY
                        AND MCV.STRUCTURE_NAME = 'FCS_CATEGORY')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_CLASS
                           AND MCV.STRUCTURE_NAME = 'FCS_CLASS')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_BRAND
                           AND MCV.STRUCTURE_NAME = 'FCS_BRAND')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_EXT
                           AND MCV.STRUCTURE_NAME = 'FCS_EXTENTION')
                || ' - '
                || (SELECT MCV.DESCRIPTION
                      FROM APPS.MTL_CATEGORIES_V MCV
                     WHERE MCV.CATEGORY_CONCAT_SEGS = BNS.PRODUCT_PACK
                           AND MCV.STRUCTURE_NAME = 'FCS_PACKAGING')
                || ' - '
                || (SELECT LISTAGG (BRV."VARIANT_DESC", ', ')
                              WITHIN GROUP (ORDER BY BRV."VARIANT_DESC")
                      FROM FOCUSPP.PROMO_BONUS_VARIANT BRV
                     WHERE BRV.PROMO_BONUS_ID = BNS.PROMO_BONUS_ID
                           AND BRV."VARIANT_DESC" IS NOT NULL)
                || ' - '
                || (SELECT LISTAGG (BRI."ITEM_DESC", ', ')
                              WITHIN GROUP (ORDER BY BRI."ITEM_DESC")
                      FROM FOCUSPP.PROMO_BONUS_PROD_ITEM BRI
                     WHERE     BRI.PROMO_BONUS_ID = BNS.PROMO_BONUS_ID
                           AND BRI."ITEM_DESC" IS NOT NULL
                           AND ROWNUM <= 80)
                || ' - Qty: '
                || BNS.QTY_FROM
                || ' '
                || BNS.UOM
                || ' @ Rp. '
                || BNS.PRICE_VAL
             ELSE
                NULL
          END
             AS DETIL_PROMO,
          CASE
             WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN' THEN POT.DISC_NON_YEARLY
             WHEN PPPC.DISCOUNT_TYPE = 'BIAYA' THEN BIA.BIAYA_NON_YEARLY
             WHEN PPPC.DISCOUNT_TYPE = 'PROMOBARANG' THEN BNS.DISC_NON_YEARLY
             ELSE NULL
          END
             AS ON_TOP_TPB,
          CASE
             WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN' THEN POT.DISC_YEARLY
             WHEN PPPC.DISCOUNT_TYPE = 'BIAYA' THEN BIA.BIAYA_YEARLY
             WHEN PPPC.DISCOUNT_TYPE = 'PROMOBARANG' THEN BNS.DISC_YEARLY
             ELSE NULL
          END
             AS MF_PB,
          CASE
             WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN'
             THEN
                PROD.DISC_ON_TOP
             WHEN PPPC.DISCOUNT_TYPE = 'BIAYA'
             THEN
                PROD.BIA_ONTOP
             WHEN PPPC.DISCOUNT_TYPE = 'PROMOBARANG'
             THEN
                PROD.BRG_BONUS_ON_TOP
             ELSE
                NULL
          END
             AS TOTAL_ON_TOP_TPB,
          CASE
             WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN' THEN PROD.DISC_MF
             WHEN PPPC.DISCOUNT_TYPE = 'BIAYA' THEN PROD.BIA_MF
             WHEN PPPC.DISCOUNT_TYPE = 'PROMOBARANG' THEN PROD.BRG_BONUS_MF
             ELSE NULL
          END
             AS TOTAL_MF_PB,
          (  SELECT PROD.ITEM_EXPENSE || ' ' || UPPER (MSI.DESCRIPTION)
                       AS DESCRIPTION
               FROM APPS.MTL_SYSTEM_ITEMS_B MSI
              WHERE MSI.SEGMENT1 = PROD.ITEM_EXPENSE
                    AND MSI.ORGANIZATION_ID = 83
           GROUP BY PROD.ITEM_EXPENSE, MSI.DESCRIPTION)
             AS ITEM_EXPENSE,
          (  SELECT PROD.KODE_POSTING || ' ' || UPPER (MSI.DESCRIPTION)
                       AS DESCRIPTION
               FROM APPS.MTL_SYSTEM_ITEMS_B MSI
              WHERE MSI.SEGMENT1 = PROD.KODE_POSTING
                    AND MSI.ORGANIZATION_ID = 83
           GROUP BY PROD.KODE_POSTING, MSI.DESCRIPTION)
             AS KODE_POSTING_ON_TOP,
          (  SELECT PROD.KODE_POSTING_MF || ' ' || UPPER (MSI.DESCRIPTION)
                       AS DESCRIPTION
               FROM APPS.MTL_SYSTEM_ITEMS_B MSI
              WHERE MSI.SEGMENT1 = PROD.KODE_POSTING_MF
                    AND MSI.ORGANIZATION_ID = 83
           GROUP BY PROD.KODE_POSTING, MSI.DESCRIPTION)
             AS KODE_POSTING_MF,
          CASE
             WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN'
                  AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
             THEN
                FVRMT.AMOUNT_OT
             WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
             THEN
                NVL (
                   CASE
                      WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF = 0
                           AND   PROD.DISC_ON_TOP
                               + PROD.BRG_BONUS_ON_TOP
                               + PROD.BIA_ONTOP > 0
                      THEN
                         FVRD.AMOUNT
                      WHEN   FVRD.AMOUNT
                           - PROD.DISC_MF
                           - PROD.BRG_BONUS_MF
                           - PROD.BIA_MF > 0
                           AND   PROD.DISC_ON_TOP
                               + PROD.BRG_BONUS_ON_TOP
                               + PROD.BIA_ONTOP > 0
                           AND PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF >
                                  0
                      THEN
                           FVRD.AMOUNT
                         - PROD.DISC_MF
                         - PROD.BRG_BONUS_MF
                         - PROD.BIA_MF
                      ELSE
                         0
                   END,
                   0)
                + NVL (
                     CASE
                        WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF =
                                0
                             AND   PROD.DISC_ON_TOP
                                 + PROD.BRG_BONUS_ON_TOP
                                 + PROD.BIA_ONTOP > 0
                        THEN
                           FVRG.AMOUNT
                        WHEN       FVRG.AMOUNT
                                 - PROD.DISC_MF
                                 - PROD.BRG_BONUS_MF
                                 - PROD.BIA_MF > 0
                             AND   PROD.DISC_ON_TOP
                                 + PROD.BRG_BONUS_ON_TOP
                                 + PROD.BIA_ONTOP > 0
                             AND   PROD.DISC_MF
                                 + PROD.BRG_BONUS_MF
                                 + PROD.BIA_MF > 0
                        THEN
                             FVRG.AMOUNT
                           - PROD.DISC_MF
                           - PROD.BRG_BONUS_MF
                           - PROD.BIA_MF
                        ELSE
                           0
                     END,
                     0)
             WHEN PPPC.DISCOUNT_TYPE = 'PROMOBARANG'
                  AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
             THEN
                (PROD.BRG_BONUS_ON_TOP * FVRP.AMOUNT)
                / (PROD.BRG_BONUS_MF + PROD.BRG_BONUS_ON_TOP)
             ELSE
                NULL
          END
             AS VALUE_OT_TPB,
          CASE
             WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN'
                  AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
             THEN
                FVRMT.AMOUNT_MF
             WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
             THEN
                NVL (
                   CASE
                      WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF > 0
                           AND   PROD.DISC_ON_TOP
                               + PROD.BRG_BONUS_ON_TOP
                               + PROD.BIA_ONTOP = 0
                      THEN
                         FVRD.AMOUNT
                      WHEN PROD.DISC_ON_TOP + PROD.BRG_BONUS_ON_TOP + PROD.BIA_ONTOP >
                              0
                           AND PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF >
                                  0
                           AND FVRD.AMOUNT > 0
                      THEN
                         CASE
                            WHEN   FVRD.AMOUNT
                                 - PROD.DISC_MF
                                 - PROD.BRG_BONUS_MF
                                 - PROD.BIA_MF < 0
                            THEN
                               FVRD.AMOUNT
                            ELSE
                               CASE
                                  WHEN FVRD.AMOUNT > 0
                                  THEN
                                       PROD.DISC_MF
                                     + PROD.BRG_BONUS_MF
                                     + PROD.BIA_MF
                                  ELSE
                                     0
                               END
                         END
                      ELSE
                         FVRD.AMOUNT
                   END,
                   0)
                + NVL (
                     CASE
                        WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF >
                                0
                             AND   PROD.DISC_ON_TOP
                                 + PROD.BRG_BONUS_ON_TOP
                                 + PROD.BIA_ONTOP = 0
                        THEN
                           FVRG.AMOUNT
                        WHEN PROD.DISC_ON_TOP + PROD.BRG_BONUS_ON_TOP + PROD.BIA_ONTOP >
                                0
                             AND   PROD.DISC_MF
                                 + PROD.BRG_BONUS_MF
                                 + PROD.BIA_MF > 0
                        THEN
                           CASE
                              WHEN   FVRG.AMOUNT
                                   - PROD.DISC_MF
                                   - PROD.BRG_BONUS_MF
                                   - PROD.BIA_MF < 0
                              THEN
                                 FVRG.AMOUNT
                              ELSE
                                 CASE
                                    WHEN FVRG.AMOUNT > 0
                                    THEN
                                         PROD.DISC_MF
                                       + PROD.BRG_BONUS_MF
                                       + PROD.BIA_MF
                                    ELSE
                                       0
                                 END
                           END
                        ELSE
                           0
                     END,
                     0)
             WHEN PPPC.DISCOUNT_TYPE = 'PROMOBARANG'
                  AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
             THEN
                (PROD.BRG_BONUS_MF * FVRP.AMOUNT)
                / (PROD.BRG_BONUS_MF + PROD.BRG_BONUS_ON_TOP)
             ELSE
                NULL
          END
             AS VALUE_MF_PB,
          0 AS REMAINING_ON_TOP_TPB,
          (SELECT SUM (BC.BUDGET_AS_TO_DATE - BC.BUDGET_AS_TO_DATE_USED)
             FROM BUDGET_CUSTOMER BC, PROD_BUDGET_BY PB
            WHERE BC.BUDGET_CUSTOMER_ID = PB.BUDGET_CUST_ID
                  AND PB.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID)
             AS REMAINING_MF_PB,
          NULL AS KETERANGAN,
          NVL (NVL (NVL (FVRG.DOC1, FVRD.DOC1), FVRMT.DOC1), FVRP.DOC1)
             AS DOC1,
          NVL (NVL (NVL (FVRG.DATE1, FVRD.DATE1), FVRMT.DATE1), FVRP.DATE1)
             AS DOC1_DATE,
          NVL (NVL (FVRG.DOC2, FVRMT.DOC2), FVRP.DOC2) AS DOC2,
          NVL (NVL (FVRG.DATE2, FVRMT.DATE2), FVRP.DATE2) AS DOC2_DATE,
          FVRG.DOC3 AS DOC3,
          FVRG.DATE3 AS DOC3_DATE,
          NULL AS DOC4,
          NULL AS DOC4_DATE
     FROM FOCUSPP.PROPOSAL PPPC,
          (SELECT ROW_NUMBER ()
                  OVER (PARTITION BY pp.proposal_id
                        ORDER BY pp.proposal_id, pp.PROMO_PRODUK_ID)
                     AS LINE_NO,
                  pp.*
             FROM FOCUSPP.PROMO_PRODUK pp) PROD,
          FOCUSPP.APP_USER_ACCESS USR,
          FOCUSPP.TARGET TGT,
          FOCUSPP.DISCOUNT POT,
          FOCUSPP.BIAYA BIA,
          FOCUSPP.PROMO_BONUS BNS,
          FOCUSPP.PROD_BUDGET_BY PBUD,
          APPS.FCS_VIEW_REALISASI_PRMBRG_DTL FVRP,
          APPS.FCS_VIEW_REALISASI_GR_DETIL FVRG,
          APPS.FCS_VIEW_REALISASI_DCV_DETIL FVRD,
          (  SELECT LINE_NO,
                    MAX (CONFIRM_NO) CONFIRM_NO,
                    DOC1,
                    DATE1,
                    DOC2,
                    DATE2,
                    SUM (OT) AMOUNT_MF,
                    SUM (MF) AMOUNT_OT
               FROM (SELECT FVRM.PROPOSAL_ID,
                            FVRM.PROPOSAL_NO,
                            FVRM.CONFIRM_NO,
                            FVRM.CONFIRM_NO_ORIG,
                            FVRM.PROMO_PRODUK_ID,
                            FVRM.LINE_NO,
                            FVRM.DOC1,
                            FVRM.DATE1,
                            FVRM.DOC2,
                            FVRM.DATE2,
                            FVRM.AMOUNT OT,
                            0 MF
                       FROM APPS.FCS_VIEW_REALISASI_MDF_DETIL FVRM
                      WHERE KET = 'OT'
                     UNION ALL
                     SELECT FVRM.PROPOSAL_ID,
                            FVRM.PROPOSAL_NO,
                            FVRM.CONFIRM_NO,
                            FVRM.CONFIRM_NO_ORIG,
                            FVRM.PROMO_PRODUK_ID,
                            FVRM.LINE_NO,
                            FVRM.DOC1,
                            FVRM.DATE1,
                            FVRM.DOC2,
                            FVRM.DATE2,
                            0 OT,
                            FVRM.AMOUNT MF
                       FROM APPS.FCS_VIEW_REALISASI_MDF_DETIL FVRM
                      WHERE KET = 'MF')
              WHERE 1 = 1
           GROUP BY LINE_NO,
                    CONFIRM_NO_ORIG,
                    DOC1,
                    DATE1,
                    DOC2,
                    DATE2) FVRMT
    WHERE     PROD.PROPOSAL_ID = PPPC.PROPOSAL_ID
          AND USR.USER_NAME(+) = PPPC.PEMOHON
          AND TGT.PROMO_PRODUK_ID = PROD.PROMO_PRODUK_ID
          AND POT.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
          AND BIA.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
          AND BNS.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
          AND PBUD.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
          --            AND PPPC.CONFIRM_NO = 'I0318000224'
          AND FVRG.CONFIRM_NO(+) =
                 PPPC.CONFIRM_NO
                 || DECODE (PPPC.ADDENDUM_KE,
                            NULL, '',
                            '-' || PPPC.ADDENDUM_KE)
          AND FVRG.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
          AND FVRG.LINE_NO(+) = NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
          AND FVRD.PROPOSAL_ID(+) = PPPC.PROPOSAL_ID
          AND FVRD.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
          AND FVRD.LINE_NO(+) = NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
          AND FVRP.PROPOSAL_ID(+) = PPPC.PROPOSAL_ID
          AND FVRP.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
          AND FVRP.LINE_NO(+) = NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
          AND FVRMT.LINE_NO(+) = NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
          AND FVRMT.CONFIRM_NO(+) =
                 PPPC.CONFIRM_NO
                 || DECODE (PPPC.ADDENDUM_KE,
                            NULL, '',
                            '-' || PPPC.ADDENDUM_KE)
   UNION ALL
     SELECT LALA.PROPOSAL_NO,
            LALA.COMPANY_ID,
            LALA.PEMOHON,
            LALA.PP,
            LALA.PP_DATE,
            LALA.PP_REFERENCE,
            LALA.PP_STATUS,
            LALA.PC,
            LALA.ADDENDUM_KE,
            LALA.PC_DATE,
            LALA.PC_STATUS,
            LALA.START_DATE,
            LALA.END_DATE,
            LALA.MONTH_START,
            LALA.MONTH_END,
            LALA.YEAR_PROMO,
            LALA.PROG_PROMO,
            LALA.PROPOSAL_TYPE,
            LALA.MEKANISME_PENAGIHAN,
            LALA.LINE,
            LALA.CUST_REGION,
            LALA.CUST_AREA,
            LALA.CUST_LOC,
            LALA.CUST_TYPE,
            LALA.CUST_GROUP,
            LALA.CUST_DETAIL,
            LALA.EXCLUDED_CUST_REGION,
            LALA.EXCLUDED_CUST_AREA,
            LALA.EXCLUDED_CUST_LOC,
            LALA.EXCLUDED_CUST_TYPE,
            LALA.EXCLUDED_CUST_GROUP,
            LALA.EXCLUDED_CUST_DETAIL,
            LALA.PROD_CATEGORY,
            LALA.PROD_CLASS,
            LALA.PROD_BRAND,
            LALA.PROD_EXTENSION,
            LALA.PROD_PACKAGING,
            LALA.PROD_VARIANT,
            LALA.PRODUCT_DETAIL,
            LALA.PROD_MEKANISME,
            LALA.DETIL_PROMO,
            LALA.ON_TOP_TPB,
            LALA.MF_PB,
            LALA.TOTAL_ON_TOP_TPB,
            LALA.TOTAL_MF_PB,
            LALA.ITEM_EXPENSE,
            LALA.KODE_POSTING_ON_TOP,
            LALA.KODE_POSTING_MF,
            NULL VALUE_OT_TPB,
            SUM (
               CASE
                  WHEN (LALA.VALUE_OT_TPB + LALA.VALUE_MF_PB) - LALA.VALUE_BUDGET_KOMBINASI <
                          1
                       AND (LALA.VALUE_OT_TPB + LALA.VALUE_MF_PB)
                           - LALA.VALUE_BUDGET_KOMBINASI > 0
                  THEN
                     (LALA.VALUE_OT_TPB + LALA.VALUE_MF_PB)
                     - LALA.VALUE_BUDGET_KOMBINASI
                  ELSE
                     0
               END
               * -1)
               VALUE_MF_PB,
            LALA.REMAINING_ON_TOP_TPB,
            LALA.REMAINING_MF_PB,
            LALA.KETERANGAN,
            LALA.DOC1,
            LALA.DOC1_DATE,
            LALA.DOC2,
            LALA.DOC2_DATE,
            LALA.DOC3,
            LALA.DOC3_DATE,
            LALA.DOC4,
            LALA.DOC4_DATE
       FROM (SELECT PPPC.PROPOSAL_NO,
                    CASE WHEN PPPC.COMPANY_ID = 'I' THEN 'FDI' ELSE 'FDN' END
                       AS COMPANY_ID,
                    PPPC.PEMOHON,
                    PPPC.PROPOSAL_NO AS PP,
                    PPPC.PROPOSAL_DATE AS PP_DATE,
                    PPPC.COPY_SOURCE AS PP_REFERENCE,
                    PPPC.STATUS AS PP_STATUS,
                    PPPC.CONFIRM_NO AS PC,
                    PPPC.ADDENDUM_KE,
                    PPPC.CONFIRM_DATE AS PC_DATE,
                    NVL (PPPC.EBS_PR_STATUS, PPPC.EBS_MODIFIER_STATUS)
                       AS PC_STATUS,
                    PPPC.PERIODE_PROG_FROM AS START_DATE,
                    PPPC.PERIODE_PROG_TO AS END_DATE,
                    TO_CHAR (PPPC.PERIODE_PROG_FROM, 'MONTH') AS MONTH_START,
                    TO_CHAR (PPPC.PERIODE_PROG_TO, 'MONTH') AS MONTH_END,
                    TO_CHAR (PPPC.PERIODE_PROG_FROM, 'YYYY') AS YEAR_PROMO,
                    PPPC.PROG_PROMO,
                    PPPC.PROPOSAL_TYPE,
                    PPPC.MEKANISME_PENAGIHAN,
                    --PRODUK
                    0 AS LINE,
                    NULL CUST_REGION,
                    NULL CUST_AREA,
                    NULL CUST_LOC,
                    NULL CUST_TYPE,
                    NULL CUST_GROUP,
                    NULL CUST_DETAIL,
                    NULL EXCLUDED_CUST_REGION,
                    NULL EXCLUDED_CUST_AREA,
                    NULL EXCLUDED_CUST_LOC,
                    NULL EXCLUDED_CUST_TYPE,
                    NULL EXCLUDED_CUST_GROUP,
                    NULL EXCLUDED_CUST_DETAIL,
                    NULL PROD_CATEGORY,
                    NULL PROD_CLASS,
                    NULL PROD_BRAND,
                    NULL PROD_EXTENSION,
                    NULL PROD_PACKAGING,
                    NULL PROD_VARIANT,
                    NULL PRODUCT_DETAIL,
                    NULL PROD_MEKANISME,
                    NULL DETIL_PROMO,
                    NULL ON_TOP_TPB,
                    NULL MF_PB,
                    NULL TOTAL_ON_TOP_TPB,
                    NULL TOTAL_MF_PB,
                    'PEMBULATAN REALISASI' ITEM_EXPENSE,
                    NULL KODE_POSTING_ON_TOP,
                    NULL KODE_POSTING_MF,
                    PBUD.AMOUNT AS VALUE_BUDGET_KOMBINASI,
                    CASE
                       WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                          FVRMT.AMOUNT_OT
                       WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
                       THEN
                          NVL (
                             CASE
                                WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF =
                                        0
                                     AND   PROD.DISC_ON_TOP
                                         + PROD.BRG_BONUS_ON_TOP
                                         + PROD.BIA_ONTOP > 0
                                THEN
                                   FVRD.AMOUNT_CM
                                WHEN       FVRD.AMOUNT_CM
                                         - PROD.DISC_MF
                                         - PROD.BRG_BONUS_MF
                                         - PROD.BIA_MF > 0
                                     AND   PROD.DISC_ON_TOP
                                         + PROD.BRG_BONUS_ON_TOP
                                         + PROD.BIA_ONTOP > 0
                                     AND   PROD.DISC_MF
                                         + PROD.BRG_BONUS_MF
                                         + PROD.BIA_MF > 0
                                THEN
                                     FVRD.AMOUNT_CM
                                   - PROD.DISC_MF
                                   - PROD.BRG_BONUS_MF
                                   - PROD.BIA_MF
                                ELSE
                                   0
                             END,
                             0)
                          + NVL (
                               CASE
                                  WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF =
                                          0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                  THEN
                                     FVRG.TOTAL
                                  WHEN       FVRG.TOTAL
                                           - PROD.DISC_MF
                                           - PROD.BRG_BONUS_MF
                                           - PROD.BIA_MF > 0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                       FVRG.TOTAL
                                     - PROD.DISC_MF
                                     - PROD.BRG_BONUS_MF
                                     - PROD.BIA_MF
                                  ELSE
                                     0
                               END,
                               0)
                       ELSE
                          NULL
                    END
                       VALUE_OT_TPB,                                        --
                    CASE
                       WHEN PPPC.DISCOUNT_TYPE = 'POTONGAN'
                            AND PPPC.MEKANISME_PENAGIHAN = 'ONINVOICE'
                       THEN
                          FVRMT.AMOUNT_MF
                       WHEN PPPC.MEKANISME_PENAGIHAN = 'OFFINVOICE'
                       THEN
                          NVL (
                             CASE
                                WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF >
                                        0
                                     AND   PROD.DISC_ON_TOP
                                         + PROD.BRG_BONUS_ON_TOP
                                         + PROD.BIA_ONTOP = 0
                                THEN
                                   FVRD.AMOUNT_CM
                                WHEN       PROD.DISC_ON_TOP
                                         + PROD.BRG_BONUS_ON_TOP
                                         + PROD.BIA_ONTOP > 0
                                     AND   PROD.DISC_MF
                                         + PROD.BRG_BONUS_MF
                                         + PROD.BIA_MF > 0
                                     AND FVRD.AMOUNT_CM > 0
                                THEN
                                   CASE
                                      WHEN   FVRD.AMOUNT_CM
                                           - PROD.DISC_MF
                                           - PROD.BRG_BONUS_MF
                                           - PROD.BIA_MF < 0
                                      THEN
                                         FVRD.AMOUNT_CM
                                      ELSE
                                           PROD.DISC_MF
                                         + PROD.BRG_BONUS_MF
                                         + PROD.BIA_MF
                                   END
                                ELSE
                                   FVRD.AMOUNT_CM
                             END,
                             0)
                          + NVL (
                               CASE
                                  WHEN PROD.DISC_MF + PROD.BRG_BONUS_MF + PROD.BIA_MF >
                                          0
                                       AND   PROD.DISC_ON_TOP
                                           + PROD.BRG_BONUS_ON_TOP
                                           + PROD.BIA_ONTOP = 0
                                  THEN
                                     FVRG.TOTAL
                                  WHEN   PROD.DISC_ON_TOP
                                       + PROD.BRG_BONUS_ON_TOP
                                       + PROD.BIA_ONTOP > 0
                                       AND   PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF > 0
                                  THEN
                                     CASE
                                        WHEN   FVRG.TOTAL
                                             - PROD.DISC_MF
                                             - PROD.BRG_BONUS_MF
                                             - PROD.BIA_MF < 0
                                        THEN
                                           FVRG.TOTAL
                                        ELSE
                                             PROD.DISC_MF
                                           + PROD.BRG_BONUS_MF
                                           + PROD.BIA_MF
                                     END
                                  ELSE
                                     0
                               END,
                               0)
                       ELSE
                          NULL
                    END
                       VALUE_MF_PB,                                         --
                    NULL REMAINING_ON_TOP_TPB,
                    NULL REMAINING_MF_PB,
                    NULL KETERANGAN,
                    NULL DOC1,
                    NULL DOC1_DATE,
                    NULL DOC2,
                    NULL DOC2_DATE,
                    NULL DOC3,
                    NULL DOC3_DATE,
                    NULL DOC4,
                    NULL DOC4_DATE
               FROM FOCUSPP.PROPOSAL PPPC,
                    (SELECT ROW_NUMBER ()
                            OVER (PARTITION BY pp.proposal_id
                                  ORDER BY pp.proposal_id, pp.PROMO_PRODUK_ID)
                               AS LINE_NO,
                            pp.*
                       FROM FOCUSPP.PROMO_PRODUK pp) PROD,
                    FOCUSPP.PROD_BUDGET_BY PBUD,
                    APPS.FCS_VIEW_REALISASI_GR FVRG,
                    APPS.FCS_VIEW_REALISASI_DCV FVRD,
                    (  SELECT LINE_NO,
                              MAX (CONFIRM_NO) CONFIRM_NO,
                              SUM (OT) AMOUNT_MF,
                              SUM (MF) AMOUNT_OT
                         FROM (SELECT FVRM.PROPOSAL_ID,
                                      FVRM.PROPOSAL_NO,
                                      FVRM.CONFIRM_NO,
                                      FVRM.CONFIRM_NO_ORIG,
                                      FVRM.PROMO_PRODUK_ID,
                                      FVRM.LINE_NO,
                                      FVRM.AMOUNT OT,
                                      0 MF
                                 FROM APPS.FCS_VIEW_REALISASI_MODIFIER FVRM
                                WHERE KET = 'OT'
                               UNION ALL
                               SELECT FVRM.PROPOSAL_ID,
                                      FVRM.PROPOSAL_NO,
                                      FVRM.CONFIRM_NO,
                                      FVRM.CONFIRM_NO_ORIG,
                                      FVRM.PROMO_PRODUK_ID,
                                      FVRM.LINE_NO,
                                      0 OT,
                                      FVRM.AMOUNT MF
                                 FROM APPS.FCS_VIEW_REALISASI_MODIFIER FVRM
                                WHERE KET = 'MF')
                        WHERE 1 = 1
                     GROUP BY LINE_NO, CONFIRM_NO_ORIG) FVRMT
              WHERE PROD.PROPOSAL_ID = PPPC.PROPOSAL_ID
                    AND PBUD.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    --              AND PPPC.CONFIRM_NO = 'I0318000224'
                    AND FVRG.NO_KONFIRMASI(+) =
                           PPPC.CONFIRM_NO
                           || DECODE (PPPC.ADDENDUM_KE,
                                      NULL, '',
                                      '-' || PPPC.ADDENDUM_KE)
                    AND FVRG.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND FVRG.LINE_NO(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRD.PROPOSAL_ID(+) = PPPC.PROPOSAL_ID
                    AND FVRD.PROMO_PRODUK_ID(+) = PROD.PROMO_PRODUK_ID
                    AND FVRD.LINE_NUM_PC(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRMT.LINE_NO(+) =
                           NVL (PROD.PRODUK_ROW_NUM, PROD.LINE_NO)
                    AND FVRMT.CONFIRM_NO(+) =
                           PPPC.CONFIRM_NO
                           || DECODE (PPPC.ADDENDUM_KE,
                                      NULL, '',
                                      '-' || PPPC.ADDENDUM_KE)
                    AND (  NVL (FVRMT.AMOUNT_MF, 0)
                         + NVL (FVRMT.AMOUNT_OT, 0)
                         + NVL (FVRD.AMOUNT_CM, 0)
                         + NVL (FVRG.TOTAL, 0)) > 0) LALA
      WHERE CASE
               WHEN (LALA.VALUE_OT_TPB + LALA.VALUE_MF_PB) - LALA.VALUE_BUDGET_KOMBINASI <
                       1
                    AND (LALA.VALUE_OT_TPB + LALA.VALUE_MF_PB)
                        - LALA.VALUE_BUDGET_KOMBINASI > 0
               THEN
                  (LALA.VALUE_OT_TPB + LALA.VALUE_MF_PB)
                  - LALA.VALUE_BUDGET_KOMBINASI
               ELSE
                  0
            END > 0
   GROUP BY LALA.PROPOSAL_NO,
            LALA.COMPANY_ID,
            LALA.PEMOHON,
            LALA.PP,
            LALA.PP_DATE,
            LALA.PP_REFERENCE,
            LALA.PP_STATUS,
            LALA.PC,
            LALA.ADDENDUM_KE,
            LALA.PC_DATE,
            LALA.PC_STATUS,
            LALA.START_DATE,
            LALA.END_DATE,
            LALA.MONTH_START,
            LALA.MONTH_END,
            LALA.YEAR_PROMO,
            LALA.PROG_PROMO,
            LALA.PROPOSAL_TYPE,
            LALA.MEKANISME_PENAGIHAN,
            LALA.LINE,
            LALA.CUST_REGION,
            LALA.CUST_AREA,
            LALA.CUST_LOC,
            LALA.CUST_TYPE,
            LALA.CUST_GROUP,
            LALA.CUST_DETAIL,
            LALA.EXCLUDED_CUST_REGION,
            LALA.EXCLUDED_CUST_AREA,
            LALA.EXCLUDED_CUST_LOC,
            LALA.EXCLUDED_CUST_TYPE,
            LALA.EXCLUDED_CUST_GROUP,
            LALA.EXCLUDED_CUST_DETAIL,
            LALA.PROD_CATEGORY,
            LALA.PROD_CLASS,
            LALA.PROD_BRAND,
            LALA.PROD_EXTENSION,
            LALA.PROD_PACKAGING,
            LALA.PROD_VARIANT,
            LALA.PRODUCT_DETAIL,
            LALA.PROD_MEKANISME,
            LALA.DETIL_PROMO,
            LALA.ON_TOP_TPB,
            LALA.MF_PB,
            LALA.TOTAL_ON_TOP_TPB,
            LALA.TOTAL_MF_PB,
            LALA.ITEM_EXPENSE,
            LALA.KODE_POSTING_ON_TOP,
            LALA.KODE_POSTING_MF,
            LALA.REMAINING_ON_TOP_TPB,
            LALA.REMAINING_MF_PB,
            LALA.KETERANGAN,
            LALA.DOC1,
            LALA.DOC1_DATE,
            LALA.DOC2,
            LALA.DOC2_DATE,
            LALA.DOC3,
            LALA.DOC3_DATE,
            LALA.DOC4,
            LALA.DOC4_DATE
   ORDER BY PROPOSAL_NO, LINE
/

