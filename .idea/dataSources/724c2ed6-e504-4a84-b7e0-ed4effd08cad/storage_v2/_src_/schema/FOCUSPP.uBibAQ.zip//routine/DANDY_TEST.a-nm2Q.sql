create function dandy_test(prop_id IN NUMBER)
return varchar2
is
 cursor dd is select doc_approval_id from doc_approval where proposal_id=prop_id;
 
 vdoc varchar2(200);
 
begin
 vdoc := '';
 for dd_rec in dd
 loop
   vdoc := vdoc || '-'|| to_char(dd_rec.doc_approval_id);
 end loop;
 return vdoc;
end;
/

