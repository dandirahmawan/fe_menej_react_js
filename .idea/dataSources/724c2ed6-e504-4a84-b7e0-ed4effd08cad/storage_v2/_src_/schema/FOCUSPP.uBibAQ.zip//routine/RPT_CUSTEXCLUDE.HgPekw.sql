create FUNCTION         RPT_CUSTEXCLUDE (P1 NUMBER) 
RETURN VARCHAR2
AS
  TORET VARCHAR2(4000);
  MAX_FIELD_LEN CONSTANT NUMBER := 3500;
BEGIN
    SELECT LISTAGG(COMB.exclude,'; ') WITHIN GROUP (ORDER BY COMB.PROMO_PRODUK_ID)
    INTO TORET
    FROM
    (
     select pch.REGION_DESC ||(case when pch.REGION_DESC is null
 then ''  when pch.AREA_DESC is not null then ' ' else null end)||nvl(pch.AREA_DESC,' ')||(case when pch.AREA_DESC is null
 then '' when pch.LOC_DESC is not null then ' ' else null end)||nvl(pch.LOC_DESC,' ')||(case when pch.LOC_DESC is null
 then '' when pch.CUSTTYP_DESC is not null then ' ' else null end)||nvl(pch.CUSTTYP_DESC,' ')||(case when pch.CUSTTYP_DESC is null
 then '' when pch.CUSTGRP_DESC is not null then ' ' else null end)||nvl(pch.CUSTGRP_DESC,' ')||(case when pch.CUSTGRP_DESC is null
 then '' when pch.CUSTOMER_NAME is not null then ' ' else null end)||pch.CUSTOMER_NAME exclude,pch.promo_produk_id
   FROM PROMO_CUSTX_HO pch
 WHERE pch.promo_produk_id = P1
 union
 select pca.REGION_DESC ||(case when pca.REGION_DESC is null
 then ''  when pca.AREA_DESC is not null then ' ' else null end)||nvl(pca.AREA_DESC,' ')||(case when pca.AREA_DESC is null
 then '' when pca.LOC_DESC is not null then ' ' else null end)||nvl(pca.LOC_DESC,' ')||(case when pca.LOC_DESC is null
 then '' when pca.CUSTTYP_DESC is not null then ' ' else null end)||nvl(pca.CUSTTYP_DESC,' ')||(case when pca.CUSTTYP_DESC is null
 then '' when pca.CUSTGRP_DESC is not null then ' ' else null end)||nvl(pca.CUSTGRP_DESC,' ')||(case when pca.CUSTGRP_DESC is null
 then '' when pca.CUSTOMER_NAME is not null then ' ' else null end)||CUSTOMER_NAME exclude,pca.promo_produk_id
   FROM PROMO_CUSTX_area pca
 WHERE pca.promo_produk_id = P1
    ) COMB;
    RETURN NVL(TORET,'');
EXCEPTION WHEN OTHERS
THEN RETURN ('');
END;
/

